# Review Package Inventory

This inventory checks package completeness and file traceability for external review. It does not validate evidence quality, approve formal acceptance records, certify calibration, or close final-study gates.

## Summary

- Review package inventory ready: `true`
- Can mark complete: `false`
- Inventory rows: 810
- Total size bytes: 38634514
- Missing required groups: 0
- Formal target files present: 0
- Draft or template files present: 41

## Required Groups

| Group | Present | Matched Path | Candidate Paths |
| --- | --- | --- | --- |
| readme | true | `README.md` | README.md |
| agent_instructions | true | `agents.md` | AGENTS.md; agents.md |
| plan | true | `plan.md` | plan.md |
| status | true | `status.md` | status.md |
| implementation_plan | true | `IMPLEMENTATION_PLAN.md` | IMPLEMENTATION_PLAN.md |
| main_entrypoint | true | `main.py` | main.py |
| config | true | `config.yaml` | config.yaml |
| requirements | true | `requirements.txt` | requirements.txt |
| source_tree | true | `src` | src |
| script_tree | true | `scripts` | scripts |
| test_tree | true | `tests` | tests |
| data_tree | true | `data` | data |
| docs_tree | true | `docs` | docs |
| paper_tree | true | `paper` | paper |
| results_tree | true | `results` | results |

## Role Counts

| Role | Count |
| --- | --- |
| agent_definition | 1 |
| configuration | 2 |
| data_or_manifest | 220 |
| documentation | 126 |
| generated_result | 56 |
| other | 1 |
| paper_or_report | 3 |
| schema | 1 |
| script | 110 |
| source_code | 149 |
| test | 141 |

## Formal Target Files Present

- none

## First Inventory Rows

| Role | Stage | Size | Path |
| --- | --- | --- | --- |
| other | supporting_artifact | 400 | `.gitignore` |
| documentation | supporting_artifact | 13807 | `IMPLEMENTATION_PLAN.md` |
| documentation | supporting_artifact | 80064 | `README.md` |
| documentation | supporting_artifact | 66435 | `agents.md` |
| agent_definition | supporting_artifact | 28703 | `agents/acceptance_review_agents.json` |
| documentation | supporting_artifact | 5701 | `cloned_repo_manifest.md` |
| configuration | supporting_artifact | 3638 | `config.yaml` |
| data_or_manifest | cached_input | 9080288 | `data/cache/pilot_region_road.graphml` |
| data_or_manifest | cached_input | 1158 | `data/cache/pilot_region_road_manifest.json` |
| data_or_manifest | supporting_artifact | 3888 | `data/manifests/acceptance_decision_template_manifest.json` |
| data_or_manifest | supporting_artifact | 145728 | `data/manifests/acceptance_orchestration_manifest.json` |
| data_or_manifest | supporting_artifact | 11469 | `data/manifests/acceptance_task_assignments.csv` |
| data_or_manifest | supporting_artifact | 1870 | `data/manifests/acceptance_task_assignments_manifest.json` |
| data_or_manifest | draft_or_template | 1626 | `data/manifests/acceptance_templates/experiment_acceptance_template.json` |
| data_or_manifest | draft_or_template | 1826 | `data/manifests/acceptance_templates/final_audit_acceptance_template.json` |
| data_or_manifest | draft_or_template | 3007 | `data/manifests/acceptance_templates/graph_scale_acceptance_template.json` |
| data_or_manifest | draft_or_template | 1376 | `data/manifests/acceptance_templates/manuscript_acceptance_template.json` |
| data_or_manifest | draft_or_template | 1109 | `data/manifests/acceptance_templates/pilot_acceptance_template.json` |
| data_or_manifest | draft_or_template | 2767 | `data/manifests/acceptance_templates/provenance_acceptance_template.json` |
| data_or_manifest | draft_or_template | 1389 | `data/manifests/acceptance_templates/reproducibility_acceptance_template.json` |
| data_or_manifest | draft_or_template | 2010 | `data/manifests/acceptance_templates/sensitivity_acceptance_template.json` |
| data_or_manifest | draft_or_template | 2474 | `data/manifests/acceptance_templates/validation_acceptance_template.json` |
| data_or_manifest | supporting_artifact | 14194 | `data/manifests/agent_review_path_audit.json` |
| data_or_manifest | supporting_artifact | 11324 | `data/manifests/agent_reviews/cached_osm_input__road_rail_parameter_evidence_agent.json` |
| data_or_manifest | supporting_artifact | 11518 | `data/manifests/agent_reviews/data_provenance__osm_source_license_provenance_review_agent.json` |
| data_or_manifest | supporting_artifact | 5979 | `data/manifests/agent_reviews/final_audit__final_independent_audit_agent.json` |
| data_or_manifest | supporting_artifact | 6573 | `data/manifests/agent_reviews/full_experiment_output__full_experiment_package_agent.json` |
| data_or_manifest | supporting_artifact | 9544 | `data/manifests/agent_reviews/graph_scale_strategy__graph_scale_method_review_agent.json` |
| data_or_manifest | supporting_artifact | 7108 | `data/manifests/agent_reviews/manuscript_report_alignment__paper_report_claim_alignment_agent.json` |
| data_or_manifest | supporting_artifact | 11528 | `data/manifests/agent_reviews/parameter_evidence__road_rail_parameter_evidence_agent.json` |
| data_or_manifest | supporting_artifact | 3799 | `data/manifests/agent_reviews/pilot_region_accepted__pilot_region_privacy_review_agent.json` |
| data_or_manifest | supporting_artifact | 10158 | `data/manifests/agent_reviews/rail_evidence__road_rail_parameter_evidence_agent.json` |
| data_or_manifest | supporting_artifact | 4819 | `data/manifests/agent_reviews/reproducibility__clean_checkout_reproducibility_agent.json` |
| data_or_manifest | supporting_artifact | 5828 | `data/manifests/agent_reviews/sensitivity_analysis__sensitivity_analysis_review_agent.json` |
| data_or_manifest | supporting_artifact | 7535 | `data/manifests/agent_reviews/validation_package__validation_benchmark_strategy_agent.json` |
| data_or_manifest | supporting_artifact | 2525 | `data/manifests/claim_alignment_review_manifest.json` |
| data_or_manifest | review_aid | 61701 | `data/manifests/claim_alignment_review_packet.csv` |
| data_or_manifest | supporting_artifact | 7800 | `data/manifests/crn_pairing_audit.csv` |
| data_or_manifest | supporting_artifact | 1316 | `data/manifests/crn_pairing_audit_manifest.json` |
| data_or_manifest | supporting_artifact | 43292 | `data/manifests/current_goal_completion_audit.json` |
| data_or_manifest | supporting_artifact | 4863 | `data/manifests/deterministic_rerun_audit.csv` |
| data_or_manifest | supporting_artifact | 2504 | `data/manifests/deterministic_rerun_audit_manifest.json` |
| data_or_manifest | draft_or_template | 22168 | `data/manifests/draft_acceptance/data_provenance_pre_review.json` |
| data_or_manifest | draft_or_template | 10662 | `data/manifests/draft_acceptance/final_audit_document_pre_review.json` |
| data_or_manifest | draft_or_template | 10617 | `data/manifests/draft_acceptance/final_audit_pre_review.json` |
| data_or_manifest | draft_or_template | 1963 | `data/manifests/draft_acceptance/formal_acceptance_pre_review_manifest.json` |
| data_or_manifest | draft_or_template | 1626 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/experiment_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 1826 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/final_audit_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 3007 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/graph_scale_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 1376 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/manuscript_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 1109 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/pilot_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 2767 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/provenance_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 1389 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/reproducibility_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 2010 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/sensitivity_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 2474 | `data/manifests/draft_acceptance/formal_target_placeholders_20260510/validation_acceptance.placeholder.json` |
| data_or_manifest | draft_or_template | 12384 | `data/manifests/draft_acceptance/full_experiment_output_pre_review.json` |
| data_or_manifest | draft_or_template | 20478 | `data/manifests/draft_acceptance/graph_scale_strategy_pre_review.json` |
| data_or_manifest | draft_or_template | 13091 | `data/manifests/draft_acceptance/manuscript_report_alignment_pre_review.json` |
| data_or_manifest | draft_or_template | 34435 | `data/manifests/draft_acceptance/parameter_acceptance_pre_review.json` |
| data_or_manifest | draft_or_template | 8437 | `data/manifests/draft_acceptance/pilot_region_accepted_pre_review.json` |
| data_or_manifest | draft_or_template | 10567 | `data/manifests/draft_acceptance/reproducibility_pre_review.json` |
| data_or_manifest | draft_or_template | 26840 | `data/manifests/draft_acceptance/road_class_overrides_pre_review.json` |
| data_or_manifest | draft_or_template | 12585 | `data/manifests/draft_acceptance/sensitivity_analysis_pre_review.json` |
| data_or_manifest | draft_or_template | 16645 | `data/manifests/draft_acceptance/validation_package_pre_review.json` |
| data_or_manifest | supporting_artifact | 3371 | `data/manifests/experiment_design_decision_manifest.json` |
| data_or_manifest | review_aid | 11051 | `data/manifests/experiment_design_decision_packet.csv` |
| data_or_manifest | supporting_artifact | 2325 | `data/manifests/experiment_package_review_manifest.json` |
| data_or_manifest | review_aid | 5331 | `data/manifests/experiment_package_review_packet.csv` |
| data_or_manifest | supporting_artifact | 10549 | `data/manifests/experiment_statistical_analysis_plan.json` |
| data_or_manifest | supporting_artifact | 2263 | `data/manifests/experiment_strategy_readiness_manifest.json` |
| data_or_manifest | review_aid | 5447 | `data/manifests/experiment_strategy_readiness_packet.csv` |
| data_or_manifest | supporting_artifact | 1980 | `data/manifests/figure_table_review_manifest.json` |
| data_or_manifest | review_aid | 12310 | `data/manifests/figure_table_review_packet.csv` |
| data_or_manifest | supporting_artifact | 3606 | `data/manifests/final_audit_decision_manifest.json` |
| data_or_manifest | review_aid | 11070 | `data/manifests/final_audit_decision_packet.csv` |
| data_or_manifest | review_aid | 8017 | `data/manifests/formal_acceptance_blocker_queue.csv` |
| data_or_manifest | review_aid | 1062 | `data/manifests/formal_acceptance_blocker_queue_manifest.json` |
| data_or_manifest | review_aid | 26028 | `data/manifests/formal_acceptance_evidence_matrix.csv` |
| data_or_manifest | review_aid | 1543 | `data/manifests/formal_acceptance_evidence_matrix_manifest.json` |
| data_or_manifest | supporting_artifact | 16487 | `data/manifests/formal_acceptance_package_audit.json` |
| data_or_manifest | supporting_artifact | 3488 | `data/manifests/formal_evidence_path_audit.json` |
| data_or_manifest | supporting_artifact | 2995 | `data/manifests/manuscript_report_decision_manifest.json` |
| data_or_manifest | review_aid | 8215 | `data/manifests/manuscript_report_decision_packet.csv` |
| data_or_manifest | supporting_artifact | 9011 | `data/manifests/pilot_experiment_design.json` |
| data_or_manifest | supporting_artifact | 2207 | `data/manifests/pilot_privacy_review_manifest.json` |
| data_or_manifest | review_aid | 4515 | `data/manifests/pilot_privacy_review_packet.csv` |
| data_or_manifest | supporting_artifact | 2490 | `data/manifests/pilot_region_decision_manifest.json` |
| data_or_manifest | review_aid | 5599 | `data/manifests/pilot_region_decision_packet.csv` |
| data_or_manifest | supporting_artifact | 3430 | `data/manifests/publication_readiness_audit.json` |
| data_or_manifest | supporting_artifact | 7840 | `data/manifests/replication_adequacy_audit.csv` |
| data_or_manifest | supporting_artifact | 1319 | `data/manifests/replication_adequacy_audit_manifest.json` |
| data_or_manifest | supporting_artifact | 36058 | `data/manifests/reproducibility_manifest.json` |
| data_or_manifest | supporting_artifact | 5796 | `data/manifests/seed_stream_manifest.json` |
| data_or_manifest | supporting_artifact | 3036 | `data/manifests/source_context_cache_decision_manifest.json` |
| data_or_manifest | review_aid | 6165 | `data/manifests/source_context_cache_decision_packet.csv` |
| data_or_manifest | supporting_artifact | 2283 | `data/manifests/source_context_cache_request_manifest.json` |
| data_or_manifest | supporting_artifact | 5878 | `data/manifests/source_context_cache_request_packet.csv` |
| data_or_manifest | supporting_artifact | 2382 | `data/manifests/source_license_review_manifest.json` |
| data_or_manifest | review_aid | 11231 | `data/manifests/source_license_review_packet.csv` |
| data_or_manifest | supporting_artifact | 3535 | `data/manifests/source_provenance_decision_manifest.json` |
| ... | ... | ... | 710 additional rows in CSV |

## Use

Use this inventory before assembling a renewed expert-review ZIP. It proves what files are available for packaging, but it does not prove that evidence is sufficient or that formal acceptance gates are closed.
