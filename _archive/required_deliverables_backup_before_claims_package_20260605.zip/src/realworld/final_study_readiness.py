"""Plan-level final-study readiness audit.

This module maps the final definition of done in ``plan.md`` to concrete
repository artifacts. It deliberately separates scaffold artifact presence from
final-study readiness so generated outputs do not accidentally unlock
calibrated real-world claims.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Iterable

from src.realworld.final_audit_acceptance import summarize_final_audit_acceptance
from src.realworld.final_audit_decision_packet import (
    DEFAULT_FINAL_AUDIT_DECISION_DOC_PATH,
    DEFAULT_FINAL_AUDIT_DECISION_MANIFEST_PATH,
    DEFAULT_FINAL_AUDIT_DECISION_PACKET_PATH,
)
from src.realworld.parameter_audit import audit_shipped_parameter_evidence
from src.realworld.parameter_evidence_priority_packet import (
    DEFAULT_PARAMETER_EVIDENCE_PRIORITY_DOC_PATH,
    DEFAULT_PARAMETER_EVIDENCE_PRIORITY_MANIFEST_PATH,
    DEFAULT_PARAMETER_EVIDENCE_PRIORITY_PACKET_PATH,
)
from src.realworld.parameter_source_decision_packet import (
    DEFAULT_PARAMETER_SOURCE_DECISION_DOC_PATH,
    DEFAULT_PARAMETER_SOURCE_DECISION_MANIFEST_PATH,
    DEFAULT_PARAMETER_SOURCE_DECISION_PACKET_PATH,
)
from src.realworld.transfer_evidence_review_packet import (
    DEFAULT_TRANSFER_EVIDENCE_REVIEW_DOC_PATH,
    DEFAULT_TRANSFER_EVIDENCE_REVIEW_MANIFEST_PATH,
    DEFAULT_TRANSFER_EVIDENCE_REVIEW_PACKET_PATH,
)
from src.realworld.graph_scale_acceptance import summarize_graph_scale_acceptance
from src.realworld.graph_scale_method_decision_packet import (
    DEFAULT_GRAPH_SCALE_METHOD_DECISION_DOC_PATH,
    DEFAULT_GRAPH_SCALE_METHOD_DECISION_MANIFEST_PATH,
    DEFAULT_GRAPH_SCALE_METHOD_DECISION_PACKET_PATH,
)
from src.realworld.experiment_acceptance import summarize_experiment_acceptance
from src.realworld.experiment_design_decision_packet import (
    DEFAULT_EXPERIMENT_DESIGN_DECISION_DOC_PATH,
    DEFAULT_EXPERIMENT_DESIGN_DECISION_MANIFEST_PATH,
    DEFAULT_EXPERIMENT_DESIGN_DECISION_PACKET_PATH,
)
from src.realworld.figure_table_review_packet import (
    DEFAULT_FIGURE_TABLE_REVIEW_DOC_PATH,
    DEFAULT_FIGURE_TABLE_REVIEW_MANIFEST_PATH,
    DEFAULT_FIGURE_TABLE_REVIEW_PACKET_PATH,
)
from src.realworld.manuscript_acceptance import summarize_manuscript_acceptance
from src.realworld.pilot_acceptance import summarize_pilot_acceptance
from src.realworld.pilot_region_decision_packet import (
    DEFAULT_PILOT_REGION_DECISION_DOC_PATH,
    DEFAULT_PILOT_REGION_DECISION_MANIFEST_PATH,
    DEFAULT_PILOT_REGION_DECISION_PACKET_PATH,
)
from src.realworld.provenance_acceptance import summarize_provenance_acceptance
from src.realworld.publication_readiness import audit_publication_readiness
from src.realworld.rail_evidence import (
    DEFAULT_RAIL_SERVICE_EVIDENCE_PATH,
    load_rail_service_evidence,
    summarize_rail_service_evidence,
)
from src.realworld.rail_station_binding import (
    DEFAULT_RAIL_STATION_BINDING_PATH,
    load_rail_station_bindings,
    summarize_rail_station_bindings,
)
from src.realworld.rail_evidence_priority_packet import (
    DEFAULT_RAIL_EVIDENCE_PRIORITY_DOC_PATH,
    DEFAULT_RAIL_EVIDENCE_PRIORITY_MANIFEST_PATH,
    DEFAULT_RAIL_EVIDENCE_PRIORITY_PACKET_PATH,
)
from src.realworld.rail_source_decision_packet import (
    DEFAULT_RAIL_SOURCE_DECISION_DOC_PATH,
    DEFAULT_RAIL_SOURCE_DECISION_MANIFEST_PATH,
    DEFAULT_RAIL_SOURCE_DECISION_PACKET_PATH,
)
from src.realworld.road_evidence import audit_cached_road_evidence
from src.realworld.road_evidence_diagnostics import (
    audit_cached_road_evidence_diagnostics,
)
from src.realworld.road_override_audit import (
    audit_road_class_override_application,
    audit_road_class_override_evidence,
)
from src.realworld.road_evidence_priority_packet import (
    DEFAULT_ROAD_EVIDENCE_PRIORITY_DOC_PATH,
    DEFAULT_ROAD_EVIDENCE_PRIORITY_MANIFEST_PATH,
    DEFAULT_ROAD_EVIDENCE_PRIORITY_PACKET_PATH,
)
from src.realworld.road_attribute_evidence import (
    DEFAULT_ROAD_ATTRIBUTE_EVIDENCE_MANIFEST_PATH,
    DEFAULT_ROAD_ATTRIBUTE_EVIDENCE_PATH,
)
from src.realworld.road_source_decision_packet import (
    DEFAULT_ROAD_SOURCE_DECISION_DOC_PATH,
    DEFAULT_ROAD_SOURCE_DECISION_MANIFEST_PATH,
    DEFAULT_ROAD_SOURCE_DECISION_PACKET_PATH,
)
from src.realworld.reproducibility_acceptance import (
    summarize_reproducibility_acceptance,
)
from src.realworld.reproducibility_review_packet import (
    DEFAULT_REPRODUCIBILITY_REVIEW_MANIFEST_PATH,
)
from src.realworld.reproducibility_decision_packet import (
    DEFAULT_REPRODUCIBILITY_DECISION_DOC_PATH,
    DEFAULT_REPRODUCIBILITY_DECISION_MANIFEST_PATH,
    DEFAULT_REPRODUCIBILITY_DECISION_PACKET_PATH,
)
from src.realworld.reproducibility_smoke import summarize_reproducibility_smoke
from src.realworld.clean_checkout_smoke import summarize_clean_checkout_smoke
from src.realworld.sensitivity_acceptance import summarize_sensitivity_acceptance
from src.realworld.sensitivity_index_review_packet import (
    DEFAULT_SENSITIVITY_INDEX_REVIEW_DOC_PATH,
    DEFAULT_SENSITIVITY_INDEX_REVIEW_MANIFEST_PATH,
    DEFAULT_SENSITIVITY_INDEX_REVIEW_PACKET_PATH,
)
from src.realworld.sensitivity_method_decision_packet import (
    DEFAULT_SENSITIVITY_METHOD_DECISION_DOC_PATH,
    DEFAULT_SENSITIVITY_METHOD_DECISION_MANIFEST_PATH,
    DEFAULT_SENSITIVITY_METHOD_DECISION_PACKET_PATH,
)
from src.realworld.source_provenance import summarize_source_provenance_manifest
from src.realworld.source_provenance_priority_packet import (
    DEFAULT_SOURCE_PROVENANCE_PRIORITY_DOC_PATH,
    DEFAULT_SOURCE_PROVENANCE_PRIORITY_MANIFEST_PATH,
    DEFAULT_SOURCE_PROVENANCE_PRIORITY_PACKET_PATH,
)
from src.realworld.source_context_cache_request_packet import (
    DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_DOC_PATH,
    DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_MANIFEST_PATH,
    DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_PACKET_PATH,
)
from src.realworld.source_context_cache_decision_packet import (
    DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_DOC_PATH,
    DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_MANIFEST_PATH,
    DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_PACKET_PATH,
)
from src.realworld.source_provenance_decision_packet import (
    DEFAULT_SOURCE_PROVENANCE_DECISION_DOC_PATH,
    DEFAULT_SOURCE_PROVENANCE_DECISION_MANIFEST_PATH,
    DEFAULT_SOURCE_PROVENANCE_DECISION_PACKET_PATH,
)
from src.realworld.validation_acceptance import summarize_validation_acceptance
from src.realworld.validation_benchmark_decision_packet import (
    DEFAULT_VALIDATION_BENCHMARK_DECISION_DOC_PATH,
    DEFAULT_VALIDATION_BENCHMARK_DECISION_MANIFEST_PATH,
    DEFAULT_VALIDATION_BENCHMARK_DECISION_PACKET_PATH,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_FINAL_AUDIT_PATH = PROJECT_ROOT / "docs" / "final_study_audit.md"
DEFAULT_CLAIM_ALIGNMENT_REVIEW_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "claim_alignment_review_manifest.json"
)
DEFAULT_MANUSCRIPT_REPORT_DECISION_PACKET_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "manuscript_report_decision_packet.csv"
)
DEFAULT_MANUSCRIPT_REPORT_DECISION_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "manuscript_report_decision_manifest.json"
)
DEFAULT_MANUSCRIPT_REPORT_DECISION_DOC_PATH = (
    PROJECT_ROOT / "docs" / "manuscript_report_decision_packet.md"
)
DEFAULT_EXPERIMENT_PACKAGE_REVIEW_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "experiment_package_review_manifest.json"
)
DEFAULT_EXPERIMENT_STRATEGY_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "experiment_strategy_readiness_manifest.json"
)
DEFAULT_SOURCE_URL_REVIEW_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "source_url_review_manifest.json"
)
DEFAULT_SOURCE_URL_REMEDIATION_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "manifests" / "source_url_remediation_manifest.json"
)
DEFAULT_RAIL_FETCH_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "rail" / "rail_fetch_readiness_manifest.json"
)
DEFAULT_ROAD_SOURCE_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "road" / "road_source_readiness_manifest.json"
)
DEFAULT_PARAMETER_SOURCE_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "parameters" / "parameter_source_readiness_manifest.json"
)
DEFAULT_GRAPH_SCALE_STRATEGY_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT
    / "data"
    / "validation"
    / "graph_scale_strategy_readiness_manifest.json"
)
DEFAULT_VALIDATION_STRATEGY_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT / "data" / "validation" / "validation_strategy_readiness_manifest.json"
)
DEFAULT_SENSITIVITY_STRATEGY_READINESS_MANIFEST_PATH = (
    PROJECT_ROOT
    / "data"
    / "validation"
    / "sensitivity_strategy_readiness_manifest.json"
)
FINAL_GATE_IDS: tuple[str, ...] = (
    "pilot_region_accepted",
    "cached_osm_input",
    "real_input_smoke",
    "graph_scale_strategy",
    "data_provenance",
    "parameter_evidence",
    "rail_evidence",
    "validation_package",
    "structured_disruptions",
    "policy_alternatives",
    "sensitivity_analysis",
    "full_experiment_output",
    "manuscript_report_alignment",
    "reproducibility",
    "final_audit",
)


def audit_final_study_readiness() -> dict[str, Any]:
    """Return a plan-to-artifact final readiness audit."""

    publication_audit = audit_publication_readiness()
    parameter_audit = audit_shipped_parameter_evidence()
    road_audit = audit_cached_road_evidence()
    road_diagnostics = audit_cached_road_evidence_diagnostics()
    road_override_audit = audit_road_class_override_evidence()
    road_override_application_audit = audit_road_class_override_application()
    rail_service_audit = summarize_rail_service_evidence(
        load_rail_service_evidence(DEFAULT_RAIL_SERVICE_EVIDENCE_PATH)
    )
    rail_station_audit = summarize_rail_station_bindings(
        load_rail_station_bindings(DEFAULT_RAIL_STATION_BINDING_PATH)
    )

    pilot_manifest = _load_json(
        PROJECT_ROOT / "results" / "realworld_pilot" / "pilot_full_manifest.json"
    )
    experiment_package_review_manifest = _load_json(
        DEFAULT_EXPERIMENT_PACKAGE_REVIEW_MANIFEST_PATH
    )
    experiment_strategy_readiness_manifest = _load_json(
        DEFAULT_EXPERIMENT_STRATEGY_READINESS_MANIFEST_PATH
    )
    experiment_design_decision_manifest = _load_json(
        DEFAULT_EXPERIMENT_DESIGN_DECISION_MANIFEST_PATH
    )
    morris_manifest = _load_json(
        PROJECT_ROOT / "results" / "realworld_pilot" / "morris_manifest.json"
    )
    figure_manifest = _load_json(
        PROJECT_ROOT
        / "results"
        / "realworld_pilot"
        / "tables"
        / "figure_table_manifest.json"
    )
    claim_alignment_manifest = _load_json(DEFAULT_CLAIM_ALIGNMENT_REVIEW_MANIFEST_PATH)
    figure_table_review_manifest = _load_json(
        DEFAULT_FIGURE_TABLE_REVIEW_MANIFEST_PATH
    )
    manuscript_report_decision_manifest = _load_json(
        DEFAULT_MANUSCRIPT_REPORT_DECISION_MANIFEST_PATH
    )
    reproducibility_manifest = _load_json(
        PROJECT_ROOT / "data" / "manifests" / "reproducibility_manifest.json"
    )
    reproducibility_review_manifest = _load_json(
        DEFAULT_REPRODUCIBILITY_REVIEW_MANIFEST_PATH
    )
    reproducibility_decision_manifest = _load_json(
        DEFAULT_REPRODUCIBILITY_DECISION_MANIFEST_PATH
    )
    final_audit_decision_manifest = _load_json(
        DEFAULT_FINAL_AUDIT_DECISION_MANIFEST_PATH
    )
    source_url_review_manifest = _load_json(DEFAULT_SOURCE_URL_REVIEW_MANIFEST_PATH)
    source_url_remediation_manifest = _load_json(
        DEFAULT_SOURCE_URL_REMEDIATION_MANIFEST_PATH
    )
    source_provenance_priority_manifest = _load_json(
        DEFAULT_SOURCE_PROVENANCE_PRIORITY_MANIFEST_PATH
    )
    source_context_cache_request_manifest = _load_json(
        DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_MANIFEST_PATH
    )
    source_context_cache_decision_manifest = _load_json(
        DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_MANIFEST_PATH
    )
    source_provenance_decision_manifest = _load_json(
        DEFAULT_SOURCE_PROVENANCE_DECISION_MANIFEST_PATH
    )
    rail_fetch_readiness_manifest = _load_json(DEFAULT_RAIL_FETCH_READINESS_MANIFEST_PATH)
    rail_evidence_priority_manifest = _load_json(
        DEFAULT_RAIL_EVIDENCE_PRIORITY_MANIFEST_PATH
    )
    rail_source_decision_manifest = _load_json(
        DEFAULT_RAIL_SOURCE_DECISION_MANIFEST_PATH
    )
    road_source_readiness_manifest = _load_json(
        DEFAULT_ROAD_SOURCE_READINESS_MANIFEST_PATH
    )
    road_source_decision_manifest = _load_json(
        DEFAULT_ROAD_SOURCE_DECISION_MANIFEST_PATH
    )
    road_evidence_priority_manifest = _load_json(
        DEFAULT_ROAD_EVIDENCE_PRIORITY_MANIFEST_PATH
    )
    road_attribute_evidence_manifest = _load_json(
        DEFAULT_ROAD_ATTRIBUTE_EVIDENCE_MANIFEST_PATH
    )
    parameter_source_readiness_manifest = _load_json(
        DEFAULT_PARAMETER_SOURCE_READINESS_MANIFEST_PATH
    )
    parameter_evidence_priority_manifest = _load_json(
        DEFAULT_PARAMETER_EVIDENCE_PRIORITY_MANIFEST_PATH
    )
    parameter_source_decision_manifest = _load_json(
        DEFAULT_PARAMETER_SOURCE_DECISION_MANIFEST_PATH
    )
    graph_scale_strategy_readiness_manifest = _load_json(
        DEFAULT_GRAPH_SCALE_STRATEGY_READINESS_MANIFEST_PATH
    )
    graph_scale_method_decision_manifest = _load_json(
        DEFAULT_GRAPH_SCALE_METHOD_DECISION_MANIFEST_PATH
    )
    validation_strategy_readiness_manifest = _load_json(
        DEFAULT_VALIDATION_STRATEGY_READINESS_MANIFEST_PATH
    )
    validation_benchmark_decision_manifest = _load_json(
        DEFAULT_VALIDATION_BENCHMARK_DECISION_MANIFEST_PATH
    )
    pilot_region_decision_manifest = _load_json(
        DEFAULT_PILOT_REGION_DECISION_MANIFEST_PATH
    )
    sensitivity_strategy_readiness_manifest = _load_json(
        DEFAULT_SENSITIVITY_STRATEGY_READINESS_MANIFEST_PATH
    )
    pilot_acceptance = summarize_pilot_acceptance()
    graph_scale_acceptance = summarize_graph_scale_acceptance()
    validation_acceptance = summarize_validation_acceptance()
    sensitivity_acceptance = summarize_sensitivity_acceptance()
    experiment_acceptance = summarize_experiment_acceptance()
    provenance_acceptance = summarize_provenance_acceptance()
    source_provenance = summarize_source_provenance_manifest()
    manuscript_acceptance = summarize_manuscript_acceptance()
    reproducibility_acceptance = summarize_reproducibility_acceptance()
    reproducibility_smoke = summarize_reproducibility_smoke()
    clean_checkout_smoke = summarize_clean_checkout_smoke()
    final_audit_acceptance = summarize_final_audit_acceptance()

    pre_final_gates = [
        _pilot_region_gate(pilot_acceptance, pilot_region_decision_manifest),
        _cached_osm_gate(
            road_audit,
            road_override_audit,
            road_override_application_audit,
            road_diagnostics=road_diagnostics,
            road_source_readiness_manifest=road_source_readiness_manifest,
            road_source_decision_manifest=road_source_decision_manifest,
            road_evidence_priority_manifest=road_evidence_priority_manifest,
            road_attribute_evidence_manifest=road_attribute_evidence_manifest,
        ),
        _real_input_smoke_gate(pilot_manifest),
        _graph_scale_gate(
            pilot_manifest,
            graph_scale_acceptance,
            graph_scale_strategy_readiness_manifest,
            graph_scale_method_decision_manifest,
        ),
        _data_provenance_gate(
            reproducibility_manifest,
            provenance_acceptance,
            source_provenance,
            source_url_review_manifest,
            source_url_remediation_manifest,
            source_provenance_priority_manifest,
            source_context_cache_request_manifest,
            source_context_cache_decision_manifest,
            source_provenance_decision_manifest,
        ),
        _parameter_gate(
            parameter_audit,
            parameter_source_readiness_manifest,
            parameter_evidence_priority_manifest,
            parameter_source_decision_manifest,
        ),
        _rail_gate(
            rail_service_audit,
            rail_station_audit,
            rail_fetch_readiness_manifest,
            rail_evidence_priority_manifest,
            rail_source_decision_manifest,
        ),
        _validation_gate(
            validation_acceptance,
            validation_strategy_readiness_manifest,
            validation_benchmark_decision_manifest,
        ),
        _structured_disruption_gate(),
        _policy_gate(),
        _sensitivity_gate(
            morris_manifest,
            sensitivity_acceptance,
            sensitivity_strategy_readiness_manifest,
        ),
        _full_experiment_gate(
            pilot_manifest,
            experiment_acceptance,
            experiment_package_review_manifest,
            experiment_strategy_readiness_manifest,
            experiment_design_decision_manifest,
        ),
        _manuscript_report_gate(
            figure_manifest,
            claim_alignment_manifest,
            figure_table_review_manifest,
            manuscript_report_decision_manifest,
            publication_audit,
            manuscript_acceptance,
        ),
        _reproducibility_gate(
            reproducibility_manifest,
            reproducibility_acceptance,
            reproducibility_review_manifest,
            reproducibility_decision_manifest,
            reproducibility_smoke,
            clean_checkout_smoke,
        ),
    ]
    gates = [
        *pre_final_gates,
        _final_audit_gate(
            pre_final_gates,
            final_audit_acceptance,
            final_audit_decision_manifest,
        ),
    ]
    gate_map = {gate["gate_id"]: gate for gate in gates}
    missing_gate_ids = [
        gate_id for gate_id in FINAL_GATE_IDS if gate_id not in gate_map
    ]
    final_ready = all(bool(gate["ready"]) for gate in gates) and not missing_gate_ids

    return {
        "final_study_ready": final_ready,
        "verdict": (
            "final_real_world_study_ready"
            if final_ready
            else "final_real_world_study_blocked"
        ),
        "claim_boundary": (
            "This audit checks plan-level final-study gates against current "
            "artifacts. Scaffold artifacts, passing tests, and generated "
            "figures are not sufficient unless every final gate is ready."
        ),
        "objective": (
            "Implement all plan.md requirements for a reproducible, "
            "real-world or quasi-real regional transport-resilience study "
            "without overclaiming operational accuracy."
        ),
        "gate_count": len(gates),
        "missing_gate_ids": missing_gate_ids,
        "ready_gate_ids": [gate["gate_id"] for gate in gates if gate["ready"]],
        "blocked_gate_ids": [gate["gate_id"] for gate in gates if not gate["ready"]],
        "gates": gates,
        "remaining_blockers": [
            f"{gate['label']}: {blocker}"
            for gate in gates
            for blocker in gate["blockers"]
        ],
    }


def _pilot_region_gate(
    pilot_acceptance: dict[str, Any],
    pilot_region_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    region_path = PROJECT_ROOT / "data" / "regions" / "pilot_region.yaml"
    data_card_path = PROJECT_ROOT / "docs" / "pilot_region_data_card.md"
    accepted = bool(pilot_acceptance["acceptance_ready"])
    decision = pilot_region_decision_manifest or {}
    decision_remaining_blockers = _list_value(
        pilot_region_decision_manifest,
        "remaining_blockers",
    )
    decision_blocking_count = _dict_int(
        pilot_region_decision_manifest,
        "blocking_decision_count",
    )
    decision_human_review_count = _dict_int(
        pilot_region_decision_manifest,
        "human_review_decision_count",
    )
    decision_artifacts_present = (
        DEFAULT_PILOT_REGION_DECISION_PACKET_PATH.exists()
        and DEFAULT_PILOT_REGION_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_PILOT_REGION_DECISION_DOC_PATH.exists()
    )
    blockers = [] if accepted else list(pilot_acceptance["remaining_blockers"])
    if not decision_artifacts_present:
        blockers.append("create pilot-region decision artifacts")
    if not accepted and decision_blocking_count:
        blockers.append(
            "resolve pilot-region decision blockers before pilot acceptance"
        )
        blockers.extend(
            f"pilot-region decision: {item}"
            for item in decision_remaining_blockers
        )
    if not accepted and decision_human_review_count:
        blockers.append(
            "review pilot-region decision human-decision items before pilot acceptance"
        )
    return _gate(
        "pilot_region_accepted",
        "Pilot Region Accepted",
        ready=accepted and decision_artifacts_present,
        artifact_present=(
            region_path.exists()
            and data_card_path.exists()
            and decision_artifacts_present
        ),
        evidence=[
            "data/regions/pilot_region.yaml",
            "docs/pilot_region_data_card.md",
            "data/manifests/pilot_privacy_review_packet.csv",
            "data/manifests/pilot_privacy_review_manifest.json",
            "docs/pilot_privacy_review_packet.md",
            "data/manifests/pilot_region_decision_packet.csv",
            "data/manifests/pilot_region_decision_manifest.json",
            "docs/pilot_region_decision_packet.md",
            "scripts/write_pilot_region_decision_packet.py",
            "data/manifests/pilot_acceptance.json",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": pilot_acceptance["record_present"],
            "acceptance_path": pilot_acceptance["path"],
            "pilot_privacy_review_packet_present": (
                PROJECT_ROOT / "data" / "manifests" / "pilot_privacy_review_packet.csv"
            ).exists(),
            "pilot_privacy_review_manifest_present": (
                PROJECT_ROOT / "data" / "manifests" / "pilot_privacy_review_manifest.json"
            ).exists(),
            "pilot_region_decision_artifacts_present": decision_artifacts_present,
            "pilot_region_decision_manifest_present": bool(
                pilot_region_decision_manifest
            ),
            "pilot_region_decision_row_count": decision.get("row_count", 0),
            "pilot_region_decision_blocking_decision_count": decision.get(
                "blocking_decision_count", 0
            ),
            "pilot_region_decision_human_review_decision_count": decision.get(
                "human_review_decision_count", 0
            ),
            "pilot_region_decision_status_counts": decision.get(
                "decision_status_counts", {}
            ),
            "pilot_region_decision_recorded": decision.get(
                "pilot_region_decision_recorded", False
            ),
            "pilot_region_decision_privacy_completion_recorded": decision.get(
                "privacy_completion_decision_recorded", False
            ),
            "pilot_region_decision_remaining_blockers": (
                decision_remaining_blockers
            ),
            "pilot_region_decision_publication_ready": decision.get(
                "publication_ready", False
            ),
            "pilot_region_decision_can_mark_complete": decision.get(
                "can_mark_complete", False
            ),
        },
    )


def _cached_osm_gate(
    road_audit: dict[str, Any],
    road_override_audit: dict[str, Any],
    road_override_application_audit: dict[str, Any],
    road_diagnostics: dict[str, Any] | None = None,
    road_source_readiness_manifest: dict[str, Any] | None = None,
    road_source_decision_manifest: dict[str, Any] | None = None,
    road_evidence_priority_manifest: dict[str, Any] | None = None,
    road_attribute_evidence_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    road_diagnostics = road_diagnostics or {
        "diagnostics_ready": True,
        "top_review_candidates": [],
        "remaining_blockers": [],
    }
    source_readiness = road_source_readiness_manifest or {}
    source_decision = road_source_decision_manifest or {}
    road_priority = road_evidence_priority_manifest or {}
    road_attribute = road_attribute_evidence_manifest or {}
    source_decision_artifacts_present = (
        DEFAULT_ROAD_SOURCE_DECISION_PACKET_PATH.exists()
        and DEFAULT_ROAD_SOURCE_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_ROAD_SOURCE_DECISION_DOC_PATH.exists()
    )
    road_priority_artifacts_present = (
        DEFAULT_ROAD_EVIDENCE_PRIORITY_PACKET_PATH.exists()
        and DEFAULT_ROAD_EVIDENCE_PRIORITY_MANIFEST_PATH.exists()
        and DEFAULT_ROAD_EVIDENCE_PRIORITY_DOC_PATH.exists()
    )
    road_attribute_evidence_artifacts_present = (
        DEFAULT_ROAD_ATTRIBUTE_EVIDENCE_PATH.exists()
        and DEFAULT_ROAD_ATTRIBUTE_EVIDENCE_MANIFEST_PATH.exists()
    )
    ready = bool(
        road_audit["publication_ready"]
        and road_override_audit["publication_ready"]
        and road_override_application_audit["publication_ready"]
    )
    blockers = [
        *[f"road input evidence: {item}" for item in road_audit["remaining_blockers"]],
        *[
            f"road diagnostics: {item}"
            for item in road_diagnostics["remaining_blockers"]
        ],
        *[
            f"road override evidence: {item}"
            for item in road_override_audit["remaining_blockers"]
        ],
        *[
            f"road override application: {item}"
            for item in road_override_application_audit["remaining_blockers"]
        ],
        *[
            f"road source readiness: {item}"
            for item in source_readiness.get("remaining_blockers", [])
        ],
        *[
            f"road source decision: {item}"
            for item in source_decision.get("remaining_blockers", [])
        ],
    ]
    return _gate(
        "cached_osm_input",
        "Cached OSM Input",
        ready=ready,
        artifact_present=bool(road_audit["edge_count"] > 0),
        evidence=[
            "data/cache/pilot_region_road.graphml",
            "data/cache/pilot_region_road_manifest.json",
            "scripts/audit_road_evidence.py",
            "scripts/audit_road_evidence_diagnostics.py",
            "data/parameters/road_speed_evidence_candidates.csv",
            "data/parameters/road_capacity_evidence_candidates.csv",
            "data/parameters/road_evidence_review_packet.csv",
            "data/parameters/road_evidence_review_manifest.json",
            "data/road/road_evidence_source_request_packet.csv",
            "data/road/road_evidence_source_request_manifest.json",
            "data/road/road_source_readiness_packet.csv",
            "data/road/road_source_readiness_manifest.json",
            "docs/road_source_readiness_packet.md",
            "data/road/road_source_decision_packet.csv",
            "data/road/road_source_decision_manifest.json",
            "docs/road_source_decision_packet.md",
            "data/road/road_evidence_priority_packet.csv",
            "data/road/road_evidence_priority_manifest.json",
            "docs/road_evidence_priority_packet.md",
            "scripts/write_road_speed_evidence.py",
            "scripts/write_road_capacity_evidence.py",
            "scripts/write_road_evidence_review_packet.py",
            "scripts/write_road_evidence_source_request_packet.py",
            "scripts/write_road_source_readiness_packet.py",
            "scripts/write_road_source_decision_packet.py",
            "scripts/write_road_evidence_priority_packet.py",
            "data/parameters/road_attribute_evidence_table.csv",
            "data/parameters/road_attribute_evidence_manifest.json",
            "scripts/write_road_attribute_evidence.py",
            "docs/road_attribute_evidence.md",
            "data/parameters/road_class_overrides_draft.csv",
            "scripts/write_road_class_override_template.py",
            "scripts/audit_road_overrides.py",
        ],
        blockers=[] if ready else blockers,
        details={
            "edge_count": road_audit["edge_count"],
            "routeable_edge_count": road_audit["routeable_edge_count"],
            "road_publication_ready": road_audit["publication_ready"],
            "road_diagnostics_ready": road_diagnostics["diagnostics_ready"],
            "road_diagnostics_top_review_candidates": [
                row["highway"]
                for row in road_diagnostics["top_review_candidates"][:5]
            ],
            "road_override_draft_table_present": road_override_audit.get(
                "draft_table_present",
                False,
            ),
            "road_override_draft_row_count": road_override_audit.get(
                "draft_row_count",
                0,
            ),
            "override_application_ready": road_override_application_audit[
                "publication_ready"
            ],
            "source_readiness_manifest_present": bool(road_source_readiness_manifest),
            "source_readiness_blocking_request_count": source_readiness.get(
                "blocking_request_count", 0
            ),
            "source_readiness_human_review_request_count": source_readiness.get(
                "human_review_request_count", 0
            ),
            "source_readiness_status_counts": source_readiness.get(
                "readiness_status_counts", {}
            ),
            "source_readiness_region_ids": list(
                _list_value(road_source_readiness_manifest, "region_ids")
            ),
            "source_readiness_source_url_or_citation_present_count": source_readiness.get(
                "source_url_or_citation_present_count", 0
            ),
            "source_readiness_required_external_input_present_count": source_readiness.get(
                "required_external_input_present_count", 0
            ),
            "source_readiness_remaining_blockers": source_readiness.get(
                "remaining_blockers", []
            ),
            "source_readiness_publication_ready": source_readiness.get(
                "publication_ready", False
            ),
            "source_readiness_can_mark_complete": source_readiness.get(
                "can_mark_complete", False
            ),
            "road_source_decision_artifacts_present": (
                source_decision_artifacts_present
            ),
            "road_source_decision_manifest_present": bool(
                road_source_decision_manifest
            ),
            "road_source_decision_row_count": source_decision.get("row_count", 0),
            "road_source_decision_blocking_decision_count": source_decision.get(
                "blocking_decision_count", 0
            ),
            "road_source_decision_human_review_decision_count": source_decision.get(
                "human_review_decision_count", 0
            ),
            "road_source_decision_status_counts": source_decision.get(
                "decision_status_counts", {}
            ),
            "road_source_decision_region_ids": list(
                _list_value(road_source_decision_manifest, "region_ids")
            ),
            "road_source_decision_recorded": source_decision.get(
                "road_source_decision_recorded", False
            ),
            "road_source_decision_road_class_overrides_present": source_decision.get(
                "road_class_overrides_present", False
            ),
            "road_source_decision_remaining_blockers": source_decision.get(
                "remaining_blockers", []
            ),
            "road_source_decision_publication_ready": source_decision.get(
                "publication_ready", False
            ),
            "road_source_decision_can_mark_complete": source_decision.get(
                "can_mark_complete", False
            ),
            "road_evidence_priority_artifacts_present": (
                road_priority_artifacts_present
            ),
            "road_evidence_priority_row_count": road_priority.get("row_count", 0),
            "road_evidence_priority_exposed_highway_count": road_priority.get(
                "exposed_highway_count", 0
            ),
            "road_evidence_priority_blocking_priority_count": road_priority.get(
                "blocking_priority_count", 0
            ),
            "road_evidence_priority_status_counts": road_priority.get(
                "priority_status_counts", {}
            ),
            "road_evidence_priority_publication_ready": road_priority.get(
                "publication_ready", False
            ),
            "road_evidence_priority_can_mark_complete": road_priority.get(
                "can_mark_complete", False
            ),
            "road_attribute_evidence_artifacts_present": (
                road_attribute_evidence_artifacts_present
            ),
            "road_attribute_evidence_manifest_present": bool(
                road_attribute_evidence_manifest
            ),
            "road_attribute_evidence_row_count": road_attribute.get("row_count", 0),
            "road_attribute_evidence_routeable_edge_count": road_attribute.get(
                "routeable_edge_count", 0
            ),
            "road_attribute_evidence_weak_for_final_claim_count": (
                road_attribute.get("weak_for_final_claim_count", 0)
            ),
            "road_attribute_evidence_status_counts": road_attribute.get(
                "evidence_status_counts", {}
            ),
            "road_attribute_evidence_speed_class_counts": road_attribute.get(
                "speed_evidence_class_counts", {}
            ),
            "road_attribute_evidence_capacity_class_counts": road_attribute.get(
                "capacity_evidence_class_counts", {}
            ),
            "road_attribute_evidence_disruption_class_counts": road_attribute.get(
                "base_disruption_evidence_class_counts", {}
            ),
            "road_attribute_evidence_publication_ready": road_attribute.get(
                "publication_ready", False
            ),
            "road_attribute_evidence_formal_acceptance_created": road_attribute.get(
                "formal_acceptance_created", False
            ),
            "road_attribute_evidence_can_mark_complete": road_attribute.get(
                "can_mark_complete", False
            ),
        },
    )


def _real_input_smoke_gate(pilot_manifest: dict[str, Any] | None) -> dict[str, Any]:
    policy_ids = set(_list_value(pilot_manifest, "policy_ids"))
    required = {"bus_only", "baseline_multimodal"}
    ready = bool(required <= policy_ids and pilot_manifest)
    return _gate(
        "real_input_smoke",
        "Real Input Smoke",
        ready=ready,
        artifact_present=bool(pilot_manifest),
        evidence=[
            "scripts/run_pilot_smoke.py",
            "scripts/run_full_graph_smoke.py",
            "data/validation/full_graph_smoke_manifest.json",
            "results/realworld_pilot/pilot_full_manifest.json",
        ],
        blockers=[] if ready else ["run cached-graph bus-only and multimodal smoke"],
    )


def _graph_scale_gate(
    pilot_manifest: dict[str, Any] | None,
    graph_scale_acceptance: dict[str, Any],
    graph_scale_strategy_readiness_manifest: dict[str, Any] | None = None,
    graph_scale_method_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    accepted = bool(graph_scale_acceptance["acceptance_ready"])
    readiness = graph_scale_strategy_readiness_manifest or {}
    method_decision = graph_scale_method_decision_manifest or {}
    readiness_remaining_blockers = _list_value(
        graph_scale_strategy_readiness_manifest,
        "remaining_blockers",
    )
    readiness_blocking_count = _dict_int(
        graph_scale_strategy_readiness_manifest,
        "blocking_request_count",
    )
    readiness_human_review_count = _dict_int(
        graph_scale_strategy_readiness_manifest,
        "human_review_request_count",
    )
    readiness_packet_path = (
        PROJECT_ROOT
        / "data"
        / "validation"
        / "graph_scale_strategy_readiness_packet.csv"
    )
    readiness_manifest_path = DEFAULT_GRAPH_SCALE_STRATEGY_READINESS_MANIFEST_PATH
    readiness_doc_path = (
        PROJECT_ROOT / "docs" / "graph_scale_strategy_readiness_packet.md"
    )
    readiness_artifacts_present = (
        readiness_packet_path.exists()
        and readiness_manifest_path.exists()
        and readiness_doc_path.exists()
    )
    method_decision_remaining_blockers = _list_value(
        graph_scale_method_decision_manifest,
        "remaining_blockers",
    )
    method_decision_blocking_count = _dict_int(
        graph_scale_method_decision_manifest,
        "blocking_decision_count",
    )
    method_decision_human_review_count = _dict_int(
        graph_scale_method_decision_manifest,
        "human_review_decision_count",
    )
    method_decision_artifacts_present = (
        DEFAULT_GRAPH_SCALE_METHOD_DECISION_PACKET_PATH.exists()
        and DEFAULT_GRAPH_SCALE_METHOD_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_GRAPH_SCALE_METHOD_DECISION_DOC_PATH.exists()
    )
    if not pilot_manifest:
        return _gate(
            "graph_scale_strategy",
            "Graph-Scale Strategy",
            ready=False,
            artifact_present=False,
            evidence=[
                "data/manifests/graph_scale_acceptance.json",
                "results/realworld_pilot/pilot_full_manifest.json",
            ],
            blockers=[
                "create a pilot full manifest with source and analysis graph scale",
                *([] if accepted else list(graph_scale_acceptance["remaining_blockers"])),
                *(
                    [
                        "resolve graph-scale strategy-readiness blockers before graph-scale acceptance"
                    ]
                    if readiness_blocking_count
                    else []
                ),
                *(
                    [
                        f"graph-scale strategy readiness: {item}"
                        for item in readiness_remaining_blockers
                    ]
                    if readiness_blocking_count
                    else []
                ),
                *(
                    [
                        "review graph-scale strategy-readiness human-decision items before graph-scale acceptance"
                    ]
                    if readiness_human_review_count
                    else []
                ),
                *(
                    [
                        "resolve graph-scale method-decision blockers before graph-scale acceptance"
                    ]
                    if method_decision_blocking_count
                    else []
                ),
                *(
                    [
                        f"graph-scale method decision: {item}"
                        for item in method_decision_remaining_blockers
                    ]
                    if method_decision_blocking_count
                    else []
                ),
                *(
                    [
                        "review graph-scale method-decision human-decision items before graph-scale acceptance"
                    ]
                    if method_decision_human_review_count
                    else []
                ),
            ],
            details={
                "acceptance_record_present": graph_scale_acceptance["record_present"],
                "acceptance_path": graph_scale_acceptance["path"],
                "strategy_readiness_manifest_present": bool(
                    graph_scale_strategy_readiness_manifest
                ),
                "strategy_readiness_blocking_request_count": readiness_blocking_count,
                "strategy_readiness_human_review_request_count": (
                    readiness_human_review_count
                ),
                "strategy_readiness_remaining_blockers": readiness_remaining_blockers,
                "method_decision_manifest_present": bool(
                    graph_scale_method_decision_manifest
                ),
                "method_decision_blocking_decision_count": (
                    method_decision_blocking_count
                ),
                "method_decision_human_review_decision_count": (
                    method_decision_human_review_count
                ),
                "method_decision_remaining_blockers": (
                    method_decision_remaining_blockers
                ),
            },
        )
    count_blockers = _graph_scale_count_blockers(
        pilot_manifest,
        graph_scale_acceptance,
    )
    blockers = [
        *([] if accepted else list(graph_scale_acceptance["remaining_blockers"])),
        *count_blockers,
    ]
    if not readiness_artifacts_present:
        blockers.append("create graph-scale strategy-readiness artifacts")
    if not method_decision_artifacts_present:
        blockers.append("create graph-scale method-decision artifacts")
    if not accepted and readiness_blocking_count:
        blockers.append(
            "resolve graph-scale strategy-readiness blockers before graph-scale acceptance"
        )
        blockers.extend(
            f"graph-scale strategy readiness: {item}"
            for item in readiness_remaining_blockers
        )
    if not accepted and readiness_human_review_count:
        blockers.append(
            "review graph-scale strategy-readiness human-decision items before graph-scale acceptance"
        )
    if not accepted and method_decision_blocking_count:
        blockers.append(
            "resolve graph-scale method-decision blockers before graph-scale acceptance"
        )
        blockers.extend(
            f"graph-scale method decision: {item}"
            for item in method_decision_remaining_blockers
        )
    if not accepted and method_decision_human_review_count:
        blockers.append(
            "review graph-scale method-decision human-decision items before graph-scale acceptance"
        )
    return _gate(
        "graph_scale_strategy",
        "Graph-Scale Strategy",
        ready=(
            accepted
            and not count_blockers
            and readiness_artifacts_present
            and method_decision_artifacts_present
        ),
        artifact_present=(
            "graph_scale" in pilot_manifest
            and readiness_artifacts_present
            and method_decision_artifacts_present
        ),
        evidence=[
            "data/manifests/graph_scale_acceptance.json",
            "docs/analysis_corridor_method_note.md",
            "docs/graph_scale_diagnostics.md",
            "data/validation/graph_scale_route_comparison.csv",
            "data/validation/graph_scale_route_comparison_summary.md",
            "data/validation/graph_scale_alternate_routes.csv",
            "data/validation/graph_scale_alternate_routes_summary.md",
            "data/validation/graph_scale_multi_corridor_routes.csv",
            "data/validation/graph_scale_multi_corridor_routes_summary.md",
            "data/validation/graph_scale_review_packet.csv",
            "data/validation/graph_scale_review_manifest.json",
            "data/validation/graph_scale_strategy_readiness_packet.csv",
            "data/validation/graph_scale_strategy_readiness_manifest.json",
            "docs/graph_scale_strategy_readiness_packet.md",
            "data/validation/graph_scale_method_decision_packet.csv",
            "data/validation/graph_scale_method_decision_manifest.json",
            "docs/graph_scale_method_decision_packet.md",
            "data/validation/graph_scale_manifest_audit.csv",
            "data/validation/graph_scale_manifest_audit_manifest.json",
            "docs/graph_scale_manifest_audit.md",
            "data/validation/full_graph_runtime_readiness_packet.csv",
            "data/validation/full_graph_runtime_readiness_manifest.json",
            "docs/full_graph_runtime_readiness_packet.md",
            "data/validation/graph_scale_result_comparison.csv",
            "data/validation/graph_scale_result_comparison_manifest.json",
            "scripts/audit_graph_scale_manifests.py",
            "scripts/write_graph_scale_review_packet.py",
            "scripts/write_graph_scale_strategy_readiness_packet.py",
            "scripts/write_graph_scale_method_decision_packet.py",
            "scripts/write_graph_scale_result_comparison.py",
            "scripts/run_graph_scale_diagnostics.py",
            "results/realworld_pilot/pilot_multi_corridor_results.csv",
            "results/realworld_pilot/pilot_multi_corridor_summary.csv",
            "results/realworld_pilot/pilot_multi_corridor_manifest.json",
            "results/realworld_pilot/pilot_multi_corridor_full_results.csv",
            "results/realworld_pilot/pilot_multi_corridor_full_summary.csv",
            "results/realworld_pilot/pilot_multi_corridor_full_manifest.json",
            "results/realworld_pilot/pilot_full_manifest.json",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": graph_scale_acceptance["record_present"],
            "acceptance_path": graph_scale_acceptance["path"],
            "acceptance_graph_scale_decision": graph_scale_acceptance.get(
                "graph_scale_decision", ""
            ),
            "acceptance_source_graph_nodes": graph_scale_acceptance.get(
                "source_graph_nodes"
            ),
            "acceptance_source_graph_edges": graph_scale_acceptance.get(
                "source_graph_edges"
            ),
            "acceptance_analysis_graph_nodes": graph_scale_acceptance.get(
                "analysis_graph_nodes"
            ),
            "acceptance_analysis_graph_edges": graph_scale_acceptance.get(
                "analysis_graph_edges"
            ),
            "analysis_graph_reduced": bool(pilot_manifest.get("analysis_graph_reduced")),
            "analysis_graph_strategy": pilot_manifest.get("analysis_graph_strategy", ""),
            "source_graph_nodes": pilot_manifest.get("source_graph_nodes"),
            "source_graph_edges": pilot_manifest.get("source_graph_edges"),
            "analysis_graph_nodes": pilot_manifest.get("graph_nodes"),
            "analysis_graph_edges": pilot_manifest.get("graph_edges"),
            "strategy_readiness_manifest_present": bool(
                graph_scale_strategy_readiness_manifest
            ),
            "strategy_readiness_blocking_request_count": readiness_blocking_count,
            "strategy_readiness_human_review_request_count": readiness_human_review_count,
            "strategy_readiness_status_counts": (
                readiness
            ).get("readiness_status_counts", {}),
            "strategy_readiness_remaining_blockers": readiness_remaining_blockers,
            "strategy_readiness_publication_ready": readiness.get(
                "publication_ready", False
            ),
            "strategy_readiness_can_mark_complete": readiness.get(
                "can_mark_complete", False
            ),
            "method_decision_artifacts_present": method_decision_artifacts_present,
            "method_decision_manifest_present": bool(
                graph_scale_method_decision_manifest
            ),
            "method_decision_row_count": method_decision.get("row_count", 0),
            "method_decision_blocking_decision_count": method_decision.get(
                "blocking_decision_count", 0
            ),
            "method_decision_human_review_decision_count": method_decision.get(
                "human_review_decision_count", 0
            ),
            "method_decision_status_counts": method_decision.get(
                "decision_status_counts", {}
            ),
            "method_decision_selected_graph_method_recorded": method_decision.get(
                "selected_graph_method_recorded", False
            ),
            "method_decision_downstream_regeneration_decision_recorded": (
                method_decision.get(
                    "downstream_regeneration_decision_recorded", False
                )
            ),
            "method_decision_remaining_blockers": method_decision_remaining_blockers,
            "method_decision_publication_ready": method_decision.get(
                "publication_ready", False
            ),
            "method_decision_can_mark_complete": method_decision.get(
                "can_mark_complete", False
            ),
        },
    )


def _graph_scale_count_blockers(
    pilot_manifest: dict[str, Any],
    graph_scale_acceptance: dict[str, Any],
) -> list[str]:
    if not graph_scale_acceptance.get("record_present"):
        return []
    comparisons = (
        (
            "source_graph_nodes",
            graph_scale_acceptance.get("source_graph_nodes"),
            pilot_manifest.get("source_graph_nodes"),
        ),
        (
            "source_graph_edges",
            graph_scale_acceptance.get("source_graph_edges"),
            pilot_manifest.get("source_graph_edges"),
        ),
        (
            "analysis_graph_nodes",
            graph_scale_acceptance.get("analysis_graph_nodes"),
            pilot_manifest.get("graph_nodes"),
        ),
        (
            "analysis_graph_edges",
            graph_scale_acceptance.get("analysis_graph_edges"),
            pilot_manifest.get("graph_edges"),
        ),
    )
    mismatches = [
        f"{label}: acceptance={accepted!r}, manifest={manifest!r}"
        for label, accepted, manifest in comparisons
        if accepted != manifest
    ]
    if not mismatches:
        return []
    return [
        "graph-scale acceptance counts must match the pilot full manifest counts: "
        + "; ".join(mismatches)
    ]


def _data_provenance_gate(
    reproducibility_manifest: dict[str, Any] | None,
    provenance_acceptance: dict[str, Any],
    source_provenance: dict[str, Any],
    source_url_review_manifest: dict[str, Any] | None = None,
    source_url_remediation_manifest: dict[str, Any] | None = None,
    source_provenance_priority_manifest: dict[str, Any] | None = None,
    source_context_cache_request_manifest: dict[str, Any] | None = None,
    source_context_cache_decision_manifest: dict[str, Any] | None = None,
    source_provenance_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    artifact_present = bool(reproducibility_manifest) and bool(
        source_provenance.get("manifest_present", False)
    )
    scope = str((reproducibility_manifest or {}).get("scope", ""))
    remaining = list((reproducibility_manifest or {}).get("remaining_upgrades", []))
    acceptance_ready = bool(provenance_acceptance["acceptance_ready"])
    source_provenance_ready = bool(source_provenance.get("diagnostics_ready", False))
    url_manifest = source_url_review_manifest or {}
    url_remediation_manifest = source_url_remediation_manifest or {}
    source_priority = source_provenance_priority_manifest or {}
    source_context_cache = source_context_cache_request_manifest or {}
    source_context_decision = source_context_cache_decision_manifest or {}
    provenance_decision = source_provenance_decision_manifest or {}
    source_priority_artifacts_present = (
        DEFAULT_SOURCE_PROVENANCE_PRIORITY_PACKET_PATH.exists()
        and DEFAULT_SOURCE_PROVENANCE_PRIORITY_MANIFEST_PATH.exists()
        and DEFAULT_SOURCE_PROVENANCE_PRIORITY_DOC_PATH.exists()
    )
    source_context_cache_artifacts_present = (
        DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_PACKET_PATH.exists()
        and DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_MANIFEST_PATH.exists()
        and DEFAULT_SOURCE_CONTEXT_CACHE_REQUEST_DOC_PATH.exists()
    )
    source_context_decision_artifacts_present = (
        DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_PACKET_PATH.exists()
        and DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_SOURCE_CONTEXT_CACHE_DECISION_DOC_PATH.exists()
    )
    source_provenance_decision_artifacts_present = (
        DEFAULT_SOURCE_PROVENANCE_DECISION_PACKET_PATH.exists()
        and DEFAULT_SOURCE_PROVENANCE_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_SOURCE_PROVENANCE_DECISION_DOC_PATH.exists()
    )
    provenance_decision_remaining_blockers = _list_value(
        source_provenance_decision_manifest,
        "remaining_blockers",
    )
    provenance_decision_blocking_count = _dict_int(
        source_provenance_decision_manifest,
        "blocking_decision_count",
    )
    provenance_decision_human_review_count = _dict_int(
        source_provenance_decision_manifest,
        "human_review_decision_count",
    )
    scope_blocked = "scaffold" in scope.lower()
    ready = (
        artifact_present
        and source_provenance_ready
        and acceptance_ready
        and not scope_blocked
        and not remaining
        and source_provenance_decision_artifacts_present
    )
    blockers: list[str] = []
    if not source_provenance_ready:
        blockers.extend(source_provenance.get("remaining_blockers", []))
    if not acceptance_ready:
        blockers.extend(provenance_acceptance["remaining_blockers"])
    if scope_blocked or remaining:
        blockers.append(
            "replace scaffold-only reproducibility manifest with accepted source/license/snapshot provenance"
        )
    blockers.extend(
        f"source provenance priority: {item}"
        for item in source_priority.get("remaining_blockers", [])
    )
    blockers.extend(
        f"source context cache request: {item}"
        for item in source_context_cache.get("remaining_blockers", [])
    )
    blockers.extend(
        f"source context cache decision: {item}"
        for item in source_context_decision.get("remaining_blockers", [])
    )
    if not source_provenance_decision_artifacts_present:
        blockers.append("create source-provenance decision artifacts")
    if not acceptance_ready and provenance_decision_blocking_count:
        blockers.append(
            "resolve source-provenance decision blockers before provenance acceptance"
        )
        blockers.extend(
            f"source provenance decision: {item}"
            for item in provenance_decision_remaining_blockers
        )
    if not acceptance_ready and provenance_decision_human_review_count:
        blockers.append(
            "review source-provenance decision human-decision items before provenance acceptance"
        )
    return _gate(
        "data_provenance",
        "Data Provenance",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/provenance_acceptance.json",
            "data/manifests/source_provenance_manifest.json",
            "data/manifests/source_license_review_packet.csv",
            "data/manifests/source_license_review_manifest.json",
            "data/manifests/source_url_review_packet.csv",
            "data/manifests/source_url_review_manifest.json",
            "data/manifests/source_url_remediation_packet.csv",
            "data/manifests/source_url_remediation_manifest.json",
            "data/manifests/source_provenance_priority_packet.csv",
            "data/manifests/source_provenance_priority_manifest.json",
            "data/manifests/source_context_cache_request_packet.csv",
            "data/manifests/source_context_cache_request_manifest.json",
            "data/manifests/source_context_cache_decision_packet.csv",
            "data/manifests/source_context_cache_decision_manifest.json",
            "data/manifests/source_provenance_decision_packet.csv",
            "data/manifests/source_provenance_decision_manifest.json",
            "data/manifests/reproducibility_manifest.json",
            "docs/source_license_review_packet.md",
            "docs/source_url_review_packet.md",
            "docs/source_url_remediation_packet.md",
            "docs/source_provenance_priority_packet.md",
            "docs/source_context_cache_request_packet.md",
            "docs/source_context_cache_decision_packet.md",
            "docs/source_provenance_decision_packet.md",
            "docs/reproducibility_package.md",
            "docs/pilot_region_data_card.md",
            "scripts/audit_source_provenance.py",
            "scripts/write_source_license_review_packet.py",
            "scripts/write_source_url_review_packet.py",
            "scripts/write_source_url_remediation_packet.py",
            "scripts/write_source_provenance_priority_packet.py",
            "scripts/write_source_context_cache_request_packet.py",
            "scripts/write_source_context_cache_decision_packet.py",
            "scripts/write_source_provenance_decision_packet.py",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": provenance_acceptance["record_present"],
            "acceptance_path": provenance_acceptance["path"],
            "source_provenance_manifest_present": source_provenance.get(
                "manifest_present",
                False,
            ),
            "source_provenance_path": source_provenance.get("path", ""),
            "source_provenance_record_count": source_provenance.get("record_count", 0),
            "source_provenance_review_status_counts": source_provenance.get(
                "review_status_counts",
                {},
            ),
            "source_license_review_packet_present": (
                PROJECT_ROOT / "data" / "manifests" / "source_license_review_packet.csv"
            ).exists(),
            "source_license_review_manifest_present": (
                PROJECT_ROOT / "data" / "manifests" / "source_license_review_manifest.json"
            ).exists(),
            "source_url_review_packet_present": (
                PROJECT_ROOT / "data" / "manifests" / "source_url_review_packet.csv"
            ).exists(),
            "source_url_review_manifest_present": (
                PROJECT_ROOT / "data" / "manifests" / "source_url_review_manifest.json"
            ).exists(),
            "source_url_live_check_performed": url_manifest.get(
                "live_check_performed",
                False,
            ),
            "source_url_status_counts": url_manifest.get("url_status_counts", {}),
            "source_url_unreachable_or_error_count": url_manifest.get(
                "unreachable_or_error_count",
                0,
            ),
            "source_url_publication_ready": url_manifest.get(
                "publication_ready",
                False,
            ),
            "source_url_can_mark_complete": url_manifest.get(
                "can_mark_complete",
                False,
            ),
            "source_url_remediation_manifest_present": (
                PROJECT_ROOT
                / "data"
                / "manifests"
                / "source_url_remediation_manifest.json"
            ).exists(),
            "source_url_remediation_row_count": url_remediation_manifest.get(
                "row_count",
                0,
            ),
            "source_url_remediation_status_counts": url_remediation_manifest.get(
                "remediation_status_counts",
                {},
            ),
            "source_url_remediation_blocking_issue_count": url_remediation_manifest.get(
                "blocking_issue_count",
                0,
            ),
            "source_url_remediation_live_check_required_count": url_remediation_manifest.get(
                "live_check_required_count",
                0,
            ),
            "source_url_remediation_publication_ready": url_remediation_manifest.get(
                "publication_ready",
                False,
            ),
            "source_url_remediation_can_mark_complete": url_remediation_manifest.get(
                "can_mark_complete",
                False,
            ),
            "source_provenance_priority_artifacts_present": (
                source_priority_artifacts_present
            ),
            "source_provenance_priority_row_count": source_priority.get(
                "row_count",
                0,
            ),
            "source_provenance_priority_blocking_source_count": source_priority.get(
                "blocking_source_count",
                0,
            ),
            "source_provenance_priority_human_review_source_count": source_priority.get(
                "human_review_source_count",
                0,
            ),
            "source_provenance_priority_context_only_source_count": source_priority.get(
                "context_only_source_count",
                0,
            ),
            "source_provenance_priority_cached_snapshot_source_count": (
                source_priority.get("cached_snapshot_source_count", 0)
            ),
            "source_provenance_priority_repository_input_source_count": (
                source_priority.get("repository_input_source_count", 0)
            ),
            "source_provenance_priority_status_counts": source_priority.get(
                "priority_status_counts",
                {},
            ),
            "source_provenance_priority_publication_ready": source_priority.get(
                "publication_ready",
                False,
            ),
            "source_provenance_priority_can_mark_complete": source_priority.get(
                "can_mark_complete",
                False,
            ),
            "source_context_cache_request_artifacts_present": (
                source_context_cache_artifacts_present
            ),
            "source_context_cache_request_row_count": source_context_cache.get(
                "row_count",
                0,
            ),
            "source_context_cache_request_blocking_request_count": (
                source_context_cache.get("blocking_request_count", 0)
            ),
            "source_context_cache_request_missing_target_cache_artifact_count": (
                source_context_cache.get("missing_target_cache_artifact_count", 0)
            ),
            "source_context_cache_request_status_counts": source_context_cache.get(
                "cache_request_status_counts",
                {},
            ),
            "source_context_cache_request_publication_ready": source_context_cache.get(
                "publication_ready",
                False,
            ),
            "source_context_cache_request_can_mark_complete": source_context_cache.get(
                "can_mark_complete",
                False,
            ),
            "source_context_cache_decision_artifacts_present": (
                source_context_decision_artifacts_present
            ),
            "source_context_cache_decision_row_count": source_context_decision.get(
                "row_count",
                0,
            ),
            "source_context_cache_decision_blocking_decision_count": (
                source_context_decision.get("blocking_decision_count", 0)
            ),
            "source_context_cache_decision_human_review_decision_count": (
                source_context_decision.get("human_review_decision_count", 0)
            ),
            "source_context_cache_decision_status_counts": (
                source_context_decision.get("decision_status_counts", {})
            ),
            "source_context_cache_decision_recorded": source_context_decision.get(
                "cache_retention_or_exclusion_decision_recorded",
                False,
            ),
            "source_context_cache_decision_publication_ready": (
                source_context_decision.get("publication_ready", False)
            ),
            "source_context_cache_decision_can_mark_complete": (
                source_context_decision.get("can_mark_complete", False)
            ),
            "source_provenance_decision_artifacts_present": (
                source_provenance_decision_artifacts_present
            ),
            "source_provenance_decision_manifest_present": bool(
                source_provenance_decision_manifest
            ),
            "source_provenance_decision_row_count": provenance_decision.get(
                "row_count",
                0,
            ),
            "source_provenance_decision_blocking_decision_count": (
                provenance_decision.get("blocking_decision_count", 0)
            ),
            "source_provenance_decision_human_review_decision_count": (
                provenance_decision.get("human_review_decision_count", 0)
            ),
            "source_provenance_decision_status_counts": provenance_decision.get(
                "decision_status_counts",
                {},
            ),
            "source_provenance_decision_recorded": provenance_decision.get(
                "provenance_decision_recorded",
                False,
            ),
            "source_provenance_decision_context_cache_retention_or_exclusion_recorded": (
                provenance_decision.get(
                    "context_cache_retention_or_exclusion_decision_recorded",
                    False,
                )
            ),
            "source_provenance_decision_remaining_blockers": (
                provenance_decision_remaining_blockers
            ),
            "source_provenance_decision_publication_ready": provenance_decision.get(
                "publication_ready",
                False,
            ),
            "source_provenance_decision_can_mark_complete": provenance_decision.get(
                "can_mark_complete",
                False,
            ),
            "scope": scope,
            "remaining_upgrade_count": len(remaining),
        },
    )


def _parameter_gate(
    parameter_audit: dict[str, Any],
    parameter_source_readiness_manifest: dict[str, Any] | None = None,
    parameter_evidence_priority_manifest: dict[str, Any] | None = None,
    parameter_source_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return the parameter-evidence gate with source-readiness detail."""

    ready = bool(parameter_audit["publication_ready"])
    readiness = parameter_source_readiness_manifest or {}
    priority = parameter_evidence_priority_manifest or {}
    decisions = parameter_source_decision_manifest or {}
    priority_artifacts_present = (
        DEFAULT_PARAMETER_EVIDENCE_PRIORITY_PACKET_PATH.exists()
        and DEFAULT_PARAMETER_EVIDENCE_PRIORITY_MANIFEST_PATH.exists()
        and DEFAULT_PARAMETER_EVIDENCE_PRIORITY_DOC_PATH.exists()
    )
    decision_artifacts_present = (
        DEFAULT_PARAMETER_SOURCE_DECISION_PACKET_PATH.exists()
        and DEFAULT_PARAMETER_SOURCE_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_PARAMETER_SOURCE_DECISION_DOC_PATH.exists()
    )
    transfer_artifacts_present = (
        DEFAULT_TRANSFER_EVIDENCE_REVIEW_PACKET_PATH.exists()
        and DEFAULT_TRANSFER_EVIDENCE_REVIEW_MANIFEST_PATH.exists()
        and DEFAULT_TRANSFER_EVIDENCE_REVIEW_DOC_PATH.exists()
    )
    blockers = []
    if not ready:
        blockers.extend(parameter_audit.get("remaining_blockers", []))
        blockers.extend(
            f"parameter source readiness: {item}"
            for item in readiness.get("remaining_blockers", [])
        )
        blockers.extend(
            f"parameter evidence priority: {item}"
            for item in priority.get("remaining_blockers", [])
        )
        blockers.extend(
            f"parameter source decision: {item}"
            for item in decisions.get("remaining_blockers", [])
        )
    return _gate(
        "parameter_evidence",
        "Parameter Evidence",
        ready=ready,
        artifact_present=True,
        evidence=[
            "data/parameters/parameter_sources.csv",
            "data/parameters/parameter_evidence_review_packet.csv",
            "data/parameters/parameter_evidence_review_manifest.json",
            "data/parameters/transfer_evidence_review_packet.csv",
            "data/parameters/transfer_evidence_review_manifest.json",
            "docs/transfer_evidence_review_packet.md",
            "data/parameters/parameter_evidence_source_request_packet.csv",
            "data/parameters/parameter_evidence_source_request_manifest.json",
            "data/parameters/parameter_source_readiness_packet.csv",
            "data/parameters/parameter_source_readiness_manifest.json",
            "docs/parameter_source_readiness_packet.md",
            "data/parameters/parameter_evidence_priority_packet.csv",
            "data/parameters/parameter_evidence_priority_manifest.json",
            "docs/parameter_evidence_priority_packet.md",
            "data/parameters/parameter_source_decision_packet.csv",
            "data/parameters/parameter_source_decision_manifest.json",
            "docs/parameter_source_decision_packet.md",
            "scripts/audit_parameter_evidence.py",
            "scripts/write_transfer_evidence_review_packet.py",
            "scripts/write_parameter_review_packet.py",
            "scripts/write_parameter_evidence_source_request_packet.py",
            "scripts/write_parameter_source_readiness_packet.py",
            "scripts/write_parameter_evidence_priority_packet.py",
            "scripts/write_parameter_source_decision_packet.py",
        ],
        blockers=blockers,
        details={
            "parameter_publication_ready": parameter_audit["publication_ready"],
            "source_readiness_manifest_present": bool(
                parameter_source_readiness_manifest
            ),
            "source_readiness_blocking_request_count": readiness.get(
                "blocking_request_count",
                0,
            ),
            "source_readiness_human_review_request_count": readiness.get(
                "human_review_request_count",
                0,
            ),
            "source_readiness_status_counts": readiness.get(
                "readiness_status_counts",
                {},
            ),
            "source_readiness_region_ids": list(
                _list_value(parameter_source_readiness_manifest, "region_ids")
            ),
            "source_readiness_source_url_or_citation_present_count": readiness.get(
                "source_url_or_citation_present_count",
                0,
            ),
            "source_readiness_required_external_input_present_count": readiness.get(
                "required_external_input_present_count",
                0,
            ),
            "source_readiness_remaining_blockers": readiness.get(
                "remaining_blockers",
                [],
            ),
            "source_readiness_publication_ready": readiness.get(
                "publication_ready",
                False,
            ),
            "source_readiness_can_mark_complete": readiness.get(
                "can_mark_complete",
                False,
            ),
            "parameter_evidence_priority_artifacts_present": (
                priority_artifacts_present
            ),
            "parameter_evidence_priority_row_count": priority.get("row_count", 0),
            "parameter_evidence_priority_blocking_priority_count": priority.get(
                "blocking_priority_count",
                0,
            ),
            "parameter_evidence_priority_human_review_priority_count": priority.get(
                "human_review_priority_count",
                0,
            ),
            "parameter_evidence_priority_high_priority_parameter_count": priority.get(
                "high_priority_parameter_count",
                0,
            ),
            "parameter_evidence_priority_medium_priority_parameter_count": priority.get(
                "medium_priority_parameter_count",
                0,
            ),
            "parameter_evidence_priority_status_counts": priority.get(
                "priority_status_counts",
                {},
            ),
            "parameter_evidence_priority_publication_ready": priority.get(
                "publication_ready",
                False,
            ),
            "parameter_evidence_priority_can_mark_complete": priority.get(
                "can_mark_complete",
                False,
            ),
            "transfer_evidence_review_artifacts_present": transfer_artifacts_present,
            "parameter_source_decision_artifacts_present": (
                decision_artifacts_present
            ),
            "parameter_source_decision_row_count": decisions.get("row_count", 0),
            "parameter_source_decision_blocking_decision_count": decisions.get(
                "blocking_decision_count",
                0,
            ),
            "parameter_source_decision_human_review_decision_count": decisions.get(
                "human_review_decision_count",
                0,
            ),
            "parameter_source_decision_status_counts": decisions.get(
                "decision_status_counts",
                {},
            ),
            "parameter_source_decision_recorded": decisions.get(
                "parameter_source_decision_recorded",
                False,
            ),
            "parameter_source_decision_publication_ready": decisions.get(
                "publication_ready",
                False,
            ),
            "parameter_source_decision_can_mark_complete": decisions.get(
                "can_mark_complete",
                False,
            ),
        },
    )


def _evidence_gate(
    *,
    gate_id: str,
    label: str,
    audit: dict[str, Any],
    ready_key: str,
    evidence: list[str],
) -> dict[str, Any]:
    ready = bool(audit[ready_key])
    return _gate(
        gate_id,
        label,
        ready=ready,
        artifact_present=True,
        evidence=evidence,
        blockers=[] if ready else list(audit.get("remaining_blockers", [])),
    )


def _rail_gate(
    rail_service_audit: dict[str, Any],
    rail_station_audit: dict[str, Any],
    rail_fetch_readiness_manifest: dict[str, Any] | None = None,
    rail_evidence_priority_manifest: dict[str, Any] | None = None,
    rail_source_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ready = bool(
        rail_service_audit["publication_ready"] and rail_station_audit["binding_ready"]
    )
    blockers = [
        *[
            f"rail service evidence: {item}"
            for item in rail_service_audit["remaining_blockers"]
        ],
        *[
            f"rail station binding: {item}"
            for item in rail_station_audit["remaining_blockers"]
        ],
    ]
    fetch_readiness = rail_fetch_readiness_manifest or {}
    rail_priority = rail_evidence_priority_manifest or {}
    rail_decisions = rail_source_decision_manifest or {}
    rail_priority_artifacts_present = (
        DEFAULT_RAIL_EVIDENCE_PRIORITY_PACKET_PATH.exists()
        and DEFAULT_RAIL_EVIDENCE_PRIORITY_MANIFEST_PATH.exists()
        and DEFAULT_RAIL_EVIDENCE_PRIORITY_DOC_PATH.exists()
    )
    rail_decision_artifacts_present = (
        DEFAULT_RAIL_SOURCE_DECISION_PACKET_PATH.exists()
        and DEFAULT_RAIL_SOURCE_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_RAIL_SOURCE_DECISION_DOC_PATH.exists()
    )
    blockers.extend(
        f"rail fetch readiness: {item}"
        for item in fetch_readiness.get("remaining_blockers", [])
    )
    blockers.extend(
        f"rail evidence priority: {item}"
        for item in rail_priority.get("remaining_blockers", [])
    )
    blockers.extend(
        f"rail source decision: {item}"
        for item in rail_decisions.get("remaining_blockers", [])
    )
    return _gate(
        "rail_evidence",
        "Rail Evidence",
        ready=ready,
        artifact_present=True,
        evidence=[
            "data/parameters/rail_service_evidence.csv",
            "data/parameters/rail_station_bindings.csv",
            "data/parameters/rail_evidence_review_packet.csv",
            "data/parameters/rail_evidence_review_manifest.json",
            "data/rail/rail_timing_source_request_packet.csv",
            "data/rail/rail_timing_source_request_manifest.json",
            "data/rail/rail_fetch_readiness_packet.csv",
            "data/rail/rail_fetch_readiness_manifest.json",
            "docs/rail_fetch_readiness_packet.md",
            "data/rail/rail_evidence_priority_packet.csv",
            "data/rail/rail_evidence_priority_manifest.json",
            "docs/rail_evidence_priority_packet.md",
            "data/rail/rail_source_decision_packet.csv",
            "data/rail/rail_source_decision_manifest.json",
            "docs/rail_source_decision_packet.md",
            "scripts/audit_rail_evidence.py",
            "scripts/write_rail_evidence_review_packet.py",
            "scripts/write_rail_timing_source_request_packet.py",
            "scripts/write_rail_fetch_readiness_packet.py",
            "scripts/write_rail_evidence_priority_packet.py",
            "scripts/write_rail_source_decision_packet.py",
            "scripts/fetch_rail_timetable_cache.py",
            "scripts/derive_rail_headway_evidence.py",
            "scripts/derive_rail_service_evidence.py",
            "scripts/derive_rail_gtfs_evidence.py",
            "docs/schemas/rail_gtfs_cache_schema.md",
            "scripts/fetch_rail_shortest_path_cache.py",
            "scripts/derive_rail_shortest_path_evidence.py",
        ],
        blockers=[] if ready else blockers,
        details={
            "service_publication_ready": rail_service_audit["publication_ready"],
            "station_binding_ready": rail_station_audit["binding_ready"],
            "fetch_readiness_manifest_present": bool(rail_fetch_readiness_manifest),
            "fetch_readiness_blocking_request_count": fetch_readiness.get(
                "blocking_request_count", 0
            ),
            "fetch_readiness_status_counts": fetch_readiness.get(
                "readiness_status_counts", {}
            ),
            "fetch_readiness_region_ids": list(
                _list_value(rail_fetch_readiness_manifest, "region_ids")
            ),
            "fetch_readiness_source_url_or_citation_present_count": fetch_readiness.get(
                "source_url_or_citation_present_count", 0
            ),
            "fetch_readiness_required_external_input_present_count": fetch_readiness.get(
                "required_external_input_present_count", 0
            ),
            "fetch_readiness_remaining_blockers": fetch_readiness.get(
                "remaining_blockers", []
            ),
            "fetch_readiness_publication_ready": fetch_readiness.get(
                "publication_ready", False
            ),
            "fetch_readiness_can_mark_complete": fetch_readiness.get(
                "can_mark_complete", False
            ),
            "rail_evidence_priority_artifacts_present": (
                rail_priority_artifacts_present
            ),
            "rail_evidence_priority_row_count": rail_priority.get("row_count", 0),
            "rail_evidence_priority_blocking_priority_count": rail_priority.get(
                "blocking_priority_count", 0
            ),
            "rail_evidence_priority_human_review_priority_count": rail_priority.get(
                "human_review_priority_count", 0
            ),
            "rail_evidence_priority_timing_closure_candidate_count": (
                rail_priority.get("timing_closure_candidate_count", 0)
            ),
            "rail_evidence_priority_status_counts": rail_priority.get(
                "readiness_status_counts", {}
            ),
            "rail_evidence_priority_publication_ready": rail_priority.get(
                "publication_ready", False
            ),
            "rail_evidence_priority_can_mark_complete": rail_priority.get(
                "can_mark_complete", False
            ),
            "rail_source_decision_artifacts_present": (
                rail_decision_artifacts_present
            ),
            "rail_source_decision_manifest_present": bool(
                rail_source_decision_manifest
            ),
            "rail_source_decision_row_count": rail_decisions.get("row_count", 0),
            "rail_source_decision_blocking_decision_count": rail_decisions.get(
                "blocking_decision_count", 0
            ),
            "rail_source_decision_human_review_decision_count": rail_decisions.get(
                "human_review_decision_count", 0
            ),
            "rail_source_decision_timing_source_decision_count": rail_decisions.get(
                "timing_source_decision_count", 0
            ),
            "rail_source_decision_status_counts": rail_decisions.get(
                "decision_status_counts", {}
            ),
            "rail_source_decision_region_ids": list(
                _list_value(rail_source_decision_manifest, "region_ids")
            ),
            "rail_source_decision_recorded": rail_decisions.get(
                "rail_source_decision_recorded", False
            ),
            "rail_source_decision_publication_ready": rail_decisions.get(
                "publication_ready", False
            ),
            "rail_source_decision_can_mark_complete": rail_decisions.get(
                "can_mark_complete", False
            ),
            "rail_source_decision_remaining_blockers": rail_decisions.get(
                "remaining_blockers", []
            ),
        },
    )


def _validation_gate(
    validation_acceptance: dict[str, Any],
    validation_strategy_readiness_manifest: dict[str, Any] | None = None,
    validation_benchmark_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    summary_path = PROJECT_ROOT / "data" / "validation" / "validation_summary.md"
    review_manifest_path = (
        PROJECT_ROOT / "data" / "validation" / "validation_review_manifest.json"
    )
    osrm_summary_path = (
        PROJECT_ROOT / "data" / "validation" / "osrm_route_benchmark_summary.md"
    )
    osrm_manifest_path = (
        PROJECT_ROOT / "data" / "validation" / "osrm_route_benchmark_manifest.json"
    )
    accessibility_path = (
        PROJECT_ROOT / "data" / "validation" / "accessibility_loss.csv"
    )
    accessibility_summary_path = (
        PROJECT_ROOT / "data" / "validation" / "accessibility_loss_summary.md"
    )
    route_exposure_path = (
        PROJECT_ROOT
        / "data"
        / "validation"
        / "canonical_route_road_evidence_exposure.csv"
    )
    route_exposure_manifest_path = (
        PROJECT_ROOT
        / "data"
        / "validation"
        / "canonical_route_road_evidence_exposure_manifest.json"
    )
    strategy_readiness_packet_path = (
        PROJECT_ROOT / "data" / "validation" / "validation_strategy_readiness_packet.csv"
    )
    strategy_readiness_manifest_path = (
        PROJECT_ROOT
        / "data"
        / "validation"
        / "validation_strategy_readiness_manifest.json"
    )
    strategy_readiness_doc_path = (
        PROJECT_ROOT / "docs" / "validation_strategy_readiness_packet.md"
    )
    benchmark_readiness_packet_path = (
        PROJECT_ROOT / "data" / "validation" / "validation_benchmark_readiness_packet.csv"
    )
    benchmark_readiness_manifest_path = (
        PROJECT_ROOT
        / "data"
        / "validation"
        / "validation_benchmark_readiness_manifest.json"
    )
    benchmark_readiness_doc_path = (
        PROJECT_ROOT / "docs" / "validation_benchmark_readiness_packet.md"
    )
    benchmark_decision_packet_path = DEFAULT_VALIDATION_BENCHMARK_DECISION_PACKET_PATH
    benchmark_decision_manifest_path = DEFAULT_VALIDATION_BENCHMARK_DECISION_MANIFEST_PATH
    benchmark_decision_doc_path = DEFAULT_VALIDATION_BENCHMARK_DECISION_DOC_PATH
    text = _read_text(summary_path)
    review_manifest = _load_json(review_manifest_path)
    osrm_manifest = _load_json(osrm_manifest_path)
    artifact_present = (
        summary_path.exists()
        and osrm_summary_path.exists()
        and osrm_manifest_path.exists()
        and accessibility_path.exists()
        and accessibility_summary_path.exists()
        and route_exposure_path.exists()
        and route_exposure_manifest_path.exists()
        and strategy_readiness_packet_path.exists()
        and strategy_readiness_manifest_path.exists()
        and strategy_readiness_doc_path.exists()
        and benchmark_readiness_packet_path.exists()
        and benchmark_readiness_manifest_path.exists()
        and benchmark_readiness_doc_path.exists()
        and benchmark_decision_packet_path.exists()
        and benchmark_decision_manifest_path.exists()
        and benchmark_decision_doc_path.exists()
    )
    acceptance_ready = bool(validation_acceptance["acceptance_ready"])
    summary_scope_blocked = _validation_summary_scope_is_blocked(text)
    ready = artifact_present and acceptance_ready and not summary_scope_blocked
    blockers: list[str] = []
    if not artifact_present:
        blockers.append(
            "create validation summary, benchmark summary, and strategy-readiness artifacts"
        )
    if not acceptance_ready:
        blockers.extend(validation_acceptance["remaining_blockers"])
        strategy_blocking_count = _dict_int(
            validation_strategy_readiness_manifest,
            "blocking_request_count",
        )
        strategy_human_review_count = _dict_int(
            validation_strategy_readiness_manifest,
            "human_review_request_count",
        )
        if strategy_blocking_count:
            blockers.append(
                "resolve validation strategy-readiness blockers before validation acceptance"
            )
            blockers.extend(
                f"validation strategy readiness: {item}"
                for item in _list_value(
                    validation_strategy_readiness_manifest,
                    "remaining_blockers",
                )
            )
        if strategy_human_review_count:
            blockers.append(
                "review validation strategy-readiness human-decision items before validation acceptance"
            )
        decision_blocking_count = _dict_int(
            validation_benchmark_decision_manifest,
            "blocking_decision_count",
        )
        decision_human_review_count = _dict_int(
            validation_benchmark_decision_manifest,
            "human_review_decision_count",
        )
        if decision_blocking_count:
            blockers.append(
                "resolve validation benchmark-decision blockers before validation acceptance"
            )
            blockers.extend(
                f"validation benchmark decision: {item}"
                for item in _list_value(
                    validation_benchmark_decision_manifest,
                    "remaining_blockers",
                )
            )
        if decision_human_review_count:
            blockers.append(
                "review validation benchmark-decision human-decision items before validation acceptance"
            )
    if summary_scope_blocked:
        blockers.append(
            "revise validation summary from scaffold/sanity evidence to accepted publication-level validation scope after review"
        )
    return _gate(
        "validation_package",
        "Validation Package",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/validation_acceptance.json",
            "data/validation/validation_summary.md",
            "data/validation/external_route_benchmarks.csv",
            "data/validation/external_route_benchmarks_osrm.csv",
            "data/validation/osrm_route_benchmark_manifest.json",
            "data/validation/accessibility_loss.csv",
            "data/validation/accessibility_loss_summary.md",
            "data/validation/canonical_route_road_evidence_exposure.csv",
            "data/validation/canonical_route_road_evidence_exposure_manifest.json",
            "data/validation/validation_review_packet.csv",
            "data/validation/validation_review_manifest.json",
            "data/validation/validation_strategy_readiness_packet.csv",
            "data/validation/validation_strategy_readiness_manifest.json",
            "docs/validation_strategy_readiness_packet.md",
            "data/validation/validation_benchmark_readiness_packet.csv",
            "data/validation/validation_benchmark_readiness_manifest.json",
            "docs/validation_benchmark_readiness_packet.md",
            "data/validation/validation_benchmark_decision_packet.csv",
            "data/validation/validation_benchmark_decision_manifest.json",
            "docs/validation_benchmark_decision_packet.md",
            "scripts/run_plausibility_validation.py",
            "scripts/run_accessibility_loss_analysis.py",
            "scripts/write_route_road_evidence_exposure.py",
            "scripts/run_osrm_route_benchmark.py",
            "scripts/write_osrm_snapshot_manifest.py",
            "scripts/write_validation_benchmark_readiness_packet.py",
            "scripts/write_validation_benchmark_decision_packet.py",
            "scripts/write_validation_review_packet.py",
            "scripts/write_validation_strategy_readiness_packet.py",
        ],
        blockers=[] if ready else blockers,
        details={
            "acceptance_record_present": validation_acceptance["record_present"],
            "acceptance_path": validation_acceptance["path"],
            "benchmark_strategy": validation_acceptance.get("benchmark_strategy", ""),
            "summary_scope_blocked": summary_scope_blocked,
            "review_packet_row_count": _dict_int(review_manifest, "row_count"),
            "route_road_evidence_exposure_row_count": _dict_int(
                review_manifest,
                "route_road_evidence_exposure_row_count",
            ),
            "review_packet_publication_ready": bool(
                review_manifest.get("publication_ready", False)
            )
            if review_manifest
            else False,
            "review_packet_acceptance_gate_closure_candidate_count": _dict_int(
                review_manifest,
                "acceptance_gate_closure_candidate_count",
            ),
            "review_packet_osrm_present": bool(
                review_manifest.get("optional_osrm_benchmark_present", False)
            )
            if review_manifest
            else False,
            "review_packet_osrm_manifest_present": bool(
                review_manifest.get(
                    "optional_osrm_benchmark_manifest_present",
                    False,
                )
            )
            if review_manifest
            else False,
            "review_packet_osrm_unpinned_row_count": _dict_int(
                review_manifest,
                "optional_osrm_benchmark_unpinned_row_count",
            ),
            "osrm_raw_response_file_count": _dict_int(
                osrm_manifest,
                "raw_response_file_count",
            ),
            "osrm_unpinned_row_count": _dict_int(
                osrm_manifest,
                "unpinned_row_count",
            ),
            "strategy_readiness_manifest_present": bool(
                validation_strategy_readiness_manifest
            ),
            "strategy_readiness_blocking_request_count": (
                validation_strategy_readiness_manifest or {}
            ).get("blocking_request_count", 0),
            "strategy_readiness_human_review_request_count": (
                validation_strategy_readiness_manifest or {}
            ).get("human_review_request_count", 0),
            "strategy_readiness_status_counts": (
                validation_strategy_readiness_manifest or {}
            ).get("readiness_status_counts", {}),
            "strategy_readiness_publication_ready": (
                validation_strategy_readiness_manifest or {}
            ).get("publication_ready", False),
            "strategy_readiness_can_mark_complete": (
                validation_strategy_readiness_manifest or {}
            ).get("can_mark_complete", False),
            "strategy_readiness_remaining_blockers": (
                validation_strategy_readiness_manifest or {}
            ).get("remaining_blockers", []),
            "benchmark_decision_manifest_present": bool(
                validation_benchmark_decision_manifest
            ),
            "benchmark_decision_blocking_decision_count": (
                validation_benchmark_decision_manifest or {}
            ).get("blocking_decision_count", 0),
            "benchmark_decision_human_review_decision_count": (
                validation_benchmark_decision_manifest or {}
            ).get("human_review_decision_count", 0),
            "benchmark_decision_status_counts": (
                validation_benchmark_decision_manifest or {}
            ).get("decision_status_counts", {}),
            "benchmark_decision_remaining_blockers": (
                validation_benchmark_decision_manifest or {}
            ).get("remaining_blockers", []),
            "benchmark_decision_publication_ready": (
                validation_benchmark_decision_manifest or {}
            ).get("publication_ready", False),
            "benchmark_decision_can_mark_complete": (
                validation_benchmark_decision_manifest or {}
            ).get("can_mark_complete", False),
        },
    )


def _validation_summary_scope_is_blocked(text: str) -> bool:
    normalized = text.lower()
    blocked_markers = (
        "scaffold/sanity evidence",
        "not calibrated",
        "not ground truth",
    )
    return any(marker in normalized for marker in blocked_markers)


def _structured_disruption_gate() -> dict[str, Any]:
    path = PROJECT_ROOT / "data" / "scenarios" / "disruption_scenarios.csv"
    rows = _csv_rows(path)
    families = {row.get("family", "") for row in rows}
    required = {
        "random",
        "critical_link",
        "access_road",
        "last_mile",
        "rail_station_access",
        "spatial_hazard_overlay",
    }
    ready = bool(required <= families)
    return _gate(
        "structured_disruptions",
        "Structured Disruptions",
        ready=ready,
        artifact_present=path.exists(),
        evidence=["data/scenarios/disruption_scenarios.csv"],
        blockers=[] if ready else [
            "include random, critical-link, access/last-mile, station-access, and spatial disruption families"
        ],
        details={"families": sorted(families)},
    )


def _policy_gate() -> dict[str, Any]:
    path = PROJECT_ROOT / "data" / "scenarios" / "policy_alternatives.csv"
    rows = _csv_rows(path)
    policies = {row.get("policy_id", "") for row in rows}
    required = {
        "bus_only",
        "baseline_multimodal",
        "multimodal_lastmile_redundancy",
        "staggered_or_adaptive_dispatch",
    }
    ready = bool(required <= policies)
    return _gate(
        "policy_alternatives",
        "Policy Alternatives",
        ready=ready,
        artifact_present=path.exists(),
        evidence=["data/scenarios/policy_alternatives.csv"],
        blockers=[] if ready else ["include the required baseline and redundancy policies"],
        details={"policy_count": len(policies), "required_policies_present": sorted(required & policies)},
    )


def _sensitivity_gate(
    morris_manifest: dict[str, Any] | None,
    sensitivity_acceptance: dict[str, Any],
    sensitivity_strategy_readiness_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    review_manifest = _load_json(
        PROJECT_ROOT / "data" / "validation" / "sensitivity_review_manifest.json"
    )
    index_review_manifest = _load_json(
        DEFAULT_SENSITIVITY_INDEX_REVIEW_MANIFEST_PATH
    )
    strategy_readiness_packet_path = (
        PROJECT_ROOT / "data" / "validation" / "sensitivity_strategy_readiness_packet.csv"
    )
    strategy_readiness_manifest_path = (
        DEFAULT_SENSITIVITY_STRATEGY_READINESS_MANIFEST_PATH
    )
    strategy_readiness_doc_path = (
        PROJECT_ROOT / "docs" / "sensitivity_strategy_readiness_packet.md"
    )
    method_decision_manifest = _load_json(
        DEFAULT_SENSITIVITY_METHOD_DECISION_MANIFEST_PATH
    )
    strategy_readiness_artifacts_present = (
        strategy_readiness_packet_path.exists()
        and strategy_readiness_manifest_path.exists()
        and strategy_readiness_doc_path.exists()
    )
    index_review_artifacts_present = (
        DEFAULT_SENSITIVITY_INDEX_REVIEW_PACKET_PATH.exists()
        and DEFAULT_SENSITIVITY_INDEX_REVIEW_MANIFEST_PATH.exists()
        and DEFAULT_SENSITIVITY_INDEX_REVIEW_DOC_PATH.exists()
    )
    method_decision_artifacts_present = (
        DEFAULT_SENSITIVITY_METHOD_DECISION_PACKET_PATH.exists()
        and DEFAULT_SENSITIVITY_METHOD_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_SENSITIVITY_METHOD_DECISION_DOC_PATH.exists()
    )
    artifact_present = bool(morris_manifest)
    scope = str((morris_manifest or {}).get("result_scope", ""))
    acceptance_ready = bool(sensitivity_acceptance["acceptance_ready"])
    strategy_readiness = sensitivity_strategy_readiness_manifest or {}
    strategy_remaining_blockers = _list_value(
        sensitivity_strategy_readiness_manifest,
        "remaining_blockers",
    )
    strategy_blocking_count = _dict_int(
        sensitivity_strategy_readiness_manifest,
        "blocking_request_count",
    )
    strategy_human_review_count = _dict_int(
        sensitivity_strategy_readiness_manifest,
        "human_review_request_count",
    )
    scope_blocked = _sensitivity_scope_is_blocked(scope)
    count_blockers = _sensitivity_count_blockers(
        morris_manifest,
        sensitivity_acceptance,
    )
    ready = (
        artifact_present
        and acceptance_ready
        and strategy_readiness_artifacts_present
        and strategy_blocking_count == 0
        and strategy_human_review_count == 0
        and method_decision_artifacts_present
        and not scope_blocked
        and not count_blockers
    )
    blockers: list[str] = []
    if not strategy_readiness_artifacts_present:
        blockers.append("create sensitivity strategy-readiness packet, manifest, and doc")
    if not index_review_artifacts_present:
        blockers.append("create sensitivity index-review packet, manifest, and doc")
    if not method_decision_artifacts_present:
        blockers.append("create sensitivity method-decision packet, manifest, and doc")
    if not artifact_present:
        blockers.append("create accepted sensitivity outputs and manifest")
    if not acceptance_ready:
        blockers.extend(sensitivity_acceptance["remaining_blockers"])
    if strategy_blocking_count:
        blockers.append(
            "resolve sensitivity strategy-readiness blockers before sensitivity acceptance"
        )
        blockers.extend(
            f"sensitivity strategy readiness: {item}"
            for item in strategy_remaining_blockers
        )
    if strategy_human_review_count:
        blockers.append(
            "review sensitivity strategy-readiness human-decision items before sensitivity acceptance"
        )
    if scope_blocked:
        blockers.append(
            "accept sensitivity outputs on final graph/evidence scope; current Morris outputs are scaffold-level"
        )
    blockers.extend(count_blockers)
    return _gate(
        "sensitivity_analysis",
        "Sensitivity Analysis",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/sensitivity_acceptance.json",
            "results/realworld_pilot/morris_results.csv",
            "results/realworld_pilot/morris_summary.csv",
            "results/realworld_pilot/morris_manifest.json",
            "data/validation/sensitivity_review_packet.csv",
            "data/validation/sensitivity_review_manifest.json",
            "data/validation/sensitivity_index_review_packet.csv",
            "data/validation/sensitivity_index_review_manifest.json",
            "docs/sensitivity_index_review_packet.md",
            "data/validation/sensitivity_strategy_readiness_packet.csv",
            "data/validation/sensitivity_strategy_readiness_manifest.json",
            "docs/sensitivity_strategy_readiness_packet.md",
            "data/validation/sensitivity_method_decision_packet.csv",
            "data/validation/sensitivity_method_decision_manifest.json",
            "docs/sensitivity_method_decision_packet.md",
            "scripts/run_sensitivity.py",
            "scripts/audit_sensitivity_diagnostics.py",
            "scripts/write_sensitivity_review_packet.py",
            "scripts/write_sensitivity_index_review_packet.py",
            "scripts/write_sensitivity_strategy_readiness_packet.py",
            "scripts/write_sensitivity_method_decision_packet.py",
        ],
        blockers=[] if ready else blockers,
        details={
            "acceptance_record_present": sensitivity_acceptance["record_present"],
            "acceptance_path": sensitivity_acceptance["path"],
            "accepted_method": sensitivity_acceptance.get("sensitivity_method", ""),
            "sobol_requirement_decision": sensitivity_acceptance.get(
                "sobol_requirement_decision", ""
            ),
            "method": (morris_manifest or {}).get("method", ""),
            "row_count": (morris_manifest or {}).get("row_count", 0),
            "summary_row_count": (morris_manifest or {}).get("summary_row_count", 0),
            "review_packet_row_count": (review_manifest or {}).get("row_count", 0),
            "review_packet_publication_ready": (review_manifest or {}).get(
                "publication_ready",
                False,
            ),
            "review_packet_acceptance_gate_closure_candidate_count": (
                review_manifest or {}
            ).get("acceptance_gate_closure_candidate_count", 0),
            "review_packet_rows_with_index_issues": (review_manifest or {}).get(
                "rows_with_index_issues",
                0,
            ),
            "review_packet_zero_mu_star_count": (review_manifest or {}).get(
                "zero_mu_star_count",
                0,
            ),
            "index_review_packet_row_count": (index_review_manifest or {}).get(
                "row_count",
                0,
            ),
            "index_review_unavailable_index_row_count": (
                index_review_manifest or {}
            ).get("unavailable_index_row_count", 0),
            "index_review_zero_mu_star_row_count": (
                index_review_manifest or {}
            ).get("zero_mu_star_row_count", 0),
            "index_review_all_zero_group_count": (
                index_review_manifest or {}
            ).get("all_zero_group_count", 0),
            "index_review_human_review_metric_count": (
                index_review_manifest or {}
            ).get("human_review_metric_count", 0),
            "index_review_artifacts_present": index_review_artifacts_present,
            "index_review_publication_ready": (index_review_manifest or {}).get(
                "publication_ready", False
            ),
            "index_review_can_mark_complete": (index_review_manifest or {}).get(
                "can_mark_complete", False
            ),
            "strategy_readiness_manifest_present": bool(
                sensitivity_strategy_readiness_manifest
            ),
            "strategy_readiness_artifacts_present": strategy_readiness_artifacts_present,
            "strategy_readiness_blocking_request_count": strategy_blocking_count,
            "strategy_readiness_human_review_request_count": (
                strategy_human_review_count
            ),
            "strategy_readiness_status_counts": (
                strategy_readiness
            ).get("readiness_status_counts", {}),
            "strategy_readiness_remaining_blockers": strategy_remaining_blockers,
            "strategy_readiness_publication_ready": strategy_readiness.get(
                "publication_ready", False
            ),
            "strategy_readiness_can_mark_complete": strategy_readiness.get(
                "can_mark_complete", False
            ),
            "method_decision_artifacts_present": method_decision_artifacts_present,
            "method_decision_row_count": (method_decision_manifest or {}).get(
                "row_count", 0
            ),
            "method_decision_blocking_decision_count": (
                method_decision_manifest or {}
            ).get("blocking_decision_count", 0),
            "method_decision_human_review_decision_count": (
                method_decision_manifest or {}
            ).get("human_review_decision_count", 0),
            "method_decision_status_counts": (method_decision_manifest or {}).get(
                "decision_status_counts", {}
            ),
            "method_decision_sobol_decision_recorded": (
                method_decision_manifest or {}
            ).get("sobol_decision_recorded", False),
            "method_decision_sobol_waiver_created": (
                method_decision_manifest or {}
            ).get("sobol_waiver_created", False),
            "method_decision_publication_ready": (
                method_decision_manifest or {}
            ).get("publication_ready", False),
            "method_decision_can_mark_complete": (
                method_decision_manifest or {}
            ).get("can_mark_complete", False),
            "result_scope": scope,
            "scope_blocked": scope_blocked,
        },
    )


def _sensitivity_scope_is_blocked(scope: str) -> bool:
    normalized = scope.lower()
    return "scaffold" in normalized or "not calibrated" in normalized


def _sensitivity_count_blockers(
    morris_manifest: dict[str, Any] | None,
    sensitivity_acceptance: dict[str, Any],
) -> list[str]:
    if not morris_manifest or not sensitivity_acceptance.get("record_present"):
        return []
    comparisons = (
        (
            "row_count",
            sensitivity_acceptance.get("expected_row_count"),
            morris_manifest.get("row_count"),
        ),
        (
            "summary_row_count",
            sensitivity_acceptance.get("expected_summary_row_count"),
            morris_manifest.get("summary_row_count"),
        ),
    )
    mismatches = [
        f"{label}: acceptance={accepted!r}, manifest={manifest!r}"
        for label, accepted, manifest in comparisons
        if accepted != manifest
    ]
    if not mismatches:
        return []
    return [
        "sensitivity acceptance counts must match the Morris manifest counts: "
        + "; ".join(mismatches)
    ]


def _full_experiment_gate(
    pilot_manifest: dict[str, Any] | None,
    experiment_acceptance: dict[str, Any],
    experiment_package_review_manifest: dict[str, Any] | None = None,
    experiment_strategy_readiness_manifest: dict[str, Any] | None = None,
    experiment_design_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    artifact_present = bool(pilot_manifest)
    strategy_readiness_packet_path = (
        PROJECT_ROOT / "data" / "manifests" / "experiment_strategy_readiness_packet.csv"
    )
    strategy_readiness_doc_path = (
        PROJECT_ROOT / "docs" / "experiment_strategy_readiness_packet.md"
    )
    strategy_readiness_artifacts_present = (
        strategy_readiness_packet_path.exists()
        and DEFAULT_EXPERIMENT_STRATEGY_READINESS_MANIFEST_PATH.exists()
        and strategy_readiness_doc_path.exists()
    )
    design_decision_artifacts_present = (
        DEFAULT_EXPERIMENT_DESIGN_DECISION_PACKET_PATH.exists()
        and DEFAULT_EXPERIMENT_DESIGN_DECISION_MANIFEST_PATH.exists()
        and DEFAULT_EXPERIMENT_DESIGN_DECISION_DOC_PATH.exists()
    )
    status = str((pilot_manifest or {}).get("design_status", ""))
    scope = str((pilot_manifest or {}).get("result_scope", ""))
    acceptance_ready = bool(experiment_acceptance["acceptance_ready"])
    strategy_readiness = experiment_strategy_readiness_manifest or {}
    design_decision = experiment_design_decision_manifest or {}
    strategy_remaining_blockers = _list_value(
        experiment_strategy_readiness_manifest,
        "remaining_blockers",
    )
    strategy_blocking_count = _dict_int(
        experiment_strategy_readiness_manifest,
        "blocking_request_count",
    )
    strategy_human_review_count = _dict_int(
        experiment_strategy_readiness_manifest,
        "human_review_request_count",
    )
    design_decision_blocking_count = _dict_int(
        experiment_design_decision_manifest,
        "blocking_decision_count",
    )
    design_decision_human_review_count = _dict_int(
        experiment_design_decision_manifest,
        "human_review_decision_count",
    )
    design_decision_remaining_blockers = _list_value(
        experiment_design_decision_manifest,
        "remaining_blockers",
    )
    scope_blocked = _experiment_scope_is_blocked(scope, status)
    count_blockers = _experiment_count_blockers(
        pilot_manifest,
        experiment_acceptance,
    )
    ready = (
        artifact_present
        and acceptance_ready
        and strategy_readiness_artifacts_present
        and strategy_blocking_count == 0
        and strategy_human_review_count == 0
        and design_decision_artifacts_present
        and design_decision_blocking_count == 0
        and design_decision_human_review_count == 0
        and not scope_blocked
        and not count_blockers
    )
    blockers: list[str] = []
    if not strategy_readiness_artifacts_present:
        blockers.append("create experiment strategy-readiness packet, manifest, and doc")
    if not design_decision_artifacts_present:
        blockers.append("create experiment design-decision packet, manifest, and doc")
    if not artifact_present:
        blockers.append("create full pilot outputs and manifest")
    if not acceptance_ready:
        blockers.extend(experiment_acceptance["remaining_blockers"])
    if strategy_blocking_count:
        blockers.append(
            "resolve experiment strategy-readiness blockers before experiment acceptance"
        )
        blockers.extend(
            f"experiment strategy readiness: {item}"
            for item in strategy_remaining_blockers
        )
    if strategy_human_review_count:
        blockers.append(
            "review experiment strategy-readiness human-decision items before experiment acceptance"
        )
    if design_decision_blocking_count:
        blockers.append(
            "resolve experiment design-decision blockers before experiment acceptance"
        )
        blockers.extend(
            f"experiment design decision: {item}"
            for item in design_decision_remaining_blockers
        )
    if design_decision_human_review_count:
        blockers.append(
            "review experiment design-decision human-decision items before experiment acceptance"
        )
    if scope_blocked:
        blockers.append(
            "accept or regenerate full pilot outputs after input validation and graph-scale decision"
        )
    blockers.extend(count_blockers)
    review_manifest = experiment_package_review_manifest or {}
    if not review_manifest:
        blockers.append("generate experiment-package review packet before experiment acceptance")
    elif _dict_int(review_manifest, "experiment_acceptance_gate_closure_candidate_count") == 0:
        blockers.append("review experiment-package rows before formal experiment acceptance")
    return _gate(
        "full_experiment_output",
        "Full Experiment Output",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/experiment_acceptance.json",
            "results/realworld_pilot/pilot_full_results.csv",
            "results/realworld_pilot/pilot_full_summary.csv",
            "results/realworld_pilot/pilot_full_manifest.json",
            "data/manifests/experiment_package_review_packet.csv",
            "data/manifests/experiment_package_review_manifest.json",
            "docs/experiment_package_review_packet.md",
            "data/manifests/experiment_strategy_readiness_packet.csv",
            "data/manifests/experiment_strategy_readiness_manifest.json",
            "docs/experiment_strategy_readiness_packet.md",
            "data/manifests/experiment_design_decision_packet.csv",
            "data/manifests/experiment_design_decision_manifest.json",
            "docs/experiment_design_decision_packet.md",
            "scripts/write_experiment_design_decision_packet.py",
        ],
        blockers=[] if ready else blockers,
        details={
            "acceptance_record_present": experiment_acceptance["record_present"],
            "acceptance_path": experiment_acceptance["path"],
            "accepted_run_profile": experiment_acceptance.get("run_profile", ""),
            "row_count": (pilot_manifest or {}).get("row_count", 0),
            "summary_row_count": (pilot_manifest or {}).get("summary_row_count", 0),
            "design_status": status,
            "result_scope": scope,
            "scope_blocked": scope_blocked,
            "experiment_package_review_manifest_present": bool(review_manifest),
            "experiment_package_review_row_count": review_manifest.get("row_count", 0),
            "experiment_package_review_count_mismatch_count": review_manifest.get(
                "row_count_mismatch_count",
                0,
            ),
            "experiment_package_review_publication_ready": review_manifest.get(
                "publication_ready",
                False,
            ),
            "strategy_readiness_artifacts_present": strategy_readiness_artifacts_present,
            "strategy_readiness_manifest_present": bool(
                experiment_strategy_readiness_manifest
            ),
            "strategy_readiness_blocking_request_count": strategy_blocking_count,
            "strategy_readiness_human_review_request_count": (
                strategy_human_review_count
            ),
            "strategy_readiness_status_counts": (
                strategy_readiness
            ).get("readiness_status_counts", {}),
            "strategy_readiness_remaining_blockers": strategy_remaining_blockers,
            "strategy_readiness_publication_ready": strategy_readiness.get(
                "publication_ready", False
            ),
            "strategy_readiness_can_mark_complete": strategy_readiness.get(
                "can_mark_complete", False
            ),
            "design_decision_artifacts_present": design_decision_artifacts_present,
            "design_decision_manifest_present": bool(
                experiment_design_decision_manifest
            ),
            "design_decision_blocking_decision_count": (
                design_decision_blocking_count
            ),
            "design_decision_human_review_decision_count": (
                design_decision_human_review_count
            ),
            "design_decision_status_counts": design_decision.get(
                "decision_status_counts", {}
            ),
            "design_decision_remaining_blockers": (
                design_decision_remaining_blockers
            ),
            "design_decision_selected_run_profile_recorded": design_decision.get(
                "selected_run_profile_recorded", False
            ),
            "design_decision_scenario_policy_seed_decision_recorded": (
                design_decision.get("scenario_policy_seed_decision_recorded", False)
            ),
            "design_decision_publication_ready": design_decision.get(
                "publication_ready", False
            ),
            "design_decision_can_mark_complete": design_decision.get(
                "can_mark_complete", False
            ),
        },
    )


def _experiment_scope_is_blocked(scope: str, status: str) -> bool:
    normalized_scope = scope.lower()
    normalized_status = status.lower()
    return (
        "pending" in normalized_status
        or "scaffold" in normalized_scope
        or "not calibrated" in normalized_scope
    )


def _experiment_count_blockers(
    pilot_manifest: dict[str, Any] | None,
    experiment_acceptance: dict[str, Any],
) -> list[str]:
    if not pilot_manifest or not experiment_acceptance.get("record_present"):
        return []
    design = pilot_manifest.get("scenario_policy_seed_design", {})
    if not isinstance(design, dict):
        design = {}
    comparisons = (
        (
            "run_profile",
            experiment_acceptance.get("run_profile"),
            pilot_manifest.get("run_profile"),
        ),
        (
            "row_count",
            experiment_acceptance.get("expected_row_count"),
            pilot_manifest.get("row_count"),
        ),
        (
            "summary_row_count",
            experiment_acceptance.get("expected_summary_row_count"),
            pilot_manifest.get("summary_row_count"),
        ),
        (
            "policy_count",
            experiment_acceptance.get("policy_count"),
            design.get("policy_count"),
        ),
        (
            "scenario_count",
            experiment_acceptance.get("scenario_count"),
            design.get("scenario_count"),
        ),
        (
            "seed_count",
            experiment_acceptance.get("seed_count"),
            design.get("seed_count"),
        ),
    )
    mismatches = [
        f"{label}: acceptance={accepted!r}, manifest={manifest!r}"
        for label, accepted, manifest in comparisons
        if accepted != manifest
    ]
    if not mismatches:
        return []
    return [
        "experiment acceptance counts must match the pilot full manifest: "
        + "; ".join(mismatches)
    ]


def _manuscript_report_gate(
    figure_manifest: dict[str, Any] | None,
    claim_alignment_manifest: dict[str, Any] | None,
    figure_table_review_manifest: dict[str, Any] | None,
    manuscript_report_decision_manifest: dict[str, Any] | None,
    publication_audit: dict[str, Any],
    manuscript_acceptance: dict[str, Any],
) -> dict[str, Any]:
    paper = PROJECT_ROOT / "paper" / "paper_draft.md"
    report = PROJECT_ROOT / "report_draft.md"
    docx = PROJECT_ROOT / "report.docx"
    artifact_present = paper.exists() and report.exists() and docx.exists()
    scope = str((figure_manifest or {}).get("claim_boundary", ""))
    acceptance_ready = bool(manuscript_acceptance["acceptance_ready"])
    figure_review_manifest = figure_table_review_manifest or {}
    figure_review_blocking_count = _dict_int(
        figure_review_manifest,
        "blocking_review_count",
    )
    figure_review_human_count = _dict_int(
        figure_review_manifest,
        "human_review_count",
    )
    decision_manifest = manuscript_report_decision_manifest or {}
    decision_blocking_count = _dict_int(decision_manifest, "blocking_decision_count")
    decision_human_count = _dict_int(decision_manifest, "human_review_decision_count")
    scope_blocked = "scaffold" in scope.lower()
    ready = (
        artifact_present
        and publication_audit["publication_ready"]
        and acceptance_ready
        and bool(figure_review_manifest)
        and figure_review_blocking_count == 0
        and figure_review_human_count == 0
        and bool(decision_manifest)
        and decision_blocking_count == 0
        and decision_human_count == 0
        and not scope_blocked
    )
    blockers: list[str] = []
    if not publication_audit["publication_ready"]:
        blockers.append("close evidence gates before final paper/report claims")
    if not acceptance_ready:
        blockers.extend(manuscript_acceptance["remaining_blockers"])
    if scope_blocked:
        blockers.append(
            "revise figure/table claim boundary from scaffold to accepted study scope"
        )
    if not figure_review_manifest:
        blockers.append("generate figure/table review packet before manuscript acceptance")
    elif figure_review_blocking_count:
        blockers.append("resolve figure/table review blockers before manuscript acceptance")
        blockers.extend(
            f"figure/table review: {item}"
            for item in figure_review_manifest.get("remaining_blockers", [])
        )
    if figure_review_human_count:
        blockers.append(
            "review figure/table human-review rows before manuscript acceptance"
        )
    claim_manifest = claim_alignment_manifest or {}
    overclaim_count = _dict_int(claim_manifest, "overclaim_candidate_count")
    if not claim_manifest:
        blockers.append("generate claim-alignment review packet before manuscript acceptance")
    elif overclaim_count:
        blockers.append(
            "review or revise claim-alignment overclaim candidates before manuscript acceptance"
        )
        blockers.extend(
            f"claim alignment: {item}"
            for item in claim_manifest.get("remaining_blockers", [])
        )
    if not decision_manifest:
        blockers.append(
            "generate manuscript/report decision packet before manuscript acceptance"
        )
    elif decision_blocking_count:
        blockers.append(
            "resolve manuscript/report decision blockers before manuscript acceptance"
        )
        blockers.extend(
            f"manuscript/report decision: {item}"
            for item in decision_manifest.get("remaining_blockers", [])
        )
    if decision_human_count:
        blockers.append(
            "review manuscript/report human-decision rows before manuscript acceptance"
        )
    return _gate(
        "manuscript_report_alignment",
        "Manuscript Report Alignment",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/manuscript_acceptance.json",
            "paper/paper_draft.md",
            "report_draft.md",
            "report.docx",
            "results/realworld_pilot/tables/figure_table_manifest.json",
            "data/manifests/figure_table_review_packet.csv",
            "data/manifests/figure_table_review_manifest.json",
            "docs/figure_table_review_packet.md",
            "data/manifests/claim_alignment_review_packet.csv",
            "data/manifests/claim_alignment_review_manifest.json",
            "docs/claim_alignment_review_packet.md",
            "data/manifests/manuscript_report_decision_packet.csv",
            "data/manifests/manuscript_report_decision_manifest.json",
            "docs/manuscript_report_decision_packet.md",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": manuscript_acceptance["record_present"],
            "acceptance_path": manuscript_acceptance["path"],
            "figure_claim_boundary_scope_blocked": scope_blocked,
            "figure_table_review_manifest_present": bool(figure_review_manifest),
            "figure_table_review_blocking_review_count": figure_review_blocking_count,
            "figure_table_review_human_review_count": figure_review_human_count,
            "figure_table_review_status_counts": figure_review_manifest.get(
                "review_status_counts",
                {},
            ),
            "figure_table_review_remaining_blockers": figure_review_manifest.get(
                "remaining_blockers",
                [],
            ),
            "figure_table_review_publication_ready": figure_review_manifest.get(
                "publication_ready",
                False,
            ),
            "figure_table_review_can_mark_complete": figure_review_manifest.get(
                "can_mark_complete",
                False,
            ),
            "claim_alignment_review_manifest_present": bool(claim_manifest),
            "claim_alignment_review_row_count": claim_manifest.get("row_count", 0),
            "claim_alignment_overclaim_candidate_count": overclaim_count,
            "claim_alignment_guardrail_language_count": claim_manifest.get(
                "guardrail_language_count",
                0,
            ),
            "claim_alignment_review_status_counts": claim_manifest.get(
                "review_status_counts",
                {},
            ),
            "claim_alignment_claim_category_counts": claim_manifest.get(
                "claim_category_counts",
                {},
            ),
            "claim_alignment_gate_dependency_counts": claim_manifest.get(
                "gate_dependency_counts",
                {},
            ),
            "claim_alignment_remaining_blockers": claim_manifest.get(
                "remaining_blockers",
                [],
            ),
            "claim_alignment_publication_ready": claim_manifest.get(
                "publication_ready",
                False,
            ),
            "manuscript_report_decision_manifest_present": bool(decision_manifest),
            "manuscript_report_decision_row_count": decision_manifest.get(
                "row_count",
                0,
            ),
            "manuscript_report_decision_blocking_decision_count": decision_blocking_count,
            "manuscript_report_decision_human_review_decision_count": decision_human_count,
            "manuscript_report_decision_status_counts": decision_manifest.get(
                "decision_status_counts",
                {},
            ),
            "manuscript_report_decision_remaining_blockers": decision_manifest.get(
                "remaining_blockers",
                [],
            ),
            "manuscript_report_decision_publication_ready": decision_manifest.get(
                "publication_ready",
                False,
            ),
            "manuscript_report_decision_can_mark_complete": decision_manifest.get(
                "can_mark_complete",
                False,
            ),
            "publication_ready": publication_audit["publication_ready"],
        },
    )


def _reproducibility_gate(
    reproducibility_manifest: dict[str, Any] | None,
    reproducibility_acceptance: dict[str, Any],
    reproducibility_review_manifest: dict[str, Any] | None,
    reproducibility_decision_manifest: dict[str, Any] | None,
    reproducibility_smoke: dict[str, Any],
    clean_checkout_smoke: dict[str, Any] | None = None,
) -> dict[str, Any]:
    artifact_present = bool(reproducibility_manifest)
    scope = str((reproducibility_manifest or {}).get("scope", ""))
    remaining = list((reproducibility_manifest or {}).get("remaining_upgrades", []))
    commands = list((reproducibility_manifest or {}).get("validation_commands", []))
    review_manifest = reproducibility_review_manifest or {}
    decision_manifest = reproducibility_decision_manifest or {}
    acceptance_ready = bool(reproducibility_acceptance["acceptance_ready"])
    count_blockers = _reproducibility_count_blockers(
        commands,
        reproducibility_acceptance,
    )
    decision_blocking_count = _dict_int(decision_manifest, "blocking_decision_count")
    decision_human_count = _dict_int(decision_manifest, "human_review_decision_count")
    scope_blocked = "scaffold" in scope.lower()
    ready = (
        artifact_present
        and acceptance_ready
        and not count_blockers
        and bool(decision_manifest)
        and decision_blocking_count == 0
        and decision_human_count == 0
        and not scope_blocked
        and not remaining
    )
    blockers: list[str] = []
    if not acceptance_ready:
        blockers.extend(reproducibility_acceptance["remaining_blockers"])
    blockers.extend(count_blockers)
    if scope_blocked or remaining:
        blockers.append(
            "replace scaffold-only manifest with clean-checkout final reproduction package"
        )
    if not review_manifest:
        blockers.append("create reproducibility review packet before clean-checkout acceptance")
    if not decision_manifest:
        blockers.append(
            "generate reproducibility decision packet before reproducibility acceptance"
        )
    elif decision_blocking_count:
        blockers.append(
            "resolve reproducibility decision blockers before reproducibility acceptance"
        )
        blockers.extend(
            f"reproducibility decision: {item}"
            for item in decision_manifest.get("remaining_blockers", [])
        )
    if decision_human_count:
        blockers.append(
            "review reproducibility human-decision rows before reproducibility acceptance"
        )
    clean_smoke = clean_checkout_smoke or {}
    if clean_smoke and clean_smoke.get("manifest_present") and not clean_smoke.get(
        "smoke_passed"
    ):
        blockers.append("resolve failed bounded clean-checkout smoke before acceptance")
    return _gate(
        "reproducibility",
        "Reproducibility",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "data/manifests/reproducibility_acceptance.json",
            "docs/reproducibility_package.md",
            "data/manifests/reproducibility_manifest.json",
            "data/validation/reproducibility_review_packet.csv",
            "data/validation/reproducibility_review_manifest.json",
            "data/validation/reproducibility_decision_packet.csv",
            "data/validation/reproducibility_decision_manifest.json",
            "docs/reproducibility_decision_packet.md",
            "data/validation/reproducibility_smoke_manifest.json",
            "docs/reproducibility_smoke.md",
            "data/validation/clean_checkout_reproducibility_smoke_manifest.json",
            "docs/clean_checkout_reproducibility_smoke.md",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": reproducibility_acceptance["record_present"],
            "acceptance_path": reproducibility_acceptance["path"],
            "scope": scope,
            "validation_command_count": len(commands),
            "accepted_validation_command_count": reproducibility_acceptance.get(
                "expected_validation_command_count"
            ),
            "review_packet_present": bool(review_manifest),
            "review_packet_row_count": review_manifest.get("row_count"),
            "review_packet_clean_checkout_test_performed": review_manifest.get(
                "clean_checkout_test_performed"
            ),
            "review_packet_git_status_line_count": review_manifest.get(
                "git_status_line_count"
            ),
            "review_packet_untracked_count": review_manifest.get(
                "git_untracked_count"
            ),
            "review_packet_no_runtime_cloned_repo_imports": review_manifest.get(
                "no_runtime_cloned_repo_imports"
            ),
            "reproducibility_decision_manifest_present": bool(decision_manifest),
            "reproducibility_decision_row_count": decision_manifest.get(
                "row_count",
                0,
            ),
            "reproducibility_decision_blocking_decision_count": decision_blocking_count,
            "reproducibility_decision_human_review_decision_count": decision_human_count,
            "reproducibility_decision_status_counts": decision_manifest.get(
                "decision_status_counts",
                {},
            ),
            "reproducibility_decision_remaining_blockers": decision_manifest.get(
                "remaining_blockers",
                [],
            ),
            "reproducibility_decision_publication_ready": decision_manifest.get(
                "publication_ready",
                False,
            ),
            "reproducibility_decision_can_mark_complete": decision_manifest.get(
                "can_mark_complete",
                False,
            ),
            "current_worktree_smoke_present": reproducibility_smoke.get(
                "manifest_present"
            ),
            "current_worktree_smoke_passed": reproducibility_smoke.get("smoke_passed"),
            "current_worktree_smoke_command_count": reproducibility_smoke.get(
                "command_count"
            ),
            "current_worktree_smoke_failed_count": reproducibility_smoke.get(
                "failed_count"
            ),
            "current_worktree_smoke_scope": reproducibility_smoke.get(
                "result_scope"
            ),
            "clean_checkout_smoke_present": clean_smoke.get("manifest_present"),
            "clean_checkout_smoke_passed": clean_smoke.get("smoke_passed"),
            "clean_checkout_smoke_command_count": clean_smoke.get("command_count"),
            "clean_checkout_smoke_failed_count": clean_smoke.get("failed_count"),
            "clean_checkout_smoke_scope": clean_smoke.get("result_scope"),
            "clean_checkout_smoke_environment_scope": clean_smoke.get(
                "environment_scope"
            ),
            "clean_checkout_smoke_full_clean_environment_tested": clean_smoke.get(
                "full_clean_environment_tested"
            ),
        },
    )


def _reproducibility_count_blockers(
    commands: list[Any],
    reproducibility_acceptance: dict[str, Any],
) -> list[str]:
    if not reproducibility_acceptance.get("record_present"):
        return []
    accepted = reproducibility_acceptance.get("expected_validation_command_count")
    manifest_count = len(commands)
    if accepted == manifest_count:
        return []
    return [
        "reproducibility acceptance validation command count must match the manifest: "
        f"acceptance={accepted!r}, manifest={manifest_count!r}"
    ]


def _final_audit_gate(
    pre_final_gates: list[dict[str, Any]],
    final_audit_acceptance: dict[str, Any],
    final_audit_decision_manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    text = _read_text(DEFAULT_FINAL_AUDIT_PATH)
    artifact_present = DEFAULT_FINAL_AUDIT_PATH.exists()
    acceptance_ready = bool(final_audit_acceptance["acceptance_ready"])
    decision_manifest = final_audit_decision_manifest or {}
    decision_blocking_count = _dict_int(decision_manifest, "blocking_decision_count")
    decision_human_count = _dict_int(decision_manifest, "human_review_decision_count")
    count_blockers = _final_audit_count_blockers(
        pre_final_gates,
        final_audit_acceptance,
    )
    blocked_pre_final = [gate["gate_id"] for gate in pre_final_gates if not gate["ready"]]
    audit_text_ready = "prompt-to-artifact checklist" in text.lower()
    ready = (
        artifact_present
        and audit_text_ready
        and acceptance_ready
        and bool(decision_manifest)
        and decision_blocking_count == 0
        and decision_human_count == 0
        and not count_blockers
        and not blocked_pre_final
    )
    blockers: list[str] = []
    if not artifact_present:
        blockers.append("create docs/final_study_audit.md after all other gates close")
    elif not audit_text_ready:
        blockers.append(
            "final audit note must include a prompt-to-artifact checklist review"
        )
    if not acceptance_ready:
        blockers.extend(final_audit_acceptance["remaining_blockers"])
    if not decision_manifest:
        blockers.append("generate final-audit decision packet before final-audit acceptance")
    elif decision_blocking_count:
        blockers.append(
            "resolve final-audit decision blockers before final-audit acceptance"
        )
        blockers.extend(
            f"final-audit decision: {item}"
            for item in decision_manifest.get("remaining_blockers", [])
        )
    if decision_human_count:
        blockers.append(
            "review final-audit human-decision rows before final-audit acceptance"
        )
    blockers.extend(count_blockers)
    if blocked_pre_final:
        blockers.append(
            "all pre-final gates must be ready before final audit acceptance: "
            + ", ".join(blocked_pre_final)
        )
    return _gate(
        "final_audit",
        "Final Audit",
        ready=ready,
        artifact_present=artifact_present,
        evidence=[
            "docs/final_study_audit.md",
            "data/manifests/final_audit_acceptance.json",
            "data/manifests/final_audit_decision_packet.csv",
            "data/manifests/final_audit_decision_manifest.json",
            "docs/final_audit_decision_packet.md",
        ],
        blockers=blockers,
        details={
            "acceptance_record_present": final_audit_acceptance["record_present"],
            "acceptance_path": final_audit_acceptance["path"],
            "final_audit_decision_manifest_present": bool(decision_manifest),
            "final_audit_decision_row_count": decision_manifest.get("row_count", 0),
            "final_audit_decision_blocking_decision_count": decision_blocking_count,
            "final_audit_decision_human_review_decision_count": decision_human_count,
            "final_audit_decision_status_counts": decision_manifest.get(
                "decision_status_counts",
                {},
            ),
            "final_audit_decision_remaining_blockers": decision_manifest.get(
                "remaining_blockers",
                [],
            ),
            "final_audit_decision_publication_ready": decision_manifest.get(
                "publication_ready",
                False,
            ),
            "final_audit_decision_can_mark_complete": decision_manifest.get(
                "can_mark_complete",
                False,
            ),
            "blocked_pre_final_gate_ids": blocked_pre_final,
            "expected_gate_count": final_audit_acceptance.get("expected_gate_count"),
            "pre_final_gate_count": len(pre_final_gates),
        },
    )


def _final_audit_count_blockers(
    pre_final_gates: list[dict[str, Any]],
    final_audit_acceptance: dict[str, Any],
) -> list[str]:
    if not final_audit_acceptance.get("record_present"):
        return []
    blockers: list[str] = []
    expected_gate_count = final_audit_acceptance.get("expected_gate_count")
    if expected_gate_count != len(pre_final_gates):
        blockers.append(
            "final-audit expected_gate_count must match pre-final gate count: "
            f"acceptance={expected_gate_count!r}, current={len(pre_final_gates)!r}"
        )
    reviewed = set(_list_value(final_audit_acceptance, "reviewed_gate_ids"))
    current = {str(gate["gate_id"]) for gate in pre_final_gates}
    if reviewed != current:
        blockers.append(
            "final-audit reviewed_gate_ids must match current pre-final gates"
        )
    ready = set(_list_value(final_audit_acceptance, "ready_gate_ids"))
    current_ready = {str(gate["gate_id"]) for gate in pre_final_gates if gate["ready"]}
    if ready != current_ready:
        blockers.append("final-audit ready_gate_ids must match current ready gates")
    blocked = set(_list_value(final_audit_acceptance, "blocked_gate_ids"))
    current_blocked = {
        str(gate["gate_id"]) for gate in pre_final_gates if not gate["ready"]
    }
    if blocked != current_blocked:
        blockers.append("final-audit blocked_gate_ids must match current blocked gates")
    return blockers


def _gate(
    gate_id: str,
    label: str,
    *,
    ready: bool,
    artifact_present: bool,
    evidence: list[str],
    blockers: list[str],
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "gate_id": gate_id,
        "label": label,
        "ready": bool(ready),
        "artifact_present": bool(artifact_present),
        "evidence": evidence,
        "blockers": blockers,
        "details": details or {},
    }


def _load_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else None


def _csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


def _list_value(value: dict[str, Any] | None, key: str) -> Iterable[str]:
    raw = (value or {}).get(key, [])
    if not isinstance(raw, list):
        return []
    return [str(item) for item in raw]


def _dict_int(value: dict[str, Any] | None, key: str) -> int:
    raw = (value or {}).get(key, 0)
    return int(raw) if isinstance(raw, int | float) else 0


__all__ = [
    "FINAL_GATE_IDS",
    "audit_final_study_readiness",
]
