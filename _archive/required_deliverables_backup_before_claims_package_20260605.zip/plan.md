# Real-World Transport Simulation Implementation Plan

## Purpose

This plan replaces the recovery-focused plan with the forward implementation
plan for turning the current transport simulator into a rigorous, real-world or
quasi-real-world simulation pipeline.

The target is not to claim operational routing, real-time dispatch authority,
or calibrated real-world forecasting. The target is a defensible research and
decision-support simulator that combines:

- open-data road and transit inputs;
- auditable provenance and snapshots;
- stochastic personnel/fleet/transfer simulation;
- disruption and resilience scenarios;
- external route and multimodal plausibility benchmarks;
- compact-to-full experiment gates;
- strict claim boundaries.

The current root repository is the authoritative simulation core. Do not
recreate `transport_simulation_core/` as a duplicate workspace unless a
specific missing file has no root-level equivalent and is explicitly rebuilt.
Recovery evidence remains preserved under `docs/recovery/`.

## Current Baseline

Verified local environment, 2026-06-02:

- OS: Windows PowerShell workflow.
- CPU: AMD Ryzen 7 5800X3D, 8 cores / 16 logical processors.
- RAM: about 32 GB physical memory.
- GPU: NVIDIA GeForce RTX 3090, 24 GB VRAM.
- NVIDIA driver/KMD: 610.47.
- CUDA UMD reported by `nvidia-smi`: 13.3.
- Python execution should use the project virtual environment:
  `.\.venv\Scripts\python`.

Current implementation strengths:

- queue-based passenger dispatch;
- strict and grace departure policies;
- finite fleets and turnaround;
- bus-only and rail-bus multimodal movement;
- fixed-headway rail abstraction;
- transfer delay modeling;
- rolling-window BPR road congestion;
- blocked and capacity-reduced road disruption states;
- censoring-aware metrics;
- common-random-number paired experiments;
- optional real-world input scaffold under `src/realworld/`.

Current limitations:

- default `config.yaml` still uses a small abstract `A/S/R/D` graph;
- OSM-derived road attributes are coarse proxies unless source-reviewed;
- road capacity, speed, and disruption probabilities are not calibrated;
- rail is still mostly fixed-headway/capacity abstraction;
- disruption generation is not yet spatially correlated or duration-aware;
- route and multimodal outputs must not be treated as operational plans;
- final-study readiness and formal acceptance remain blocked until evidence
  gates are genuinely closed.

## Final Target Architecture

The final simulator should be layered rather than replaced by a monolithic
external platform.

```text
Region and scenario registry
  -> OSM / PBF / GraphML road-network snapshot
  -> GTFS or reviewed timetable / station / rail evidence
  -> road attribute evidence and calibration table
  -> disruption scenario library
  -> compact simulation gate
  -> external route / multimodal plausibility benchmark
  -> full stochastic experiment
  -> sensitivity, CRN, and replication audit
  -> figures, tables, and bounded claims
```

Keep the in-repo simulator as the core evaluator. External packages should
improve inputs, calibration, validation, and benchmarks.

Priority external stack:

1. `OSMnx` plus cached GraphML for initial real road networks.
2. `GeoPandas` and `Shapely` for region geometry, route geometry, connectors,
   and spatial QA.
3. `GTFS Validator`, `partridge`, and/or `gtfs_kit` for rail/transit input
   evidence.
4. `routingpy` plus cached OSRM/Valhalla snapshots for route plausibility.
5. `r5py/R5` for multimodal travel-time matrix and itinerary benchmarks.
6. `UXsim` as the first road-dynamics benchmark beyond rolling-window BPR.
7. `AequilibraE` or `Path4GMNS` for traffic assignment/calibration evidence
   once OD demand and road networks are stable.
8. `SALib` for sensitivity analysis, already present in requirements.

Deferred tools:

- `SUMO`: use only for small-corridor microscopic validation after the main
  OSM/GTFS pipeline is stable.
- `MATSim`: defer unless the project pivots to population-scale activity-based
  simulation.
- `OpenTripPlanner`: use as a later independent server benchmark, not as the
  first core dependency.
- `Valhalla` native stack: defer unless self-hosted multimodal routing becomes
  necessary.

## Claim Boundary

Allowed claims after the implementation and validation ladder passes:

- conditional comparison under documented scenario assumptions;
- quasi-real open-data decision-support simulation;
- resilience evaluation for disrupted regional personnel movement;
- route and mode plausibility based on cached external benchmark snapshots;
- sensitivity of outcomes to fleet, demand, transfer, congestion, and
  disruption assumptions.

Forbidden claims unless separately validated and accepted:

- operational routing orders;
- real-time dispatch instructions;
- real-world forecast accuracy;
- proof that one mode is always superior in the real world;
- calibrated traffic assignment or military/public-sector operation plan;
- final acceptance based only on filenames, generated figures, or smoke tests.

## Workflow Overview

The work proceeds through gated phases. Each phase has:

- local implementation owner: the main Codex thread;
- sub-agent review or build tasks: GPT-5.5 xhigh agents where useful;
- tests and audits before moving to the next phase;
- self-refinement checkpoints.

No full-scale run may start until all upstream compact and audit gates pass.

## Sub-Agent Operating Model

Use sub-agents aggressively, but only with explicit ownership and dependencies.
Each sub-agent must use `gpt-5.5` with `xhigh` reasoning when the work requires
research judgment, real-world validity review, or high-risk code review.

General rules:

1. The main thread owns the critical path and final integration.
2. Sub-agents receive bounded tasks with explicit read/write scope.
3. Parallel agents must have disjoint write sets or be read-only reviewers.
4. Do not start downstream agents until dependency gates are complete.
5. Every agent must report:
   - files inspected;
   - files edited;
   - tests run;
   - blockers;
   - residual risks.
6. Main thread performs final review before any commit or full experiment.
7. Use self-refinement after each wave:
   - compare agent findings;
   - reject unsupported claims;
   - update plan/checklists;
   - add tests before broadening scope.

## Sub-Agent Wave Scheduler

Sub-agents should not be called as an unstructured pool. Use a wave scheduler
so parallel work is fast but still auditable.

Agent classes:

1. Explorer agents:
   - read-only;
   - compare packages, methods, schemas, and validation options;
   - never edit files.
2. Builder agents:
   - edit only explicitly assigned files;
   - add or update tests with the implementation;
   - do not run broad experiments.
3. Reviewer agents:
   - inspect diffs, tests, manifests, and claim language;
   - report defects before integration proceeds.
4. Adversarial agents:
   - search for overclaims, false acceptance, broken provenance, and hidden
     operational assumptions;
   - should be used before any final report, package, or full run.
5. Audit agents:
   - verify output paths, row counts, hashes, source snapshots, and acceptance
     hygiene;
   - should run after compact and full outputs are generated.

Default wave order:

```text
Wave 0: main-thread baseline check
  -> Wave 1: parallel read-only explorers
  -> main-thread synthesis and implementation scope freeze
  -> Wave 2: one builder, or multiple builders with disjoint write sets
  -> main-thread narrow tests
  -> Wave 3: parallel reviewers
  -> main-thread self-refine patch
  -> main-thread expanded tests
  -> Wave 4: adversarial and audit reviewers
  -> gate decision
```

Parallelization rules:

- Parallel read-only agents are safe when they inspect different concerns.
- Parallel builders are allowed only when their write sets are disjoint and
  their tests are independent.
- Never run two builders against the same module, manifest, or generated output
  directory.
- Never start a downstream reviewer before the builder's tests and diff exist.
- Never start a full-run agent before compact-run audit has passed.

Each sub-agent prompt must include:

```text
Role:
  GPT-5.5 xhigh [explorer | builder | reviewer | adversarial | audit] agent.

Scope:
  Files/directories allowed to read.
  Files/directories allowed to edit, or "read-only".

Required output:
  files inspected;
  files edited;
  tests or commands run;
  findings ordered by severity;
  blockers;
  residual risks;
  exact next action recommendation.

Evidence rule:
  Do not claim anything was inspected, tested, or verified without tool or file
  evidence.
```

## Sub-Agent Orchestration Ledger

Every phase should maintain a short orchestration ledger before agents are
started. The ledger can live in `docs/recovery/` or the phase-specific run log,
but it must be written before implementation work expands.

Ledger fields:

- phase ID and objective;
- current git status summary;
- expected read set;
- expected write set;
- allowed generated-output directories;
- sub-agent names, roles, and model setting: GPT-5.5 xhigh;
- parallelization decision;
- join condition;
- tests required before the next wave;
- reviewer/adversarial findings;
- final gate decision.

Write-lock rules:

- Only one builder may edit a shared core module at a time.
- Parallel builders may run only with disjoint write sets.
- Generated-output builders must write to a new timestamped or explicitly
  scoped directory first.
- No agent may delete, move, or overwrite top-level directories.
- No agent may run recursive deletion or cleanup commands.
- No agent may create formal acceptance artifacts unless that phase explicitly
  authorizes a human-reviewed acceptance workflow.

Recommended per-phase ledger shape:

```text
Phase:
Objective:
Baseline status:
Agents:
  - name:
    role:
    scope:
    write lock:
    commands/tests allowed:
Dependencies:
Join condition:
Narrow tests:
Broad tests:
Self-refine actions:
Gate decision:
```

## Dependency-Aware Sub-Agent Call Pattern

Use multiple GPT-5.5 xhigh agents, but enforce barriers between waves:

1. Main-thread preflight barrier:
   - inspect files in scope;
   - record git status;
   - run the smallest relevant tests;
   - define expected edits.
2. Parallel explorer barrier:
   - run read-only agents by domain;
   - reject unsupported recommendations;
   - freeze the implementation scope.
3. Builder barrier:
   - run one builder for shared modules, or parallel builders only for
     non-overlapping write sets;
   - require tests or fixtures with every code change.
4. Main integration barrier:
   - inspect diff;
   - run narrow tests;
   - patch failures before expanding scope.
5. Parallel reviewer barrier:
   - run implementation reviewer, realism reviewer, and test/audit reviewer;
   - classify findings by severity.
6. Self-refine barrier:
   - patch blocker and high findings;
   - rerun impacted tests;
   - update manifests, logs, and claim boundaries.
7. Gate barrier:
   - proceed only if code, outputs, tests, and written claims agree.

Agent scheduling examples:

```text
Good parallel explorer wave:
  Agent A: road graph and OSM snapshot review, read-only.
  Agent B: rail/GTFS evidence review, read-only.
  Agent C: provenance and acceptance-hygiene review, read-only.

Good parallel builder wave:
  Agent A: figure script only.
  Agent B: CSV schema fixture only.
  Agent C: report wording only.

Bad parallel builder wave:
  Agent A and Agent B both edit src/scenario.py.
  Agent A edits outputs while Agent B audits those same outputs.
  Agent A moves directories while Agent B builds from those directories.
```

Every agent handoff must end with one of these recommendations:

- proceed;
- proceed after listed fixes;
- block until missing evidence is restored;
- block because methodology is not defensible.

## Hardware-Aware Execution Policy

Use the local workstation deliberately:

- CPU: AMD Ryzen 7 5800X3D, 8 physical cores and 16 logical processors.
- RAM: about 32 GB physical memory. Treat large road graphs, route matrices, and seed-level
  result tables as memory-sensitive.
- GPU: NVIDIA GeForce RTX 3090, 24 GB VRAM. `nvidia-smi` reports CUDA UMD
  13.3 in the current environment.

Simulation engine policy:

- Keep SimPy, NetworkX, and core stochastic simulation CPU-based unless a
  specific validated library path is introduced.
- Use bounded CPU workers:
  - 1 to 2 workers for debugging;
  - 4 to 8 workers for compact experiments;
  - at most 8 workers for the first full experiment;
  - increase only after runtime and memory logs show headroom.
- Write runtime logs with:
  - command;
  - worker count;
  - wall time;
  - peak memory if available;
  - output row counts;
  - config/input hashes.

GPU policy:

- Use RTX 3090 for post-simulation ML only:
  - XGBoost CUDA risk classification;
  - SHAP or feature-importance acceleration where supported;
  - optional PyTorch/CuPy/Numba experiments only if they add measurable value.
- Before any GPU claim, run a small CUDA fit/check and record `nvidia-smi`.
- Maintain CPU fallback for every ML step.
- Do not describe the simulation engine itself as GPU-accelerated unless a
  tested GPU simulation implementation exists.

Hardware test profiles:

| Profile | Purpose | CPU workers | GPU use | Required evidence |
|---|---:|---:|---|---|
| Debug | single scenario or unit tests | 1 | none | command and pass/fail |
| Compact | small real-world pipeline probe | 4-8 | none | row counts, hashes, runtime |
| Benchmark | route or multimodal benchmark cache | 1-4 | none | raw payload/cache manifest |
| Full simulation | audited stochastic experiment | <=8 initially | none | runtime log, memory check, output audit |
| ML post-analysis | risk/cluster/explanation models | 1-4 | RTX 3090 allowed | CUDA check, metrics, CPU fallback |

Before a GPU-backed ML result is reported, run and log:

```powershell
nvidia-smi
.\.venv\Scripts\python <small_cuda_or_xgboost_check.py>
```

If CUDA is unavailable, continue with CPU ML and state that GPU acceleration was
not used. Do not block simulation correctness on GPU availability.

## Self-Refinement And Verification Loop

Every implementation phase must follow this loop:

1. Baseline:
   - record current git status;
   - run the narrowest relevant existing tests;
   - identify expected changed files.
2. Implement:
   - keep edits scoped to the phase;
   - add tests before expanding behavior;
   - avoid broad rewrites.
3. Verify:
   - run module tests;
   - run scenario smoke;
   - run manifest/audit scripts if outputs changed.
4. Review:
   - use reviewer or adversarial sub-agents;
   - classify findings as blocker, high, medium, or low.
5. Refine:
   - patch blocker/high findings;
   - rerun the failed or impacted tests;
   - update the plan or claim boundary if evidence is weaker than expected.
6. Gate:
   - proceed only when tests, audit, and claim language agree.

Stop conditions:

- unexpected deleted tracked files;
- corrupt or unreadable required input/output files;
- source snapshots missing for claimed real-world evidence;
- compact experiment produces no meaningful stress outcomes;
- benchmark disagreement is unexplained;
- reviewer finds operational or forecast overclaim language.
- any agent reports edits outside its assigned write set;
- any agent creates formal acceptance files or final-ready claims without the
  required human/source review.

## Dependency-Aware Agent Matrix

Use this high-level dependency map before invoking agents:

| Stage | Main dependency | Parallel agents allowed | Join condition |
|---|---|---|---|
| Baseline/recovery | Clean worktree and smoke tests | No implementation agents | no unexpected deletes; smoke tests pass |
| Schema design | Existing `src/realworld` contracts | region, scenario, provenance explorers | schema synthesis approved by main thread |
| Road network | schema design complete | OSM, geometry, path reviewers | graph snapshot tests and provenance manifest pass |
| Road attributes | road graph exists | capacity/speed, BPR, assignment reviewers | weak values classified; overrides tested |
| Rail/transit | region nodes exist | GTFS/timetable, R5, rail-claim reviewers | rail assumptions or evidence path documented |
| Disruptions | road/rail network exists | hazard, resilience, test reviewers | non-trivial compact stress scenarios exist |
| Compact run | inputs and tests pass | output, stats, figure reviewers | compact audit passes |
| Full run | compact gate passes | preflight only before run; output reviewers after run | row counts, CRN, replication, sensitivity pass |
| ML analysis | audited full outputs | ML, GPU, explanation reviewers | metrics and labels are traceable |
| Reporting | audited figures/results | visual, manuscript, evidence reviewers | claim alignment and evidence package pass |
| Formal package | all prior gates pass | sequential formal/adversarial reviewers | no placeholder acceptance; blockers explicit |

## Phase Execution Cadence

For each phase, use this execution pattern unless the phase text gives a
stricter order:

1. Main thread preflight:
   - record `git status --short --branch`;
   - inspect the exact modules, tests, manifests, and data files in scope;
   - choose the narrowest test set that proves the current baseline still
     works.
2. Explorer wave:
   - launch GPT-5.5 xhigh read-only agents in parallel when the work separates
     cleanly by domain, such as road graph, rail evidence, validation, and
     provenance;
   - synthesize the findings into one implementation scope before any edit.
3. Builder wave:
   - prefer one builder for shared core modules;
   - allow parallel builders only when their write sets are disjoint, such as
     one data fixture builder and one figure-script builder;
   - every builder must add or update tests with the code.
4. Main-thread integration:
   - review the diff;
   - run narrow tests first;
   - patch failures before running broader tests.
5. Reviewer/adversarial wave:
   - run GPT-5.5 xhigh reviewers after a concrete diff and test output exist;
   - include at least one adversarial reviewer for realism, claim boundaries,
     formal-acceptance hygiene, and hidden operational assumptions.
6. Self-refine gate:
   - fix blocker/high findings;
   - rerun impacted tests;
   - update runtime logs, manifests, and plan notes;
   - only then move to the next phase.

Use the local hardware during tests deliberately:

- compact simulation tests should use the CPU with bounded workers and runtime
  logging;
- ML proof-of-concept tests should use a small RTX 3090 CUDA check before any
  GPU-backed claim;
- full experiments should not start until compact outputs, audits, and
  reviewer findings agree.

## Phase 0 - Baseline Preservation And Worktree Safety

Goal: ensure the restored repository is safe before new implementation work.

Local steps:

1. Run:

```powershell
git status --short --branch -uno
git log -1 --oneline
.\.venv\Scripts\python tests\test_config.py
.\.venv\Scripts\python tests\test_scenario.py
.\.venv\Scripts\python main.py --test
```

2. Confirm recovery artifacts still exist under `docs/recovery/`.
3. Confirm `plan.md` is now this forward implementation plan.
4. Do not cite missing event-transport outputs or untracked old results.

Sub-agent wave:

- No parallel implementation agent yet.
- Optional GPT-5.5 xhigh reviewer:
  "Audit the current plan and recovery artifacts for contradictions before
  implementation starts."

Gate:

- Git has no unexpected deleted tracked files.
- Minimal smoke tests pass.
- Any dirty files are explained.

## Phase 1 - Real-World Region And Scenario Registry

Goal: replace one-off hardcoded scenario context with reusable region and
scenario registries.

Implementation tasks:

1. Define a region registry schema:
   - `region_id`;
   - human-readable label;
   - bounding box or polygon path;
   - origin zone(s);
   - rail access node(s);
   - rail egress node(s);
   - destination zone(s);
   - privacy/sensitivity level;
   - source and provenance references.
2. Define scenario registry schema:
   - demand profile;
   - fleet profile;
   - policy alternatives;
   - disruption family;
   - rail service profile;
   - validation profile;
   - experiment size profile.
3. Keep abstract `A/S/R/D` config only as smoke-test fixture.
4. Add schema and fixture tests before using real regions.

Sub-agent wave 1, parallel:

- Agent A, region-schema reviewer:
  Review `src/realworld/types.py`, `regions.py`, and existing tests. Propose
  minimal schema changes and tests. Read-only unless explicitly assigned.
- Agent B, scenario-schema reviewer:
  Review `config.yaml`, `src/scenario.py`, `src/experiment/runner.py`, and
  scenario-related realworld modules. Identify required config separation.
- Agent C, data-provenance reviewer:
  Review existing manifests and acceptance modules. Recommend how region and
  scenario sources should be recorded without creating formal acceptance.

Dependency:

- Phase 1 agents can run in parallel.
- Implementation starts only after their findings are reconciled.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_types.py
.\.venv\Scripts\python tests\test_realworld_validation.py
.\.venv\Scripts\python tests\test_config.py
```

Self-refine checkpoint:

- Confirm every new field has a source, default, and test.
- Remove any schema field that is not used by downstream Phase 2 or Phase 3.

## Phase 2 - Real Road-Network Input Pipeline

Goal: make real or quasi-real road networks the standard non-smoke input path.

Implementation tasks:

1. Strengthen `src/realworld/osm_network.py` and related scripts so the
   pipeline supports:
   - live OSMnx extraction for prototypes;
   - cached GraphML load/save;
   - future pinned PBF workflow;
   - checksum/provenance manifest;
   - routeable road filtering;
   - geometry retention for figures and validation.
2. Build region-level road snapshot command:
   - input: region registry ID;
   - output: GraphML, edge table, node table, manifest.
3. Keep the extraction command non-destructive:
   - never overwrite a reviewed snapshot without an explicit flag;
   - write new timestamped output first.
4. Add connector audit:
   - origin to nearest road node;
   - rail access connector;
   - rail egress connector;
   - destination connector;
   - connector distance and travel-time reasonableness.

Sub-agent wave 2, sequential plus parallel:

1. Main thread implements or scopes the snapshot interface.
2. Then launch parallel read-only reviewers:
   - Agent A, OSM/GraphML reviewer:
     inspect `osm_network.py`, `adapter.py`, `zones.py`, and tests.
   - Agent B, geometry reviewer:
     inspect whether GeoPandas/Shapely is needed now or can remain optional.
   - Agent C, path/provenance reviewer:
     inspect manifests and source-provenance modules for snapshot audit gaps.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_osm_network.py
.\.venv\Scripts\python tests\test_realworld_adapter.py
.\.venv\Scripts\python tests\test_realworld_validation.py
.\.venv\Scripts\python tests\test_realworld_end_to_end.py
```

Compact experiment:

- Use a tiny region or fixture GraphML.
- Run no more than 2 policies x 2 disruption families x 3 seeds.
- Record row counts and checksums.

Self-refine checkpoint:

- Inspect route geometry and connector distances.
- Reject a region if connectors dominate route time or if required routes are
  disconnected.

## Phase 3 - Road Attribute Evidence And Calibration

Goal: move from coarse road defaults to auditable road attributes.

Implementation tasks:

1. Split road attributes into evidence classes:
   - source-backed;
   - OSM-derived;
   - routing-engine benchmarked;
   - expert proxy;
   - sensitivity-only.
2. Build a road attribute table with:
   - edge ID;
   - highway class;
   - length;
   - maxspeed;
   - lane count if available;
   - capacity proxy;
   - free-flow time;
   - benchmark travel time if available;
   - evidence status.
3. Keep `HIGHWAY_DEFAULTS` as explicit fallback only.
4. Add optional AequilibraE/Path4GMNS planning branch later, after OD demand is
   stable.
5. Add UXsim benchmark branch before replacing BPR:
   - compare BPR vs UXsim on a compact corridor;
   - use identical demand and disruption profiles;
   - report whether BPR is adequate for full sweeps.

Sub-agent wave 3, parallel:

- Agent A, road capacity and speed evidence:
  inspect `attributes.py`, road evidence modules, and review packets.
- Agent B, traffic-model reviewer:
  compare rolling-window BPR assumptions with UXsim benchmark requirements.
- Agent C, assignment-tool reviewer:
  evaluate whether AequilibraE or Path4GMNS should enter this phase or wait.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_attributes.py
.\.venv\Scripts\python tests\test_realworld_road_evidence.py
.\.venv\Scripts\python tests\test_realworld_road_capacity_evidence.py
.\.venv\Scripts\python tests\test_realworld_road_speed_evidence.py
.\.venv\Scripts\python tests\test_realworld_road_attribute_evidence.py
.\.venv\Scripts\python tests\test_traffic.py
```

Self-refine checkpoint:

- Any final claim must distinguish calibrated, source-backed, proxy, and
  sensitivity-only road values.
- If most edges remain proxy-only, claims stay quasi-real and exploratory.

## Phase 4 - Rail, Transit, And Multimodal Evidence

Goal: replace fixed-headway rail assumptions with reviewed timetable or GTFS
evidence where possible.

Implementation tasks:

1. Add or strengthen rail input modes:
   - static GTFS feed path;
   - public timetable cache path;
   - shortest-path or rail travel-time evidence path;
   - manually reviewed rail assumption path.
2. Use GTFS Validator before GTFS-derived evidence is accepted.
3. Use `partridge` or `gtfs_kit` for feed slicing and headway summaries.
4. Use r5py/R5 as an external multimodal benchmark when a feed and OSM network
   are available.
5. Keep rail capacity and emergency availability as sensitivity-only unless
   source-backed.
6. Add rail disruption profiles:
   - normal service;
   - increased headway;
   - partial capacity reduction;
   - rail access/egress disruption;
   - station processing delay.

Sub-agent wave 4, dependency-aware:

1. Agent A, GTFS/timetable intake reviewer:
   inspect `rail_gtfs.py`, `rail_timetable.py`, and rail evidence tests.
2. Agent B, r5py benchmark reviewer:
   design a minimal benchmark only after Phase 2 road snapshot exists.
3. Agent C, rail-claim reviewer:
   check manuscript/report language and formal evidence boundaries after code
   and data changes.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_rail_gtfs.py
.\.venv\Scripts\python tests\test_realworld_rail_timetable.py
.\.venv\Scripts\python tests\test_realworld_rail_shortest_path.py
.\.venv\Scripts\python tests\test_realworld_rail_evidence.py
.\.venv\Scripts\python tests\test_rail.py
.\.venv\Scripts\python tests\test_transfers.py
```

Self-refine checkpoint:

- Verify that rail assumptions do not silently imply operational availability.
- If GTFS is unavailable or not reviewed, keep rail as documented assumption.

## Phase 5 - Demand, Fleet, And Behavior Profiles

Goal: replace single fixed personnel count and generic lateness with explicit
demand and fleet profiles.

Implementation tasks:

1. Create demand profile tables:
   - total demand;
   - origin split;
   - arrival-time distribution;
   - no-show or late-arrival fraction;
   - group/boarding batch sizes;
   - source/evidence status.
2. Create fleet profile tables:
   - vehicle type;
   - capacity;
   - available count;
   - dispatch interval;
   - turnaround;
   - driver/rest constraints if modeled;
   - source/evidence status.
3. Add behavior scenario profiles:
   - concentrated arrival;
   - staggered arrival;
   - heavy-tailed lateness;
   - partial non-arrival;
   - boarding delay.
4. Rebuild the missing compact non-arrival scripts/tests only if this research
   scope remains active.

Sub-agent wave 5, parallel after Phase 1 schemas:

- Agent A, demand-model reviewer:
  evaluate demand CSV schema and stochastic sampling.
- Agent B, fleet-model reviewer:
  evaluate finite fleet and turnaround realism.
- Agent C, non-arrival contract reviewer:
  decide whether to reimplement the compact non-arrival missing files recorded
  in `docs/recovery/transport_core_reconstruction_decision_20260602.md`.

Validation:

```powershell
.\.venv\Scripts\python tests\test_dispatch.py
.\.venv\Scripts\python tests\test_fleet.py
.\.venv\Scripts\python tests\test_metrics.py
.\.venv\Scripts\python tests\test_scenario.py
```

Self-refine checkpoint:

- Run monotonic sanity tests:
  - more vehicles should not reduce completion under identical random streams;
  - lower capacity should not improve completion unless a documented side
    effect explains it;
  - worse lateness should not improve strict-policy completion.

## Phase 6 - Disruption Scenario Library

Goal: replace only independent Bernoulli edge failures with named and spatially
coherent disruption scenarios.

Implementation tasks:

1. Keep existing Bernoulli failure as baseline stochastic stress.
2. Add named disruption scenarios:
   - critical-link blockage;
   - corridor capacity reduction;
   - station access degradation;
   - rail headway increase;
   - destination access bottleneck;
   - multi-hazard overlap.
3. Add spatial disruption layer:
   - polygon/buffer-based edge exposure;
   - optional raster/hazard overlay later;
   - exposure-to-state mapping.
4. Add duration and recovery fields if they can be modeled without excessive
   architecture churn.
5. Add disruption manifest and scenario family checksums.

Sub-agent wave 6:

- Agent A, resilience-method reviewer:
  inspect NetworkX criticality, accessibility, and graph-scale diagnostics.
- Agent B, hazard-overlay reviewer:
  decide whether `snail`, GeoPandas-only overlays, or simple scenario polygons
  are sufficient for the first implementation.
- Agent C, disruption-test reviewer:
  design tests for blocked vs degraded vs rail/station-access disruptions.

Validation:

```powershell
.\.venv\Scripts\python tests\test_disruptions.py
.\.venv\Scripts\python tests\test_realworld_disruption_scenarios.py
.\.venv\Scripts\python tests\test_realworld_graph_scale_diagnostics.py
.\.venv\Scripts\python tests\test_realworld_route_road_evidence_exposure.py
```

Self-refine checkpoint:

- Ensure disruption scenarios are plausible, reproducible, and interpretable.
- Do not use random edge failure alone for strong real-world resilience claims.

## Phase 7 - External Benchmark Layer

Goal: independently check route and multimodal plausibility without treating
any external engine as ground truth.

Implementation tasks:

1. Replace or complement ad hoc OSRM calls with `routingpy` where useful.
2. Cache raw route benchmark responses:
   - query URL or engine config;
   - route geometry;
   - distance;
   - duration;
   - timestamp;
   - engine version if available;
   - SHA256.
3. Add at least one road route benchmark:
   - OSRM or Valhalla.
4. Add at least one multimodal benchmark when GTFS exists:
   - r5py/R5 preferred.
5. Add benchmark comparison table:
   - simulator free-flow time;
   - benchmark time;
   - percent difference;
   - status pass/warn/fail;
   - reason.

Sub-agent wave 7, sequential:

1. Agent A, route benchmark implementer or reviewer:
   owns route benchmark client files only.
2. Agent B, multimodal benchmark reviewer:
   starts only after rail/GTFS evidence exists.
3. Agent C, validation boundary reviewer:
   verifies no document treats OSRM/R5/Valhalla as ground truth.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_osrm_snapshot_manifest.py
.\.venv\Scripts\python tests\test_realworld_validation_review_packet.py
.\.venv\Scripts\python tests\test_realworld_validation_strategy_readiness_packet.py
```

Self-refine checkpoint:

- Any benchmark row with live/unpinned source must be downgraded to review aid.
- Strong claims require cached raw payloads or explicitly reviewed snapshots.

## Phase 8 - Compact Experiment Gate

Goal: prove the full pipeline works at small scale before expensive full runs.

Compact profile:

- 1 region.
- 2 to 3 policies.
- 2 to 3 disruption families.
- 3 to 5 seeds.
- 1 demand profile.
- 1 rail profile.
- no publication claim.

Implementation tasks:

1. Add compact run command with deterministic output directory.
2. Record command, config hash, input hashes, row counts, and runtime.
3. Generate compact summary only after audit passes.
4. Add failure-focused compact probe:
   - at least one scenario should produce non-trivial censored or degraded
     outcomes, otherwise the stress profile is too weak.

Hardware guidance:

- Use CPU multiprocessing carefully: Ryzen 7 5800X3D has 16 logical processors,
  but leave headroom for OS and interactive tools.
- Suggested compact CPU workers: 4 to 8.
- Do not use GPU for SimPy/NetworkX simulation unless a specific library path
  supports it.
- Use RTX 3090 for ML post-analysis only, such as XGBoost/CUDA or GPU-enabled
  explainability, after simulation outputs are audited.

Sub-agent wave 8:

- Agent A, compact output validator:
  inspect compact outputs and row counts.
- Agent B, statistical sanity reviewer:
  inspect completion, censoring, resource metrics, and monotonic checks.
- Agent C, figure/claim reviewer:
  inspect generated compact figures for overclaim risk.

Validation:

```powershell
.\.venv\Scripts\python tests\test_scenario.py
.\.venv\Scripts\python tests\test_analysis.py
.\.venv\Scripts\python tests\test_realworld_pilot_smoke.py
.\.venv\Scripts\python tests\test_realworld_reproducibility_smoke.py
```

Self-refine checkpoint:

- If compact run has no failures, no stress, or no policy differences, revise
  scenario ranges before full run.

## Phase 9 - Full Experiment Gate

Goal: run the full quasi-real experiment only after compact validity is proven.

Preconditions:

- Phase 1 to Phase 8 gates pass.
- input manifests exist and match current files;
- benchmark manifests exist for retained benchmarks;
- compact run audit passes;
- no known corrupt files;
- no unresolved high-risk path loss affects the active scope.

Full profile design:

- multiple policies;
- multiple disruption families;
- multiple demand/fleet profiles;
- 30 or more seeds only if runtime and statistical adequacy justify it;
- common-random-number pairing across comparable policies;
- controlled output directory with timestamp and manifest.

Hardware guidance:

- CPU simulation should use bounded worker count, initially 8 workers or less.
- Monitor memory use because road graphs and per-seed outputs can grow quickly.
- RTX 3090 should be reserved for ML analysis after simulation, not for
  NetworkX/SimPy loops.
- If GPU training is used, verify with `nvidia-smi` and store the check result.

Sub-agent wave 9, dependency-aware:

1. Agent A, full-run preflight reviewer:
   inspect all manifests and compact audit; no code edits.
2. Main thread runs full experiment.
3. Agent B, output-integrity reviewer:
   starts only after full outputs exist.
4. Agent C, statistical reviewer:
   starts only after output-integrity reviewer confirms row counts.
5. Agent D, claim-boundary reviewer:
   starts only after statistical reviewer finishes.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_crn_pairing_audit.py
.\.venv\Scripts\python tests\test_realworld_replication_adequacy_audit.py
.\.venv\Scripts\python tests\test_realworld_experiment_strategy_readiness_packet.py
.\.venv\Scripts\python tests\test_realworld_sensitivity.py
.\.venv\Scripts\python tests\test_realworld_sensitivity_diagnostics.py
```

Self-refine checkpoint:

- If replication adequacy is weak, increase seeds or narrow claims.
- If metrics are dominated by censoring, avoid raw makespan interpretation.
- If policy ordering is unstable, present uncertainty rather than ranking.

## Phase 10 - ML And Decision-Support Analysis

Goal: add AI/ML analysis only after simulation outputs are valid.

Allowed ML tasks:

- risk classification from audited simulation rows;
- clustering of scenario-policy outcome patterns;
- feature importance and SHAP-style explanation;
- natural-language decision briefing generated from audited facts;
- bottleneck classification and sensitivity interpretation.

Implementation rules:

1. ML labels must be derived transparently from audited metrics.
2. Avoid pretending deterministic threshold labels prove predictive generality.
3. Split train/test by scenario family or seed where meaningful.
4. Store model config, package versions, metrics, and confusion matrix.
5. If using XGBoost CUDA on RTX 3090:
   - verify GPU fit with a small test;
   - record `nvidia-smi`;
   - keep CPU fallback;
   - do not claim simulation engine itself is GPU accelerated.

Sub-agent wave 10:

- Agent A, ML-method reviewer:
  decide whether classification/clustering is scientifically meaningful.
- Agent B, GPU/runtime reviewer:
  verify CUDA use and fallback behavior.
- Agent C, explanation reviewer:
  inspect feature names, Korean/English labels, and claim boundaries.

Validation:

- model metrics CSV/JSON exist;
- no raw variable names in final figures unless they are explained;
- SHAP/feature importance terms map to human-readable scenario concepts;
- ML claims are phrased as decision-support post-analysis, not operational AI.

Self-refine checkpoint:

- If ML adds no insight beyond rule-based summaries, keep it as optional
  dashboard support rather than central research contribution.

## Phase 11 - Figures, Reports, And Evidence Package

Goal: generate only figures and reports that are traceable to audited outputs.

Implementation tasks:

1. Build figure generation scripts that read only audited outputs.
2. Store each figure with:
   - source data path;
   - script path;
   - command;
   - caption;
   - claim boundary.
3. Avoid decorative figures that do not support a claim.
4. Put final candidate figures in a dedicated `final` directory.
5. Keep rejected or exploratory figures in `candidate` or archive directories.
6. Generate manuscript/report text only after figure provenance is complete.

Sub-agent wave 11:

- Agent A, visual QA reviewer:
  inspect figures for overlaps, unreadable labels, wrong units, and overclaim.
- Agent B, manuscript reviewer:
  inspect claim alignment and terminology.
- Agent C, evidence-package reviewer:
  inspect whether every figure/table has source data and script traceability.

Validation:

```powershell
.\.venv\Scripts\python tests\test_realworld_pilot_figures.py
.\.venv\Scripts\python tests\test_realworld_publication_readiness.py
.\.venv\Scripts\python tests\test_realworld_final_study_readiness.py
```

Self-refine checkpoint:

- Remove any figure whose conclusion depends on unaccepted evidence.
- Rewrite any text that sounds like operational routing or forecast certainty.

## Phase 12 - Formal Acceptance And Final Audit

Goal: convert a working quasi-real pipeline into a reviewable final-study
package without confusing review aids with acceptance.

Implementation tasks:

1. Do not populate formal target files with templates.
2. Create formal artifacts only after source-backed human/reviewer decisions.
3. Run formal acceptance guards after every formal artifact change.
4. Keep final-study readiness false until all formal gates are genuinely ready.
5. Build review package only after source, input, output, figure, and claim
   audits pass.

Required checks:

```powershell
.\.venv\Scripts\python scripts\audit_formal_acceptance_artifacts.py
.\.venv\Scripts\python scripts\audit_formal_evidence_paths.py
.\.venv\Scripts\python scripts\validate_formal_acceptance_package.py
.\.venv\Scripts\python scripts\audit_final_study_readiness.py
.\.venv\Scripts\python scripts\build_review_package.py
.\.venv\Scripts\python scripts\audit_review_package_paths.py
```

Sub-agent wave 12, sequential:

1. Agent A, formal artifact hygiene reviewer.
2. Agent B, final-study gate reviewer.
3. Agent C, package path-integrity reviewer.
4. Agent D, adversarial overclaim reviewer.

Self-refine checkpoint:

- If any gate is blocked, keep the package as review-ready but
  acceptance-incomplete.
- Do not downgrade blocker language merely to make the package look complete.

## Test Ladder Summary

Always run tests from narrow to broad.

Level 0, baseline:

```powershell
.\.venv\Scripts\python tests\test_config.py
.\.venv\Scripts\python tests\test_scenario.py
.\.venv\Scripts\python main.py --test
```

Level 1, core modules:

```powershell
.\.venv\Scripts\python tests\test_models.py
.\.venv\Scripts\python tests\test_dispatch.py
.\.venv\Scripts\python tests\test_fleet.py
.\.venv\Scripts\python tests\test_traffic.py
.\.venv\Scripts\python tests\test_disruptions.py
.\.venv\Scripts\python tests\test_rail.py
.\.venv\Scripts\python tests\test_transfers.py
.\.venv\Scripts\python tests\test_metrics.py
.\.venv\Scripts\python tests\test_analysis.py
```

Level 2, real-world modules:

```powershell
.\.venv\Scripts\python tests\test_realworld_types.py
.\.venv\Scripts\python tests\test_realworld_osm_network.py
.\.venv\Scripts\python tests\test_realworld_road_snapshot.py
.\.venv\Scripts\python tests\test_realworld_adapter.py
.\.venv\Scripts\python tests\test_realworld_validation.py
.\.venv\Scripts\python tests\test_realworld_end_to_end.py
.\.venv\Scripts\python tests\test_realworld_attributes.py
.\.venv\Scripts\python tests\test_realworld_road_evidence.py
.\.venv\Scripts\python tests\test_realworld_road_attribute_evidence.py
.\.venv\Scripts\python tests\test_realworld_rail_evidence.py
```

Level 3, experiment and audit:

```powershell
.\.venv\Scripts\python tests\test_realworld_pilot_smoke.py
.\.venv\Scripts\python tests\test_realworld_full_graph_smoke.py
.\.venv\Scripts\python tests\test_realworld_crn_pairing_audit.py
.\.venv\Scripts\python tests\test_realworld_replication_adequacy_audit.py
.\.venv\Scripts\python tests\test_realworld_sensitivity.py
.\.venv\Scripts\python tests\test_realworld_reproducibility_smoke.py
```

Level 4, readiness and final controls:

```powershell
.\.venv\Scripts\python tests\test_realworld_publication_readiness.py
.\.venv\Scripts\python tests\test_realworld_final_study_readiness.py
.\.venv\Scripts\python tests\test_realworld_review_package_inventory.py
.\.venv\Scripts\python tests\test_realworld_review_package_builder.py
.\.venv\Scripts\python tests\test_realworld_review_package_handoff.py
```

## Minimum Viable Real-World Milestone

The first credible milestone is not a huge full-scale run. It is:

1. one reviewed pilot region;
2. one cached OSM/GraphML road network;
3. one origin, one rail access, one rail egress, one destination zone;
4. one documented rail assumption or GTFS/timetable evidence path;
5. two policies: bus-only and rail-bus multimodal;
6. three disruption families:
   - no disruption;
   - critical road/corridor degradation;
   - rail or station-access stress;
7. compact run with non-trivial stress outcomes;
8. external route plausibility benchmark;
9. sensitivity over demand, fleet, transfer, and disruption parameters;
10. audited figures and bounded report language.

Only after this milestone passes should the project expand to multiple
regions, multiple corridors, or heavier platforms such as SUMO.

## Immediate Next Actions

1. Keep this `plan.md` as the controlling implementation plan.
2. Preserve Phase 0 to Phase 2 evidence under `docs/recovery/`; do not rerun
   broad cleanup or reconstruction steps unless a concrete missing/corrupt file
   is found.
3. Continue Phase 3 road-attribute evidence work:
   - finish the edge-level road-attribute evidence table;
   - classify OSM-derived, source-backed, proxy, benchmarked, and
     sensitivity-only values;
   - add tests and a non-acceptance manifest;
   - keep formal acceptance targets absent.
4. Use the Phase 3 agent pattern:
   - GPT-5.5 xhigh road evidence reviewer;
   - GPT-5.5 xhigh traffic/UXsim reviewer;
   - GPT-5.5 xhigh assignment-method reviewer;
   - main-thread synthesis and tests before any broader implementation.
5. Run narrow tests first, then the Level 0 and Level 2 test ladder impacted by
   road attributes.
6. After Phase 3 passes, move to Phase 4 rail/transit evidence; do not start
   compact or full experiments until road and rail input gates are both
   auditable.
7. Use RTX 3090 only for Phase 10 ML post-analysis after simulation outputs are
   already audited.
