# Source Provenance Priority Packet

This packet prioritizes existing source provenance review work. It does not create provenance_acceptance.json, certify license compatibility, accept source snapshots, or close provenance, validation, reproducibility, or final-study gates.

## Verdict

- Publication ready: `false`
- Can mark complete: `false`
- Priority rows: 11
- Blocking sources: 2
- Human-review sources: 9
- Priority status counts: `{'blocked_context_only_source_not_cached': 2, 'needs_human_review_cached_snapshot_source': 5, 'needs_human_review_repository_input_source': 4}`

## Priority Rows

| Source | Type | Status | Priority | URLs | Alternate Candidates | Required Decision |
| --- | --- | --- | --- | --- | --- | --- |
| seoul_shortest_path_api_context | public_api | blocked_context_only_source_not_cached | high | alternate_reachable_url_needs_review=1; reachable_needs_license_review=1 | https://data.seoul.go.kr/dataList/OA-22724/A/1/datasetView.do | provide a reviewed target payload with terms/attribution review, retain this context-source row as sensitivity/context-only, or exclude it from final-study claims |
| seoul_timetable_api_context | public_api | blocked_context_only_source_not_cached | high | reachable_needs_license_review=2 |  | provide a reviewed target payload with terms/attribution review, retain this context-source row as sensitivity/context-only, or exclude it from final-study claims |
| metro9_capacity_context | operator_page | needs_human_review_cached_snapshot_source | high | reachable_needs_license_review=1 |  | review source terms, attribution, snapshot date, and retained local artifacts |
| seoul_station_binding_cache | public_api | needs_human_review_cached_snapshot_source | high | reachable_needs_license_review=1 |  | review source terms, attribution, snapshot date, and retained local artifacts |
| ktdb_public_transport_gtfs_context | public_data | needs_human_review_cached_snapshot_source | high | reachable_needs_license_review=2 |  | review source terms, attribution, snapshot date, and retained local artifacts |
| osm_overpass_road_snapshot | public_map | needs_human_review_cached_snapshot_source | high | reachable_needs_license_review=2 |  | review source terms, attribution, snapshot date, and retained local artifacts |
| osrm_public_route_benchmark | public_router | needs_human_review_cached_snapshot_source | high | reachable_needs_license_review=3 |  | review source terms, attribution, snapshot date, and retained local artifacts |
| parameter_source_tables | repository_input | needs_human_review_repository_input_source | medium | local_citation_needs_review=1 |  | review project-owned assumptions, privacy abstraction, and claim boundary |
| pilot_region_spec | repository_input | needs_human_review_repository_input_source | medium | local_citation_needs_review=1 |  | review project-owned assumptions, privacy abstraction, and claim boundary |
| reproducibility_package | repository_input | needs_human_review_repository_input_source | medium | local_citation_needs_review=1 |  | review project-owned assumptions, privacy abstraction, and claim boundary |
| structured_scenario_tables | repository_input | needs_human_review_repository_input_source | medium | local_citation_needs_review=1 |  | review project-owned assumptions, privacy abstraction, and claim boundary |

## Boundary

- This packet is source-provenance prioritization support only.
- It does not certify source terms, license compatibility, or snapshot suitability.
- It cannot create or replace `data/manifests/provenance_acceptance.json`.
