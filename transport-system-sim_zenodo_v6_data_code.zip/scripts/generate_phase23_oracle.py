"""Regenerate the Phase 2.3 byte-identity oracle (deterministic).

The oracle (``results/_phase23_baseline/oracle.json``) is the frozen baseline
that proves invariant #1: the contract widening must NOT perturb the legacy
rail / bus KPIs. ``tests/test_composable_service_pipeline.py::
test_byte_identity_against_oracle`` re-runs the 6 frozen runs (bus_only /
multimodal x seeds 1101-1103) and asserts every KPI reproduces bit-for-bit.

This script is the SINGLE SOURCE of the oracle. Run it only when the baseline
LEGITIMATELY changes (e.g. ``MetricsCollector.as_dict`` gains/loses a key, or
the canonical pilot config is intentionally re-tuned). It:

* rebuilds the canonical pilot base config (``make_pilot_base_config`` +
  ``apply_pilot_demand_fleet_profiles`` — the same path the composable tests
  use), and pins ``base_config_sha256`` so a config drift is caught;
* runs the 6 frozen scenarios on the real cached Goseong graph and records the
  FULL ``as_dict()`` (all result keys, not a curated subset) so the oracle
  cannot be silently weakened by dropping keys;
* stamps ``runs_sha256`` = sha256 of the ``runs`` block so a hand-edit to any
  KPI value (the silent-regeneration attack) is detected by the test.

Quasi-real / decision-support only — not an operational plan, forecast, or
calibrated validation. ``final_study_ready`` stays false.

Usage::

    .\\.venv\\Scripts\\python scripts\\generate_phase23_oracle.py
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.realworld.pilot_experiments import (  # noqa: E402
    _json_sha256,
    apply_pilot_demand_fleet_profiles,
    load_pilot_inputs,
    make_pilot_base_config,
)
from src.scenario import run_scenario  # noqa: E402
from src.policies import StrictPolicy  # noqa: E402

REGION = "data/regions/goseong_mobilization.yaml"
# Phase 2: the byte-identity oracle is frozen against the Korean 표준노드링크
# canonical cache (official road network). The OSM cache
# (goseong_corridor_road.graphml) remains a documented archived alternative
# source. This CACHE and tests/test_composable_service_pipeline.py::CACHE must
# stay in lockstep or the byte-identity test fails.
CACHE = "data/cache/goseong_nodelink_road.graphml"
OVERRIDES = "data/parameters/road_class_overrides.csv"
ORACLE_PATH = ROOT / "results" / "_phase23_baseline" / "oracle.json"

DEFAULT_SIGMA = 0.75

# Single source of the frozen oracle runs. Consumed by BOTH this generator and
# tests/test_composable_service_pipeline.py::test_byte_identity_against_oracle
# (imported) so the two cannot drift apart. Each spec carries an optional
# ``failure`` config and ``p_fail_scale``; defaults reproduce the clean baseline.
ORACLE_RUN_SPECS: tuple[dict, ...] = (
    # --- Baseline (no disruptions): proves the additive travel_time_multiplier
    #     field is non-regressive for the legacy rail/bus KPIs. ---
    {"key": "bus_only_s1101", "scenario_type": "bus_only", "seed": 1101},
    {"key": "bus_only_s1102", "scenario_type": "bus_only", "seed": 1102},
    {"key": "bus_only_s1103", "scenario_type": "bus_only", "seed": 1103},
    {"key": "multimodal_s1101", "scenario_type": "multimodal", "seed": 1101},
    {"key": "multimodal_s1102", "scenario_type": "multimodal", "seed": 1102},
    {"key": "multimodal_s1103", "scenario_type": "multimodal", "seed": 1103},
    # --- Road-damage frozen runs: guard the wartime direct-slowdown lever
    #     (road_travel_time_multiplier) end-to-end against silent drift.
    #     p_fail_scale=1.0 deterministically degrades a fixed CRN edge set;
    #     capacity_factor=1.0 isolates the speed lever from the wartime-inert
    #     capacity path. Decision-support sensitivity only. ---
    {
        "key": "bus_only_road_damage_s1101",
        "scenario_type": "bus_only",
        "seed": 1101,
        "p_fail_scale": 1.0,
        "failure": {
            "mode": "capacity_reduction",
            "capacity_reduction_factor": 1.0,
            "road_travel_time_multiplier": 2.0,
        },
    },
    {
        "key": "multimodal_road_damage_s1101",
        "scenario_type": "multimodal",
        "seed": 1101,
        "p_fail_scale": 1.0,
        "failure": {
            "mode": "capacity_reduction",
            "capacity_reduction_factor": 1.0,
            "road_travel_time_multiplier": 2.0,
        },
    },
)


def build_oracle() -> dict:
    inputs = load_pilot_inputs(
        region_path=REGION,
        cache_path=CACHE,
        road_class_overrides_path=OVERRIDES,
    )
    # Canonical pilot base config (experiment.time_limit=1440, the 24h wartime window).
    # Mirrors tests/test_composable_service_pipeline.py::_base_config exactly,
    # including the road_class_overrides_path so the byte-identity baseline and
    # the Goseong case-study runs share the same evidenced road inputs.
    base = apply_pilot_demand_fleet_profiles(make_pilot_base_config(inputs.region))[0]

    runs: dict[str, dict] = {}
    for spec in ORACLE_RUN_SPECS:
        import copy

        cfg = copy.deepcopy(base)
        failure = spec.get("failure")
        if failure:
            cfg["failure"] = copy.deepcopy(failure)
        params = {
            "s": 1.0,
            "p_fail_scale": spec.get("p_fail_scale", 0.0),
            "sigma": DEFAULT_SIGMA,
        }
        result = run_scenario(
            G=inputs.graph,
            config=cfg,
            scenario_type=spec["scenario_type"],
            policy=StrictPolicy(),
            params=params,
            seed=spec["seed"],
        )
        runs[spec["key"]] = result

    return {
        "schema_version": 2,
        "description": (
            "Phase 2.3 byte-identity oracle. Generated by "
            "scripts/generate_phase23_oracle.py (single source). The "
            "contract widening must not perturb these legacy rail/bus KPIs; "
            "the road-damage frozen runs additionally guard the wartime "
            "direct-slowdown lever (road_travel_time_multiplier). Baseline "
            "applies data/parameters/road_class_overrides.csv (Goseong "
            "evidenced road inputs). Regenerate only on a legitimate "
            "baseline change."
        ),
        "base_config_sha256": _json_sha256(base),
        "runs_sha256": _json_sha256(runs),
        "runs": runs,
    }


def main() -> None:
    os.chdir(ROOT)
    oracle = build_oracle()
    ORACLE_PATH.parent.mkdir(parents=True, exist_ok=True)
    ORACLE_PATH.write_text(
        json.dumps(oracle, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {ORACLE_PATH}")
    print(f"  base_config_sha256 = {oracle['base_config_sha256']}")
    print(f"  runs_sha256        = {oracle['runs_sha256']}")
    print(f"  runs               = {len(oracle['runs'])} x "
          f"{len(next(iter(oracle['runs'].values())))} keys")


if __name__ == "__main__":
    main()
