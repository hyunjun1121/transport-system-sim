r"""Deterministic scenario regression tests.

These tests document Wave 1 target behavior for the scenario orchestrator.
They intentionally exercise the public run_scenario API and avoid pytest so the
file can be run directly with:

    .\.venv\Scripts\python tests\test_scenario.py

The assertions cover dispatch, fleet, rail, transfer, and censoring semantics
through deterministic stochastic fixtures.
"""

from contextlib import contextmanager
import os
import sys

import networkx as nx
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import scenario as scenario_module
from src.network import build_network
from src.policies import GracePolicy, StrictPolicy
from src.sim_types import EdgeDisruption
from src.traffic import DynamicRoadTraffic


PARAMS = {"s": 1.0, "p_fail_scale": 0.0, "sigma": 0.0}
HIGH_CAPACITY = 1_000_000_000
LEGACY_RESULT_KEYS = {
    "makespan",
    "success_count",
    "success_rate",
    "total_personnel",
    "bus_trips",
    "train_trips",
    "bus_minutes",
    "train_minutes",
    "lastmile_minutes",
    "lastmile_vehicle_minutes",
    "road_vehicle_service_minutes",
    "train_service_minutes",
    "total_service_minutes",
    "passenger_travel_minutes",
    "passengers_per_vehicle_minute",
    "passengers_per_total_service_minute",
    "resource_efficiency",
    "rerouting_events",
    "leftover_count",
    "censored_count",
    "completion_rate",
    "penalized_makespan",
    "first_arrival_time",
    "median_arrival_time",
    "p80_arrival_time",
    "p95_arrival_time",
    "service_breakdown",
}


@contextmanager
def fixed_stochastic_inputs(delays):
    """Patch stochastic scenario inputs to fixed deterministic values."""
    original_delays = scenario_module.sample_arrival_delays
    original_disruptions = scenario_module.sample_edge_disruptions
    original_failures = scenario_module.sample_link_failures

    def sample_fixed_delays(n_personnel, mu, sigma, rng):
        assert n_personnel == len(delays), (
            f"fixture has {len(delays)} delays for {n_personnel} personnel"
        )
        return np.array(delays, dtype=float)

    def sample_no_disruptions(G, p_fail_scale, rng, **kwargs):
        return {(u, v): EdgeDisruption() for u, v in G.edges()}

    scenario_module.sample_arrival_delays = sample_fixed_delays
    scenario_module.sample_edge_disruptions = sample_no_disruptions
    scenario_module.sample_link_failures = lambda G, p_fail_scale, rng, **kwargs: []
    try:
        yield
    finally:
        scenario_module.sample_arrival_delays = original_delays
        scenario_module.sample_edge_disruptions = original_disruptions
        scenario_module.sample_link_failures = original_failures


def make_config(
    total,
    group_size,
    *,
    bus_route_time=5.0,
    shuttle_time=1.0,
    rail_time=1000.0,
    rail_headway=10.0,
    rail_capacity=100,
    lastmile_time=1.0,
    dispatch_interval=10.0,
    fleet_size=1,
    turnaround=0.0,
    time_limit=500.0,
    assembly_time=0.0,
    bus_first_departure=None,
    shuttle_first_departure=None,
    rail_first_departure=None,
    lastmile_fleet_size=None,
    lastmile_turnaround=None,
    lastmile_vehicle_capacity=None,
    lastmile_first_departure=None,
    return_strategy=None,
):
    """Build a small deterministic config for scenario behavior tests."""
    bus_conf = {
        "dispatch_interval_min": dispatch_interval,
        "fleet_size": fleet_size,
        "turnaround_min": turnaround,
    }
    if bus_first_departure is not None:
        bus_conf["first_departure_min"] = bus_first_departure

    multimodal_conf = {
        "shuttle_dispatch_interval_min": dispatch_interval,
        "shuttle_fleet_size": fleet_size,
        "transfer_time_min": 0.0,
        "transfer_per_passenger_min": 0.0,
        "lastmile_dispatch_interval_min": dispatch_interval,
    }
    if shuttle_first_departure is not None:
        multimodal_conf["shuttle_first_departure_min"] = shuttle_first_departure
    if rail_first_departure is not None:
        multimodal_conf["rail_first_departure_min"] = rail_first_departure
    if lastmile_fleet_size is not None:
        multimodal_conf["lastmile_fleet_size"] = lastmile_fleet_size
    if lastmile_turnaround is not None:
        multimodal_conf["lastmile_turnaround_min"] = lastmile_turnaround
    if lastmile_vehicle_capacity is not None:
        multimodal_conf["lastmile_vehicle_capacity"] = lastmile_vehicle_capacity
    if lastmile_first_departure is not None:
        multimodal_conf["lastmile_first_departure_min"] = lastmile_first_departure

    config = {
        "network": {
            "nodes": ["H", "A", "S", "R", "D"],
            "road_links": [
                ["A", "D", bus_route_time, HIGH_CAPACITY, 0.0],
                ["A", "S", shuttle_time, HIGH_CAPACITY, 0.0],
                ["R", "D", lastmile_time, HIGH_CAPACITY, 0.0],
            ],
            "rail_link": [["S", "R", rail_time, rail_headway, rail_capacity]],
        },
        "personnel": {
            "total": total,
            "group_size": group_size,
            "assembly_time": assembly_time,
        },
        "bus": bus_conf,
        "multimodal": multimodal_conf,
        "traffic": {
            "volume_window_min": 60.0,
            "background_volume": 0.0,
        },
        "failure": {
            "mode": "blocked",
            "capacity_reduction_factor": 1.0,
        },
        "metrics": {
            "late_penalty_min": time_limit,
        },
        "bpr": {
            "alpha": 0.0,
            "beta": 4.0,
        },
        "lateness": {
            "distribution": "fixed-test-fixture",
            "mu": 0.0,
            "sigma_levels": [0.0],
        },
        "experiment": {
            "R": 1,
            "seed_base": 1,
            "time_limit": time_limit,
        },
    }
    if return_strategy is not None:
        config["fleet"] = {"return_strategy": return_strategy}
    return config


def run_fixed(config, scenario_type, policy, delays):
    """Run a scenario with fixed arrivals and no link failures."""
    G = build_network(config)
    with fixed_stochastic_inputs(delays):
        return scenario_module.run_scenario(
            G=G,
            config=config,
            scenario_type=scenario_type,
            policy=policy,
            params=PARAMS,
            seed=123,
        )


def assert_close(actual, expected, tolerance=0.05, label="value"):
    assert abs(actual - expected) <= tolerance, (
        f"{label}: expected {expected}, got {actual}"
    )


def test_origin_schedule_defaults_to_assembly_time():
    """Origin dispatch should use the assembly-time timetable, not first arrival."""
    config = make_config(
        total=1,
        group_size=1,
        bus_route_time=1.0,
        dispatch_interval=10.0,
        fleet_size=1,
        assembly_time=0.0,
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [6.0])

    assert result["success_count"] == 1
    assert result["bus_trips"] == 1
    assert_close(result["makespan"], 11.0, label="assembly-time schedule makespan")
    print("PASS: origin schedule defaults to assembly time")


def test_origin_schedule_accepts_explicit_first_departure():
    """Origin dispatch should accept an explicit first departure override."""
    config = make_config(
        total=1,
        group_size=1,
        bus_route_time=1.0,
        dispatch_interval=10.0,
        fleet_size=1,
        assembly_time=0.0,
        bus_first_departure=6.0,
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [6.0])

    assert result["success_count"] == 1
    assert result["bus_trips"] == 1
    assert_close(result["makespan"], 7.0, label="explicit first departure makespan")
    print("PASS: explicit first departure overrides assembly-time default")


def test_strict_departures_do_not_wait_for_late_arrivals():
    """STRICT should send an on-time partial bus and leave latecomers queued."""
    config = make_config(
        total=4,
        group_size=4,
        bus_route_time=5.0,
        dispatch_interval=10.0,
        fleet_size=2,
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 0.0, 6.0, 6.0])

    assert result["success_count"] == 4, (
        f"expected all passengers delivered, got {result['success_count']}"
    )
    assert result["bus_trips"] == 2, (
        "STRICT should depart at t=0 with the two present passengers and "
        "carry the late arrivals on the next dispatch; "
        f"got {result['bus_trips']} bus trips"
    )
    assert_close(result["makespan"], 15.0, label="STRICT makespan")
    print("PASS: STRICT leaves late arrivals for a follow-up dispatch")


def test_fleet_delay_does_not_retroactively_board_late_arrivals():
    """Passengers who miss policy time should not board a later-delayed vehicle."""
    config = make_config(
        total=3,
        group_size=2,
        bus_route_time=100.0,
        dispatch_interval=10.0,
        fleet_size=1,
        turnaround=0.0,
        time_limit=500.0,
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 5.0, 60.0])

    assert result["success_count"] == 3
    assert result["bus_trips"] == 3, (
        "the passenger arriving at t=60 missed the t=10 policy decision even "
        "though that vehicle physically departed later"
    )
    assert_close(result["makespan"], 300.0, label="fleet-delayed makespan")
    print("PASS: fleet delays do not retroactively change manifests")


def test_grace_waits_for_threshold_and_differs_from_strict():
    """GRACE should wait for the threshold when it is reached before max wait."""
    config = make_config(
        total=4,
        group_size=4,
        bus_route_time=5.0,
        dispatch_interval=10.0,
        fleet_size=2,
    )
    delays = [0.0, 0.0, 6.0, 6.0]

    strict = run_fixed(config, "bus_only", StrictPolicy(), delays)
    grace = run_fixed(config, "bus_only", GracePolicy(W=10.0, theta=1.0), delays)

    assert grace["success_count"] == 4, (
        f"expected all passengers delivered, got {grace['success_count']}"
    )
    assert grace["bus_trips"] == 1, (
        "GRACE should wait until all four passengers have arrived at t=6; "
        f"got {grace['bus_trips']} bus trips"
    )
    assert_close(grace["makespan"], 11.0, label="GRACE makespan")
    assert grace["bus_trips"] < strict["bus_trips"], (
        "STRICT and GRACE should produce different dispatch counts; "
        f"strict={strict['bus_trips']} grace={grace['bus_trips']}"
    )
    assert grace["makespan"] < strict["makespan"], (
        "Waiting for the threshold should beat the next scheduled STRICT bus here; "
        f"strict={strict['makespan']} grace={grace['makespan']}"
    )
    print("PASS: GRACE threshold behavior differs from STRICT")


def test_grace_max_wait_leaves_late_arrivals_for_next_dispatch():
    """GRACE should depart at max wait when the threshold is not reached."""
    config = make_config(
        total=4,
        group_size=4,
        bus_route_time=5.0,
        dispatch_interval=10.0,
        fleet_size=2,
    )

    result = run_fixed(
        config,
        "bus_only",
        GracePolicy(W=10.0, theta=1.0),
        [0.0, 0.0, 20.0, 20.0],
    )

    assert result["success_count"] == 4, (
        f"expected all passengers delivered, got {result['success_count']}"
    )
    assert result["bus_trips"] == 2, (
        "GRACE should depart at t=10 with early arrivals, then use a later "
        "dispatch for passengers who arrive after the max wait; "
        f"got {result['bus_trips']} bus trips"
    )
    assert_close(result["makespan"], 25.0, label="GRACE max-wait makespan")
    print("PASS: GRACE max wait leaves later arrivals queued")


def test_bus_fleet_allows_overlapping_trips():
    """A fleet larger than one should not serialize all bus trips."""
    config = make_config(
        total=4,
        group_size=2,
        bus_route_time=100.0,
        dispatch_interval=10.0,
        fleet_size=2,
        turnaround=100.0,
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 0.0, 0.0, 0.0])

    assert result["success_count"] == 4, (
        f"expected all passengers delivered, got {result['success_count']}"
    )
    assert result["bus_trips"] == 2, (
        f"expected two bus trips, got {result['bus_trips']}"
    )
    assert_close(result["makespan"], 110.0, label="overlapping fleet makespan")
    print("PASS: bus fleet overlaps trips when multiple buses are available")


def test_rail_departures_keep_fixed_headway_while_trains_are_in_transit():
    """Rail headway should be independent of earlier trains still traveling."""
    config = make_config(
        total=6,
        group_size=6,
        shuttle_time=0.0,
        rail_time=100.0,
        rail_headway=10.0,
        rail_capacity=2,
        lastmile_time=0.0,
        time_limit=500.0,
    )

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0] * 6)

    assert result["success_count"] == 6, (
        f"expected all rail passengers delivered, got {result['success_count']}"
    )
    assert result["train_trips"] == 3, (
        f"expected three train trips, got {result['train_trips']}"
    )
    assert result["makespan"] <= 130.05, (
        "three capacity-two trains should depart near t=10, t=20, and t=30 "
        "even though the first train arrives near t=110; "
        f"got makespan {result['makespan']}"
    )
    print("PASS: rail dispatch keeps fixed headway during in-transit trains")


def test_explicit_rail_first_departure_is_honored():
    """Rail should honor the optional first-departure timetable override."""
    config = make_config(
        total=2,
        group_size=2,
        shuttle_time=0.0,
        rail_time=10.0,
        rail_headway=10.0,
        rail_capacity=2,
        rail_first_departure=50.0,
        lastmile_time=0.0,
        time_limit=200.0,
    )

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0, 0.0])

    assert result["success_count"] == 2
    assert result["train_trips"] == 1
    assert_close(result["makespan"], 60.0, label="explicit rail first departure")
    print("PASS: explicit rail first departure is honored")


def test_explicit_available_rail_state_preserves_default_result():
    """Explicit available state must be identical to the legacy default."""
    implicit = make_config(
        total=2,
        group_size=2,
        shuttle_time=0.0,
        rail_time=10.0,
        rail_headway=10.0,
        rail_capacity=2,
        lastmile_time=0.0,
        time_limit=100.0,
    )
    explicit = make_config(
        total=2,
        group_size=2,
        shuttle_time=0.0,
        rail_time=10.0,
        rail_headway=10.0,
        rail_capacity=2,
        lastmile_time=0.0,
        time_limit=100.0,
    )
    explicit["multimodal"]["rail_status"] = "available"

    implicit_result = run_fixed(implicit, "multimodal", StrictPolicy(), [0.0, 0.0])
    explicit_result = run_fixed(explicit, "multimodal", StrictPolicy(), [0.0, 0.0])

    assert implicit_result == explicit_result
    print("PASS: explicit available rail state preserves default result")


def test_degraded_rail_state_multiplies_only_rail_travel_time():
    """Degraded rail must apply its configured travel-time multiplier."""
    config = make_config(
        total=1,
        group_size=1,
        shuttle_time=0.0,
        rail_time=10.0,
        rail_headway=10.0,
        rail_capacity=1,
        lastmile_time=0.0,
        time_limit=100.0,
    )
    config["multimodal"].update(
        rail_status="degraded",
        rail_degradation_multiplier=2.0,
    )

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0])

    assert result["success_count"] == 1
    assert result["train_trips"] == 1
    assert_close(result["makespan"], 30.0, label="degraded rail makespan")
    assert_close(result["train_minutes"], 20.0, label="degraded rail minutes")
    print("PASS: degraded rail state multiplies rail travel time")


def test_unavailable_rail_state_produces_no_rail_departures_or_arrivals():
    """Unavailable rail is structural absence, not a very slow train."""
    config = make_config(
        total=2,
        group_size=2,
        shuttle_time=0.0,
        rail_time=10.0,
        rail_headway=10.0,
        rail_capacity=2,
        lastmile_time=0.0,
        time_limit=100.0,
    )
    config["multimodal"]["rail_status"] = "unavailable"

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0, 0.0])

    assert result["success_count"] == 0
    assert result["completion_rate"] == 0.0
    assert result["train_trips"] == 0
    assert result["leftover_count"] == 2
    print("PASS: unavailable rail state has no departures or arrivals")


def test_invalid_rail_state_and_degradation_multiplier_fail_loudly():
    """Rail state schema must reject unknown states and invalid multipliers."""
    invalid_state = make_config(total=1, group_size=1, time_limit=100.0)
    invalid_state["multimodal"]["rail_status"] = "delayed-ish"
    try:
        run_fixed(invalid_state, "multimodal", StrictPolicy(), [0.0])
    except ValueError as exc:
        assert "rail service state" in str(exc), str(exc)
    else:
        raise AssertionError("unknown rail status was accepted")

    invalid_multiplier = make_config(total=1, group_size=1, time_limit=100.0)
    invalid_multiplier["multimodal"].update(
        rail_status="degraded",
        rail_degradation_multiplier=0.5,
    )
    try:
        run_fixed(invalid_multiplier, "multimodal", StrictPolicy(), [0.0])
    except ValueError as exc:
        assert "degradation_multiplier" in str(exc), str(exc)
    else:
        raise AssertionError("degraded rail multiplier below one was accepted")
    print("PASS: invalid rail state and multiplier fail loudly")


def test_lastmile_fleet_capacity_and_turnaround_create_bottleneck():
    """Finite last-mile capacity and turnaround should delay downstream delivery."""
    config = make_config(
        total=4,
        group_size=2,
        shuttle_time=0.0,
        rail_time=0.0,
        rail_headway=10.0,
        rail_capacity=4,
        lastmile_time=100.0,
        dispatch_interval=10.0,
        fleet_size=2,
        lastmile_fleet_size=1,
        lastmile_turnaround=100.0,
        time_limit=500.0,
    )

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0] * 4)

    assert result["success_count"] == 4
    assert result["train_trips"] == 1
    assert_close(result["makespan"], 310.0, label="last-mile bottleneck makespan")
    assert_close(result["lastmile_minutes"], 200.0, label="last-mile vehicle minutes")
    print("PASS: finite last-mile fleet creates a measurable bottleneck")


def test_censoring_penalty_prevents_failed_scenario_from_looking_better():
    """Censored scenarios need explicit completion and penalized KPIs."""
    censored_config = make_config(
        total=4,
        group_size=2,
        bus_route_time=100.0,
        dispatch_interval=10.0,
        fleet_size=1,
        turnaround=100.0,
        time_limit=150.0,
    )
    complete_config = make_config(
        total=4,
        group_size=2,
        bus_route_time=100.0,
        dispatch_interval=10.0,
        fleet_size=1,
        turnaround=100.0,
        time_limit=500.0,
    )

    delays = [0.0, 0.0, 0.0, 0.0]
    censored = run_fixed(censored_config, "bus_only", StrictPolicy(), delays)
    complete = run_fixed(complete_config, "bus_only", StrictPolicy(), delays)

    assert censored["success_count"] == 2, (
        f"expected two delivered passengers before the limit, got {censored['success_count']}"
    )
    assert censored["leftover_count"] == 2, (
        f"expected two censored passengers, got {censored['leftover_count']}"
    )
    for key in ("censored_count", "completion_rate", "penalized_makespan"):
        assert key in censored, f"missing explicit censoring KPI: {key}"
    assert censored["censored_count"] == 2
    assert_close(censored["completion_rate"], 0.5, label="completion rate")
    assert censored["penalized_makespan"] > complete["makespan"], (
        "a partially delivered run must not rank better than the complete run"
    )
    assert censored["penalized_makespan"] > censored["makespan"], (
        "penalized makespan should expose the cost of undelivered personnel"
    )
    print("PASS: censoring exposes incomplete delivery in penalized KPIs")


def test_arrival_delay_correction_factor_scales_lateness():
    """lateness.correction_factor multiplies sampled arrival delays (default 1.0).

    The 1.67x underestimation correction (진학은 et al. 2022) is an opt-in knob
    defaulting to 1.0; CRN is preserved (same seed -> same raw sample -> scaled).
    """

    def _run(correction_factor):
        config = make_config(
            total=2,
            group_size=2,
            bus_route_time=5.0,
            dispatch_interval=10.0,
            fleet_size=1,
            turnaround=0.0,
            time_limit=500.0,
        )
        if correction_factor is not None:
            config["lateness"]["correction_factor"] = correction_factor
        result = run_fixed(
            config, "bus_only", GracePolicy(W=100.0, theta=1.0), [10.0, 10.0]
        )
        assert result["success_count"] == 2, (
            f"expected both passengers delivered, got {result['success_count']}"
        )
        return result["makespan"]

    makespan_default = _run(None)  # no key -> scenario defaults to 1.0
    makespan_one = _run(1.0)
    makespan_two = _run(2.0)

    # default (no key) must equal explicit 1.0 -> knob defaults OFF
    assert abs(makespan_default - makespan_one) <= 0.1, (
        f"default correction_factor should equal 1.0: {makespan_default} vs {makespan_one}"
    )
    # 2.0 doubles the 10-min delay -> makespan rises by 10
    delta = makespan_two - makespan_one
    assert abs(delta - 10.0) <= 0.1, (
        f"correction_factor=2.0 should shift makespan by +10 (doubled 10-min delay), got {delta}"
    )
    print("PASS: arrival-delay correction_factor scales lateness (default 1.0)")


def test_sample_disruptions_threads_road_travel_time_multiplier():
    """failure.road_travel_time_multiplier config -> sampled disrupted edges."""
    import networkx as nx
    import numpy as np
    from src.scenario import _sample_disruptions

    G = nx.DiGraph()
    G.add_edge("A", "B", t0=10.0, capacity=100.0, p_fail=1.0, mode="road")
    G.add_edge("B", "C", t0=20.0, capacity=100.0, p_fail=0.0, mode="road")

    config = {
        "failure": {
            "mode": "capacity_reduction",
            "capacity_reduction_factor": 0.5,
            "road_travel_time_multiplier": 2.0,
        }
    }
    params = {"p_fail_scale": 1.0}
    disruptions = _sample_disruptions(G, config, params, np.random.default_rng(7))

    ab = disruptions[("A", "B")]
    assert not ab.is_blocked
    assert ab.capacity_factor == 0.5
    assert ab.travel_time_multiplier == 2.0
    assert disruptions[("B", "C")].travel_time_multiplier == 1.0

    disruptions_default = _sample_disruptions(
        G,
        {"failure": {"mode": "capacity_reduction", "capacity_reduction_factor": 0.5}},
        params,
        np.random.default_rng(7),
    )
    assert disruptions_default[("A", "B")].travel_time_multiplier == 1.0
    print("PASS: _sample_disruptions threads road_travel_time_multiplier from config")


def test_forced_edge_disruptions_use_sparse_deterministic_mapping():
    """Revision runs should not allocate normal states for every graph edge."""
    graph = nx.DiGraph()
    graph.add_edge("A", "B", mode="road", t0=1.0, capacity=100.0, p_fail=0.0)
    graph.add_edge("B", "C", mode="road", t0=1.0, capacity=100.0, p_fail=0.0)
    config = {
        "failure": {
            "forced_edges": [["A", "B"]],
            "mode": "capacity_reduction",
            "capacity_reduction_factor": 0.75,
            "road_travel_time_multiplier": 1.5,
        }
    }

    original_sampler = scenario_module.sample_edge_disruptions
    scenario_module.sample_edge_disruptions = lambda *args, **kwargs: (_ for _ in ()).throw(
        AssertionError("forced-edge path called full-graph sampler")
    )
    try:
        disruptions = scenario_module._sample_disruptions(
            graph,
            config,
            PARAMS,
            np.random.default_rng(123),
        )
    finally:
        scenario_module.sample_edge_disruptions = original_sampler

    assert set(disruptions) == {("A", "B")}
    disruption = disruptions[("A", "B")]
    assert disruption.status == "degraded"
    assert disruption.capacity_factor == 0.75
    assert disruption.travel_time_multiplier == 1.5

    config["failure"]["forced_edges"] = [["missing", "edge"]]
    try:
        scenario_module._sample_disruptions(
            graph,
            config,
            PARAMS,
            np.random.default_rng(123),
        )
    except ValueError as exc:
        assert "missing" in str(exc)
    else:
        raise AssertionError("missing forced edge should fail")
    print("PASS: forced edge disruptions use sparse deterministic mapping")


def test_dynamic_shortest_path_evaluates_edge_weights_lazily():
    """Routing must not materialize weights for every edge in a large graph."""

    class RecordingTraffic:
        def __init__(self):
            self.disruptions = {
                ("A", "C"): EdgeDisruption(status="blocked"),
            }
            self.volume_window_min = 60.0
            self.alpha = 0.0
            self.beta = 4.0
            self.scale = 1.0
            self.evaluated_edges = []

        def current_volume(self, edge, depart_time):
            assert depart_time == 12.0
            self.evaluated_edges.append(edge)
            return 0.0

    graph = nx.DiGraph()
    graph.add_edge("A", "B", t0=1.0, capacity=100.0, mode="road")
    graph.add_edge("B", "D", t0=1.0, capacity=100.0, mode="road")
    graph.add_edge("A", "C", t0=0.1, capacity=100.0, mode="road")
    graph.add_edge("C", "D", t0=0.1, capacity=100.0, mode="road")
    for index in range(100):
        graph.add_edge(
            f"unused-{index}",
            f"unused-{index + 1}",
            t0=0.01,
            capacity=100.0,
            mode="road",
        )

    original_materializer = scenario_module._edge_weights_at_time

    def fail_if_materialized(*args, **kwargs):
        raise AssertionError("dynamic routing materialized the full edge-weight table")

    scenario_module._edge_weights_at_time = fail_if_materialized
    try:
        traffic = RecordingTraffic()
        path = scenario_module._shortest_path_at_time(
            graph,
            traffic,
            "A",
            "D",
            12.0,
            allowed_modes={"road"},
        )
    finally:
        scenario_module._edge_weights_at_time = original_materializer

    assert path == ["A", "B", "D"], path
    assert traffic.evaluated_edges
    assert all(not edge[0].startswith("unused-") for edge in traffic.evaluated_edges), (
        "lazy routing evaluated disconnected edges: "
        f"{traffic.evaluated_edges}"
    )

    traffic.disruptions[("B", "D")] = EdgeDisruption(status="blocked")
    no_path = scenario_module._shortest_path_at_time(
        graph,
        traffic,
        "A",
        "D",
        12.0,
        allowed_modes={"road"},
    )
    assert no_path == [], no_path
    print("PASS: dynamic shortest path evaluates edge weights lazily")


def test_dynamic_shortest_path_accounts_for_direct_damage_multiplier():
    """Slowdown must affect path choice, not only traversal after routing."""
    graph = nx.DiGraph()
    graph.add_edge("A", "B", t0=1.0, capacity=HIGH_CAPACITY, mode="road")
    graph.add_edge("B", "D", t0=1.0, capacity=HIGH_CAPACITY, mode="road")
    graph.add_edge("A", "C", t0=3.0, capacity=HIGH_CAPACITY, mode="road")
    graph.add_edge("C", "D", t0=3.0, capacity=HIGH_CAPACITY, mode="road")
    traffic = DynamicRoadTraffic(
        graph,
        volume_window_min=60.0,
        background_volume=0.0,
        alpha=0.0,
        disruptions={
            ("A", "B"): EdgeDisruption(travel_time_multiplier=10.0),
        },
    )

    path = scenario_module._shortest_path_at_time(
        graph,
        traffic,
        "A",
        "D",
        0.0,
        allowed_modes={"road"},
    )
    assert path == ["A", "C", "D"]
    print("PASS: direct slowdown participates in route choice")


def test_a2_route_cache_avoids_repeated_full_graph_search():
    """Opt-in A2 cache reuses one disruption-aware path per route traveler."""
    graph = nx.DiGraph()
    graph.add_edge("A", "D", t0=5.0, capacity=HIGH_CAPACITY, mode="road")
    traffic = DynamicRoadTraffic(
        graph,
        volume_window_min=60.0,
        background_volume=0.0,
        alpha=0.0,
    )
    original = scenario_module._shortest_path_at_time
    calls = []

    def counted(*args, **kwargs):
        calls.append(args[4])
        return original(*args, **kwargs)

    scenario_module._shortest_path_at_time = counted
    try:
        traveler = scenario_module._make_route_traveler(
            graph,
            traffic,
            "A",
            "D",
            allowed_modes={"road"},
            rerouting_config={"cache_departure_path": True},
        )
        traveler(0.0)
        traveler(10.0)
    finally:
        scenario_module._shortest_path_at_time = original

    assert len(calls) == 1
    print("PASS: opt-in A2 route cache avoids repeated graph search")


def test_reverse_network_delay_controls_second_bus_trip():
    """Empty reverse traversal must delay reuse on an asymmetric road graph."""
    config = make_config(
        total=2,
        group_size=1,
        bus_route_time=5.0,
        dispatch_interval=1.0,
        fleet_size=1,
        turnaround=0.0,
        time_limit=100.0,
        return_strategy="reverse_network",
    )
    config["network"]["road_links"].append(
        ["D", "A", 20.0, HIGH_CAPACITY, 0.0]
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 0.0])

    assert result["success_count"] == 2
    assert result["bus_trips"] == 2
    assert_close(result["makespan"], 30.0, label="reverse-delayed makespan")
    print("PASS: reverse road traversal delays second bus trip")


def test_missing_reverse_route_retires_vehicle_after_delivery():
    """Unreachable empty return must retire vehicle without undoing delivery."""
    config = make_config(
        total=2,
        group_size=1,
        bus_route_time=5.0,
        dispatch_interval=1.0,
        fleet_size=1,
        turnaround=0.0,
        time_limit=100.0,
        return_strategy="reverse_network",
    )

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 0.0])

    assert result["success_count"] == 1
    assert result["leftover_count"] == 1
    assert result["bus_trips"] == 1
    assert_close(result["makespan"], 5.0, label="delivered first trip makespan")
    print("PASS: missing reverse route retires vehicle after delivery")


def test_invalid_return_strategy_fails_loudly():
    """Unknown fleet return strategy must not silently use legacy semantics."""
    config = make_config(
        total=1,
        group_size=1,
        return_strategy="teleport",
    )

    try:
        run_fixed(config, "bus_only", StrictPolicy(), [0.0])
    except ValueError as exc:
        assert "fleet.return_strategy" in str(exc), str(exc)
    else:
        raise AssertionError("invalid fleet.return_strategy was accepted")
    print("PASS: invalid return strategy fails loudly")


def test_legacy_return_strategy_preserves_one_way_results():
    """Absent and explicit legacy strategy must remain byte-level equivalent."""
    implicit = make_config(
        total=2,
        group_size=1,
        bus_route_time=5.0,
        dispatch_interval=1.0,
        fleet_size=1,
        turnaround=2.0,
        time_limit=100.0,
    )
    explicit = make_config(
        total=2,
        group_size=1,
        bus_route_time=5.0,
        dispatch_interval=1.0,
        fleet_size=1,
        turnaround=2.0,
        time_limit=100.0,
        return_strategy="legacy_none",
    )
    for config in (implicit, explicit):
        config["network"]["road_links"].append(
            ["D", "A", 50.0, HIGH_CAPACITY, 0.0]
        )

    implicit_result = run_fixed(implicit, "bus_only", StrictPolicy(), [0.0, 0.0])
    explicit_result = run_fixed(explicit, "bus_only", StrictPolicy(), [0.0, 0.0])

    assert implicit_result == explicit_result
    assert_close(implicit_result["makespan"], 12.0, label="legacy makespan")
    print("PASS: legacy return strategy preserves one-way results")


def test_reverse_network_applies_to_multimodal_road_roles():
    """Feeder and last-mile fleets must both traverse their reverse road legs."""
    feeder_config = make_config(
        total=2,
        group_size=1,
        shuttle_time=1.0,
        rail_time=0.0,
        rail_headway=1.0,
        rail_capacity=2,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=1,
        lastmile_fleet_size=2,
        lastmile_vehicle_capacity=1,
        lastmile_turnaround=0.0,
        time_limit=100.0,
        return_strategy="reverse_network",
    )
    feeder_config["network"]["road_links"].extend(
        [
            ["S", "A", 10.0, HIGH_CAPACITY, 0.0],
            ["D", "R", 0.0, HIGH_CAPACITY, 0.0],
        ]
    )
    feeder_config["multimodal"]["shuttle_turnaround_min"] = 0.0
    feeder_result = run_fixed(
        feeder_config,
        "multimodal",
        StrictPolicy(),
        [0.0, 0.0],
    )
    assert_close(feeder_result["makespan"], 13.0, label="feeder-return makespan")

    lastmile_config = make_config(
        total=2,
        group_size=1,
        shuttle_time=1.0,
        rail_time=0.0,
        rail_headway=1.0,
        rail_capacity=2,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=2,
        lastmile_fleet_size=1,
        lastmile_vehicle_capacity=1,
        lastmile_turnaround=0.0,
        time_limit=100.0,
        return_strategy="reverse_network",
    )
    lastmile_config["network"]["road_links"].extend(
        [
            ["S", "A", 0.0, HIGH_CAPACITY, 0.0],
            ["D", "R", 20.0, HIGH_CAPACITY, 0.0],
        ]
    )
    lastmile_config["multimodal"]["shuttle_turnaround_min"] = 0.0
    lastmile_result = run_fixed(
        lastmile_config,
        "multimodal",
        StrictPolicy(),
        [0.0, 0.0],
    )
    assert_close(
        lastmile_result["makespan"],
        23.0,
        label="last-mile-return makespan",
    )
    print("PASS: reverse network applies to feeder and last-mile fleets")


def test_extended_metrics_are_opt_in_without_changing_legacy_keys():
    """Default results must retain exact legacy key identity."""
    config = make_config(
        total=1,
        group_size=1,
        bus_route_time=2.0,
        dispatch_interval=1.0,
        fleet_size=1,
    )

    legacy = run_fixed(config, "bus_only", StrictPolicy(), [0.0])
    assert set(legacy) == LEGACY_RESULT_KEYS, sorted(set(legacy) ^ LEGACY_RESULT_KEYS)
    assert "vehicle_cycles" not in legacy

    config["metrics"]["include_extended"] = True
    extended = run_fixed(config, "bus_only", StrictPolicy(), [0.0])
    assert {key: extended[key] for key in LEGACY_RESULT_KEYS} == legacy
    assert extended["vehicle_cycles"] == 1
    print("PASS: extended scenario metrics preserve default key identity")


def test_extended_bus_metrics_include_fleet_delay_and_finite_returns():
    """Road accounting must use actual departures, manifests, and return paths."""
    config = make_config(
        total=3,
        group_size=2,
        bus_route_time=5.0,
        dispatch_interval=1.0,
        fleet_size=1,
        turnaround=0.0,
        time_limit=100.0,
        return_strategy="reverse_network",
    )
    config["network"]["road_links"].append(
        ["D", "A", 7.0, HIGH_CAPACITY, 0.0]
    )
    config["metrics"]["include_extended"] = True

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0, 0.0, 0.0])

    assert_close(result["makespan"], 17.0, label="return-delayed makespan")
    assert result["vehicle_cycles"] == 2
    assert result["empty_return_trips"] == 2
    assert_close(result["empty_return_minutes"], 14.0, label="empty return minutes")
    assert result["deployed_seat_capacity"] == 4
    assert result["boarded_passengers"] == 3
    assert_close(result["mean_vehicle_load_factor"], 0.75, label="load factor")
    assert result["assembly_wait_passenger_count"] == 3
    assert_close(
        result["assembly_wait_passenger_minutes"],
        12.0,
        label="assembly passenger-minutes",
    )
    assert_close(result["mean_assembly_wait_min"], 4.0, label="mean assembly wait")
    print("PASS: extended bus metrics include fleet delay and finite returns")


def test_unreachable_empty_return_is_excluded_from_finite_metrics():
    """A retired vehicle may deliver passengers but must not emit infinite metrics."""
    config = make_config(
        total=1,
        group_size=1,
        bus_route_time=5.0,
        fleet_size=1,
        return_strategy="reverse_network",
    )
    config["metrics"]["include_extended"] = True

    result = run_fixed(config, "bus_only", StrictPolicy(), [0.0])

    assert result["success_count"] == 1
    assert result["vehicle_cycles"] == 0
    assert result["empty_return_trips"] == 0
    assert_close(result["empty_return_minutes"], 0.0, label="finite return minutes")
    print("PASS: unreachable empty return stays out of finite metrics")


def test_extended_multimodal_waits_split_transfer_and_rail_platform_time():
    """Transfer processing and scheduled rail waiting must remain separate."""
    config = make_config(
        total=2,
        group_size=2,
        shuttle_time=2.0,
        rail_time=3.0,
        rail_headway=10.0,
        rail_capacity=2,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=1,
        lastmile_fleet_size=1,
        lastmile_vehicle_capacity=2,
        time_limit=100.0,
    )
    config["multimodal"]["transfer_time_min"] = 4.0
    config["metrics"]["include_extended"] = True

    result = run_fixed(config, "multimodal", StrictPolicy(), [0.0, 0.0])

    assert result["transfer_wait_passenger_count"] == 2
    assert_close(result["mean_transfer_wait_min"], 4.0, label="transfer wait")
    assert result["rail_wait_passenger_count"] == 2
    assert_close(result["mean_rail_wait_min"], 4.0, label="rail platform wait")
    assert result["deployed_seat_capacity"] == 4
    assert result["boarded_passengers"] == 4
    assert_close(result["mean_vehicle_load_factor"], 1.0, label="multimodal load")
    assert result["road_vehicle_cycles"] == 2
    assert result["road_deployed_seat_capacity"] == 4
    assert result["road_boarded_passengers"] == 4
    assert_close(result["road_mean_vehicle_load_factor"], 1.0, label="road load")
    assert result["rail_deployed_seat_capacity"] == 2
    assert result["rail_boarded_passengers"] == 2
    assert_close(result["rail_mean_load_factor"], 1.0, label="rail load")
    print("PASS: extended multimodal waits are stage-separated")


def test_adaptive_rng_streams_are_independent_stable_and_crn_aligned():
    """Adaptive arms need named RNG streams immune to sibling draw counts."""
    config = make_config(
        total=10,
        group_size=10,
        bus_route_time=1.0,
        shuttle_time=1.0,
        rail_time=1.0,
        rail_headway=1.0,
        rail_capacity=10,
        lastmile_time=1.0,
        time_limit=100.0,
    )
    config["adaptation"] = {"policy_id": "split_600_400"}
    config["stochastic"] = {
        "road_noise_sigma": 0.1,
        "turnaround_noise_lambda": 1.0,
    }

    original_bus = scenario_module._run_bus_only
    original_multi = scenario_module._run_multimodal

    def capture(scenario_type, direct_extra_draws):
        observed = {}

        def fake_bus(*args, **kwargs):
            road_rng = kwargs["rng_road"]
            turnaround_rng = kwargs["rng_turnaround"]
            observed["direct_road"] = road_rng.normal()
            observed["direct_turnaround"] = turnaround_rng.poisson()
            road_rng.normal(size=direct_extra_draws)
            turnaround_rng.poisson(size=direct_extra_draws)

        def fake_multi(*args, **kwargs):
            road_rng = kwargs["rng_road_shuttle"]
            turnaround_rng = kwargs["rng_turnaround_shuttle"]
            observed["service_road"] = road_rng.normal()
            observed["service_turnaround"] = turnaround_rng.poisson()

        scenario_module._run_bus_only = fake_bus
        scenario_module._run_multimodal = fake_multi
        try:
            run_fixed(config, scenario_type, StrictPolicy(), [0.0] * 10)
        finally:
            scenario_module._run_bus_only = original_bus
            scenario_module._run_multimodal = original_multi
        return observed

    split_short = capture("adaptive_split", 1)
    split_long = capture("adaptive_split", 100)
    assert split_short["service_road"] == split_long["service_road"]
    assert split_short["service_turnaround"] == split_long["service_turnaround"]
    assert split_short["direct_road"] != split_short["service_road"]

    direct_static = capture("bus_only", 0)
    assert direct_static["direct_road"] == split_short["direct_road"]
    assert (
        direct_static["direct_turnaround"]
        == split_short["direct_turnaround"]
    )

    service_static = capture("multimodal", 0)
    assert service_static["service_road"] == split_short["service_road"]
    assert (
        service_static["service_turnaround"]
        == split_short["service_turnaround"]
    )
    print("PASS: adaptive RNG streams are independent, stable, and CRN-aligned")


def test_adaptive_split_uses_sixty_forty_allocation_and_conserves_passengers():
    """Split policy must send floor(60%) by rail and every other person by bus."""
    config = make_config(
        total=10,
        group_size=10,
        bus_route_time=10.0,
        shuttle_time=1.0,
        rail_time=5.0,
        rail_headway=1.0,
        rail_capacity=10,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=1,
        lastmile_fleet_size=1,
        lastmile_vehicle_capacity=10,
        time_limit=100.0,
    )
    config["adaptation"] = {"policy_id": "split_600_400"}

    result = run_fixed(config, "adaptive_split", StrictPolicy(), [0.0] * 10)

    assert result["success_count"] == 10
    assert result["leftover_count"] == 0
    assert result["train_trips"] == 1
    assert result["bus_trips"] == 2
    # 4 * direct(10) + 6 * (shuttle(1) + rail(5) + last-mile(1)).
    assert_close(
        result["passenger_travel_minutes"],
        82.0,
        label="split passenger travel minutes",
    )
    print("PASS: adaptive split uses floor sixty-forty allocation")


def test_adaptive_split_keeps_rail_share_incomplete_when_rail_is_unavailable():
    """Unavailable rail must strand only the deterministic 60% rail share."""
    config = make_config(
        total=10,
        group_size=10,
        bus_route_time=10.0,
        shuttle_time=1.0,
        rail_time=5.0,
        rail_headway=1.0,
        rail_capacity=10,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=1,
        time_limit=100.0,
    )
    config["multimodal"]["rail_status"] = "unavailable"
    config["adaptation"] = {"policy_id": "split_600_400"}

    result = run_fixed(config, "adaptive_split", StrictPolicy(), [0.0] * 10)

    assert result["success_count"] == 4
    assert result["leftover_count"] == 6
    assert_close(result["completion_rate"], 0.4, label="split completion rate")
    assert result["train_trips"] == 0
    print("PASS: unavailable rail strands only adaptive split rail share")


def test_station_fallback_threshold_changes_makespan_and_completes():
    """Unavailable rail must trigger finite S-to-D fallback after configured hold."""
    base = make_config(
        total=2,
        group_size=2,
        shuttle_time=1.0,
        rail_time=5.0,
        rail_headway=1.0,
        rail_capacity=2,
        dispatch_interval=1.0,
        fleet_size=1,
        lastmile_fleet_size=1,
        lastmile_turnaround=0.0,
        lastmile_vehicle_capacity=2,
        time_limit=200.0,
        return_strategy="reverse_network",
    )
    base["network"]["road_links"].extend(
        [
            ["S", "D", 7.0, HIGH_CAPACITY, 0.0],
            ["D", "S", 7.0, HIGH_CAPACITY, 0.0],
        ]
    )
    base["multimodal"]["rail_status"] = "unavailable"
    base["metrics"]["include_extended"] = True

    fallback_30 = dict(base)
    fallback_30["adaptation"] = {
        "policy_id": "station_fallback_30",
        "fallback_fleet_size": 1,
    }
    result_30 = run_fixed(
        fallback_30,
        "adaptive_fallback",
        StrictPolicy(),
        [0.0, 0.0],
    )

    fallback_90 = dict(base)
    fallback_90["adaptation"] = {
        "policy_id": "station_fallback_90",
        "fallback_fleet_size": 1,
    }
    result_90 = run_fixed(
        fallback_90,
        "adaptive_fallback",
        StrictPolicy(),
        [0.0, 0.0],
    )

    assert result_30["success_count"] == 2
    assert result_90["success_count"] == 2
    assert_close(
        result_90["makespan"] - result_30["makespan"],
        60.0,
        label="fallback hold delta",
    )
    assert result_30["empty_return_trips"] == 1
    assert_close(result_30["empty_return_minutes"], 7.0, label="fallback return")
    assert_close(
        result_30["mean_transfer_wait_min"],
        30.0,
        label="fallback station hold",
    )
    print("PASS: station fallback threshold controls completion time")


def test_available_or_degraded_station_fallback_is_identical_to_static_multimodal():
    """Fallback policy must be inert while rail remains available or degraded."""
    config = make_config(
        total=2,
        group_size=2,
        shuttle_time=1.0,
        rail_time=5.0,
        rail_headway=1.0,
        rail_capacity=2,
        lastmile_time=1.0,
        dispatch_interval=1.0,
        fleet_size=1,
        lastmile_fleet_size=1,
        lastmile_vehicle_capacity=2,
        time_limit=100.0,
    )
    config["adaptation"] = {"policy_id": "station_fallback_60"}

    for rail_state in ("available", "degraded"):
        config["multimodal"].update(
            {
                "rail_status": rail_state,
                "rail_degradation_multiplier": 2.0,
            }
        )
        static_result = run_fixed(
            config,
            "multimodal",
            StrictPolicy(),
            [0.0, 0.0],
        )
        adaptive_result = run_fixed(
            config,
            "adaptive_fallback",
            StrictPolicy(),
            [0.0, 0.0],
        )
        assert adaptive_result == static_result, rail_state
    print("PASS: available and degraded fallback are multimodal-identical")


def test_invalid_adaptive_policy_config_fails_loudly():
    """Adaptive scenario types must reject missing or mismatched policy ids."""
    missing = make_config(total=1, group_size=1)
    try:
        run_fixed(missing, "adaptive_split", StrictPolicy(), [0.0])
    except ValueError as exc:
        assert "adaptation.policy_id" in str(exc), str(exc)
    else:
        raise AssertionError("missing adaptive policy id was accepted")

    mismatched = make_config(total=1, group_size=1)
    mismatched["adaptation"] = {"policy_id": "station_fallback_30"}
    try:
        run_fixed(mismatched, "adaptive_split", StrictPolicy(), [0.0])
    except ValueError as exc:
        assert "adaptation.policy_id" in str(exc), str(exc)
    else:
        raise AssertionError("mismatched adaptive policy id was accepted")
    print("PASS: invalid adaptive policy config fails loudly")


TESTS = [
    test_origin_schedule_defaults_to_assembly_time,
    test_origin_schedule_accepts_explicit_first_departure,
    test_strict_departures_do_not_wait_for_late_arrivals,
    test_fleet_delay_does_not_retroactively_board_late_arrivals,
    test_grace_waits_for_threshold_and_differs_from_strict,
    test_grace_max_wait_leaves_late_arrivals_for_next_dispatch,
    test_bus_fleet_allows_overlapping_trips,
    test_rail_departures_keep_fixed_headway_while_trains_are_in_transit,
    test_explicit_rail_first_departure_is_honored,
    test_explicit_available_rail_state_preserves_default_result,
    test_degraded_rail_state_multiplies_only_rail_travel_time,
    test_unavailable_rail_state_produces_no_rail_departures_or_arrivals,
    test_invalid_rail_state_and_degradation_multiplier_fail_loudly,
    test_lastmile_fleet_capacity_and_turnaround_create_bottleneck,
    test_censoring_penalty_prevents_failed_scenario_from_looking_better,
    test_arrival_delay_correction_factor_scales_lateness,
    test_sample_disruptions_threads_road_travel_time_multiplier,
    test_forced_edge_disruptions_use_sparse_deterministic_mapping,
    test_dynamic_shortest_path_evaluates_edge_weights_lazily,
    test_dynamic_shortest_path_accounts_for_direct_damage_multiplier,
    test_a2_route_cache_avoids_repeated_full_graph_search,
    test_reverse_network_delay_controls_second_bus_trip,
    test_missing_reverse_route_retires_vehicle_after_delivery,
    test_invalid_return_strategy_fails_loudly,
    test_legacy_return_strategy_preserves_one_way_results,
    test_reverse_network_applies_to_multimodal_road_roles,
    test_extended_metrics_are_opt_in_without_changing_legacy_keys,
    test_extended_bus_metrics_include_fleet_delay_and_finite_returns,
    test_unreachable_empty_return_is_excluded_from_finite_metrics,
    test_extended_multimodal_waits_split_transfer_and_rail_platform_time,
    test_adaptive_rng_streams_are_independent_stable_and_crn_aligned,
    test_adaptive_split_uses_sixty_forty_allocation_and_conserves_passengers,
    test_adaptive_split_keeps_rail_share_incomplete_when_rail_is_unavailable,
    test_station_fallback_threshold_changes_makespan_and_completes,
    test_available_or_degraded_station_fallback_is_identical_to_static_multimodal,
    test_invalid_adaptive_policy_config_fails_loudly,
]


if __name__ == "__main__":
    failures = []
    for test in TESTS:
        try:
            test()
        except AssertionError as exc:
            failures.append((test.__name__, str(exc)))
            print(f"FAIL: {test.__name__}: {exc}")
        except Exception as exc:
            failures.append((test.__name__, f"{type(exc).__name__}: {exc}"))
            print(f"ERROR: {test.__name__}: {type(exc).__name__}: {exc}")

    if failures:
        print("\n=== SCENARIO TEST FAILURES ===")
        for name, message in failures:
            print(f"- {name}: {message}")
        raise SystemExit(1)

    print("\n=== ALL SCENARIO TESTS PASSED ===")
